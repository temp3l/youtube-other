# YouTube Positioning Shorts — v3 50-second narration pack

This package updates all 18 Shorts across EN, DE, IT, FR and PT: **90 narration files**.

The original v2 scripts averaged roughly 88–97 words depending on locale and produced real rendered videos as short as ~22 seconds. v3 expands each script into a complete micro-lesson while preserving the original positioning thesis and content IDs.

## Use
1. Feed `shorts/{locale}/*.md` directly to TTS.
2. Measure actual audio duration.
3. Accept 45–60 seconds; prefer 50–55 seconds.
4. For a miss, remediate only that locale's narration.
5. Freeze narration/TTS before final image/video regeneration.

See `PRODUCTION-REVIEW.md` and `meta/runtime-calibration.json`.
