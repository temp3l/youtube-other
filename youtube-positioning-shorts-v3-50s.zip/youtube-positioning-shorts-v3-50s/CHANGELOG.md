# v3 changes

- Expanded all 90 Shorts narrations.
- Preserved IDs, slugs and localized titles.
- Added concrete examples/mechanisms instead of filler.
- Added measured-runtime policy and calibrated preflight estimates.
- Added canonical YouTube production ratings.
- No long-form narration changed.
