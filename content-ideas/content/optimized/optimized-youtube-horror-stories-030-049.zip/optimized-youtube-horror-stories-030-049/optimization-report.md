# Optimization Report — Episodes 030–049

## Overall assessment

The source scripts had strong hooks and usable concepts, but most read as expanded beat sheets rather than finished narration. The optimized versions preserve each premise while adding specific scenes, investigation, evidence, rules, failed safety measures, active choices, consequences, climaxes and final reversals.

| Ep. | Title | Words | Runtime @ 175–185 WPM | Before | After |
|---:|---|---:|---:|---:|---:|
| 030 | The Woman in the Painting Was Moving | 1234 | 6.7–7.0 min | 5.0/10 | 8.2/10 |
| 031 | The Faceless Man Appeared in Every Photograph | 1215 | 6.6–6.9 min | 5.0/10 | 8.2/10 |
| 032 | The Emergency Broadcast Named the Next Victim | 1197 | 6.5–6.8 min | 5.0/10 | 8.2/10 |
| 033 | They Buried It—But It Always Came Back | 1205 | 6.5–6.9 min | 5.0/10 | 8.2/10 |
| 034 | Her Reflection Stopped Copying Her | 1167 | 6.3–6.7 min | 5.0/10 | 8.2/10 |
| 035 | The Wendigo Legend Was Never About a Monster | 1202 | 6.5–6.9 min | 5.0/10 | 8.6/10 |
| 036 | The House Repeated Every Voice It Heard | 1178 | 6.4–6.7 min | 5.0/10 | 8.2/10 |
| 037 | The Hospital Corridor That Shouldn't Exist | 1166 | 6.3–6.7 min | 5.0/10 | 8.2/10 |
| 038 | The Rain Man Only Appeared During Storms | 1169 | 6.3–6.7 min | 5.0/10 | 8.2/10 |
| 039 | The Photograph Changed Every Night | 1153 | 6.2–6.6 min | 5.0/10 | 8.2/10 |
| 040 | No Guest Ever Checked Out of Room 1413 | 1164 | 6.3–6.7 min | 5.0/10 | 8.2/10 |
| 041 | The Town That Calls Your Name After Dark | 1157 | 6.2–6.6 min | 4.5/10 | 8.2/10 |
| 042 | The Video Knew Who Was Watching | 1172 | 6.3–6.7 min | 4.5/10 | 8.2/10 |
| 043 | The Clown Appeared in Every Window | 1149 | 6.2–6.6 min | 4.5/10 | 8.2/10 |
| 044 | The Door That Was Never Meant to Open | 1161 | 6.3–6.6 min | 4.5/10 | 8.2/10 |
| 045 | The Village That Disappeared Overnight | 1147 | 6.2–6.5 min | 4.5/10 | 8.2/10 |
| 046 | The Mask That Would Not Come Off | 1149 | 6.2–6.6 min | 4.5/10 | 8.2/10 |
| 047 | The Story That Erases Everyone Who Hears It | 1139 | 6.2–6.5 min | 4.5/10 | 8.2/10 |
| 048 | Never Take This Road After Midnight | 1160 | 6.3–6.6 min | 4.5/10 | 8.2/10 |
| 049 | The Doll That Collected People's Eyes | 1157 | 6.2–6.6 min | 4.5/10 | 8.2/10 |

## Reusable production recommendations

1. Open with an impossible event immediately.
2. Attach the sound motif only to escalation points.
3. Give the threat an observable rule.
4. Include a reasonable failed safety measure.
5. Expand decisions and consequences, not decorative description.
6. Use an evidence trail and investigation to add meaningful runtime.
7. End with apparent escape followed by one concise contradiction.
8. Separate cultural or factual context from fictional reconstruction.