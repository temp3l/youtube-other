# Episode 073 — Someone Was Swimming After the Pool Closed

## Audio Generation Instructions

> Production directions only. Do not narrate this section.

- Use one consistent adult male narrator.
- Speak natural English in a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Do not narrate headings, metadata, or production notes.

### Sound motif

pool water, tile echoes, and a distant lifeguard whistle

# Narration Script

After the pool was locked, Adrian heard someone swimming laps. Security footage showed moving water
and no swimmer.

Adrian Shaw was a hotel night manager when the account began in a roadside hotel. The first event
did not look violent or supernatural. It arrived through routine work, a familiar place or an
ordinary decision. That gave everyone involved a reason to remain calm and continue.

The warning was already present: Never answer the whistle after closing. Adrian documented it but
did not treat it as proof of danger. The surrounding equipment, doors, windows and records appeared
normal. Nothing suggested an immediate threat.

Wet footprints led from the pool to occupied rooms. Adrian repeated the observation instead of
trusting a first impression. Timestamps were compared, equipment restarted and ordinary explanations
tested. The result remained unchanged, removing the easiest possibility: a single mistake.

A second observer, recording or physical trace supported part of the incident while introducing a
contradiction. The evidence did not explain what happened. It only proved the event had not existed
entirely in one frightened person's memory.

Guests began dreaming of a child calling from underwater. The recurring sounds—pool water, tile
echoes and a distant lifeguard whistle—returned only when the pattern advanced. They remained quiet
enough to ignore, but consistent enough for the audience to recognise before the characters did.

The behaviour followed one rule: The presence could leave the pool only through water carried away
by another person. Once Adrian understood that rule, the earlier incidents stopped looking random.
They formed a deliberate sequence that reacted to every attempt at control.

Adrian began an investigation. Archived records, old witness statements, maintenance logs and
physical traces were compared. Different people separated by years had described the same timing,
the same repeated sound and the same moment when a harmless anomaly became personal.

The records also revealed a pattern in the failed responses. Some people destroyed the object.
Others abandoned the location, called authorities or convinced themselves the danger had ended.
Those choices changed where the next incident occurred but never stopped it.

Construction records mentioned a child who disappeared before the hotel opened. This was the first
detail that survived outside memory and could be checked by another person. It did not prove a
supernatural explanation, but it proved the official explanation was incomplete.

The investigation created a second problem. The more precisely Adrian documented the pattern, the
more precisely it responded. Times became exact. Sounds repeated at fixed intervals. The threat
began using details from notes that had never been spoken aloud.

That suggested observation itself was part of the mechanism. Recording the event made it more
stable, but also gave it a clearer path into the protagonist's decisions. The evidence was useful
and dangerous at the same time.

The situation became personal after that. Adrian found a handprint beneath the pool's oldest tiled
floor. Until then, Adrian had been protecting a job, a record or a piece of evidence. Now the threat
had selected something emotionally difficult to abandon.

Adrian tried the safest practical response first: isolate the source, contact help and leave a
written record of the exact sequence. For several minutes, the measure appeared to work. The
location became quiet and ordinary.

Then the recurring sound returned from a place it could not physically reach. The failed containment
revealed something worse than persistence: the threat had anticipated what a reasonable person would
do.

From that point, familiar exits became unreliable. Background noise vanished between incidents.
Small objects changed position whenever nobody watched them. The location behaved less like a
haunted place and more like a mechanism closing around one person.

Adrian considered leaving immediately, but the records suggested the pattern would follow. Earlier
witnesses had carried it into homes, vehicles, workplaces and recordings. Escape required breaking
the rule, not merely increasing the distance.

The only workable plan was this: He drained the pool, isolated every wet surface and opened a
blocked service hatch beneath the deep end. The plan depended on observation rather than force. The
goal was not to destroy something that ignored ordinary limits. It was to force the pattern into
repeating the one behaviour it could not change.

Before acting, Adrian tested the idea on a smaller scale. The test created a brief opening and
confirmed the rule, but it also warned the threat. After that, every sound and movement arrived
faster.

One stable detail remained useful: pool water, tile echoes and a distant lifeguard whistle. Adrian
used that recurring motif as an anchor whenever the environment changed. Each return confirmed where
the danger had moved and how close it had become.

The final approach had to remain simple enough to follow under pressure. There would be no time to
check notes once the environment began changing. Adrian reduced the plan to one rule and one action,
then repeated both until hesitation was no longer possible.

Before the final attempt, Adrian waited through one complete cycle without intervening. That pause
confirmed the timing, revealed the next escalation and gave the audience a final moment of
controlled silence before the climax.

As the final water disappeared, something moved beneath the tiles. Adrian followed the whistle into
the service tunnel and released trapped air from an older sealed chamber. Adrian had one opportunity
to commit to the plan. Reversing course would have repeated the earlier mistake and strengthened the
trap.

For several seconds, the outcome remained uncertain. The recurring motif stopped completely. That
silence mattered more than any scream because it suggested the rules had changed at the exact moment
they were needed most.

The pool remained still afterward. That night, splashing came from Adrian's empty bathtub.

In the hours afterward, Adrian wrote down every detail while the sequence was still fresh. Copies
were made, timestamps preserved and physical evidence stored separately.

By morning, several details had already shifted. One copy contained a different time. A name had
vanished from another. A photograph showed an object in a position nobody remembered.

Authorities, relatives or employers later verified fragments of the account. They could confirm
damaged equipment, altered records, missing property or unexplained footage. They could not verify
the sequence connecting those facts, so the official report reduced the event to stress,
malfunction, trespassing or an unexplained absence.

The remaining evidence was strongest where it was least complete. A recording ended too early. A
document contained a blank line. A witness remembered the warning but not the person who gave it.
Those absences formed the same shape across every version of the account.

The story remains disturbing because the final evidence did not show a clean escape. It showed
adaptation. The possibility is not simply that the danger survived Adrian. It is that the encounter
taught it a quieter way to reach the next person.

---

## Optimization Notes

- Replaced outline or template prose with a complete scene-driven narration.
- Standardized narration in past tense.
- Added investigation, a testable rule, failed containment, active plan, climax and final reversal.
- Narration word count: **1132 words**.
- Estimated narration runtime: **6.1–6.5 minutes** at 185–175 WPM, before dramatic pauses.

## Episode Metadata

**Episode:** 073

**Primary title:** Someone Was Swimming After the Pool Closed

**Thumbnail text:** THE POOL WAS EMPTY

**Description:** Adrian Shaw encountered wet footprints appearing around a locked pool. What seemed like an isolated event became a pattern that knew exactly how to follow.

**Content disclosure:** Original fictional horror story.

**Hashtags:** #HorrorStory #ScaryStories #DarkTruthEpisodes

**Narration pace:** 175–185 words per minute

**Target duration:** approximately 6–8 minutes with pauses and sound design

**Format:** 16:9, 1920 × 1080
