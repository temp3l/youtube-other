# Optimization Report — Episodes 070–089

## Overall assessment

Episodes 070–080 contained usable plot outlines but were too short and relied on repeated framework language. Episodes 081–089 were generic templates with almost no story-specific narrative. All twenty files were rebuilt as scene-driven narrations with concrete protagonists, rules, evidence, containment failures, plans, climaxes and final reversals.

| Ep. | Title | Words | Runtime @ 175–185 WPM | Before | After |
|---:|---|---:|---:|---:|---:|
| 070 | Her Livestream Continued After She Disappeared | 1177 | 6.4–6.7 min | 4.7/10 | 8.2/10 |
| 071 | The Laundromat Only Opened at Midnight | 1142 | 6.2–6.5 min | 4.7/10 | 8.2/10 |
| 072 | The Scarecrow Appeared at Window Three | 1140 | 6.2–6.5 min | 4.7/10 | 8.2/10 |
| 073 | Someone Was Swimming After the Pool Closed | 1132 | 6.1–6.5 min | 4.7/10 | 8.2/10 |
| 074 | The Book Wrote Its Own Ending | 1139 | 6.2–6.5 min | 4.7/10 | 8.2/10 |
| 075 | The Lift Opened on the Blackout Floor | 1137 | 6.2–6.5 min | 4.7/10 | 8.2/10 |
| 076 | A Voice Was Calling From Beneath the Ice | 1138 | 6.2–6.5 min | 4.7/10 | 8.2/10 |
| 077 | Nothing Cast a Shadow Inside the House | 1123 | 6.1–6.4 min | 4.7/10 | 8.2/10 |
| 078 | The Subway Map Added One Extra Stop | 1147 | 6.2–6.5 min | 4.7/10 | 8.2/10 |
| 079 | The Doctor Was Called to an Empty House | 1142 | 6.2–6.5 min | 4.7/10 | 8.2/10 |
| 080 | The Empty Seat Was Set for Someone | 1118 | 6.0–6.4 min | 4.7/10 | 8.2/10 |
| 081 | The Room Answered Before He Spoke | 1142 | 6.2–6.5 min | 3.5/10 | 8.2/10 |
| 082 | The Night Bus Had No Final Stop | 1136 | 6.1–6.5 min | 3.5/10 | 8.2/10 |
| 083 | The Window Never Showed Daylight | 1130 | 6.1–6.5 min | 3.5/10 | 8.2/10 |
| 084 | The Phone Rang From Inside a Grave | 1116 | 6.0–6.4 min | 3.5/10 | 8.2/10 |
| 085 | A Voice Spoke Through the Baby Monitor | 1122 | 6.1–6.4 min | 3.5/10 | 8.2/10 |
| 086 | A House Appeared Inside the Storm | 1129 | 6.1–6.5 min | 3.5/10 | 8.2/10 |
| 087 | A Bell Was Ringing Beneath the Church | 1124 | 6.1–6.4 min | 3.5/10 | 8.2/10 |
| 088 | Camera Nine Showed a Guard Who Wasn't There | 1122 | 6.1–6.4 min | 3.5/10 | 8.2/10 |
| 089 | The Chair Turned Toward the Room | 1136 | 6.1–6.5 min | 3.5/10 | 8.2/10 |

## Reusable recommendations

1. Start with the impossible detail before background.
2. Give every threat one observable and testable rule.
3. Tie the sound motif only to escalation points.
4. Include a reasonable failed containment attempt.
5. Expand investigation, choices and consequences instead of decorative description.
6. Let the protagonist solve the climax through observation rather than force.
7. End the apparent escape with one concise final contradiction.
8. Keep dialogue brief and TTS-friendly.