# Episode 087 — Unter der Kirche läutete eine Glocke

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Der Glockenturm war leer, doch unter dem Boden läutete eine Glocke. Die Warnung war bereits
vorhanden: Antworte der unterirdischen Glocke niemals mit der Turmglocke. Der Ton kam aus einer
versiegelten Krypta. Nach jedem Schlag fehlte ein Name im Kirchenregister. Das Verhalten folgte
einer Regel: Die vergrabene Glocke löschte jeden, dessen Name nicht vor dem nächsten Schlag
ausgesprochen wurde. Alte Pläne zeigten eine tiefere Kapelle, die aus allen späteren Unterlagen
entfernt worden war. Danach wurde die Situation persönlich. Mara sah, wie ihr eigener Name im
Register verblasste. Dann kehrte das wiederkehrende Geräusch aus einem Ort zurück, den es physisch
nicht erreichen konnte. Der einzige brauchbare Plan lautete: Sie stieg mit der vollständigen Liste
der ausgelöschten Gemeindemitglieder hinab und las jeden Namen zwischen den Schlägen. Die Türen der
Krypta schlossen sich, während die Glocke schneller läutete. Mara erreichte den letzten Namen und
zog an der Kette, bevor ihr Eintrag verschwand. Für einige Sekunden verstummte das wiederkehrende
Motiv vollständig. Die Glocke verstummte. Wochen später ertönte ein Schlag unter Maras Wohnung.

---

## Episode Metadata

**Episode:** 087

**Primary title:** Unter der Kirche läutete eine Glocke

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 167

**Estimated spoken duration:** approximately 54–57 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
