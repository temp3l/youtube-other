# Episode 082 — Der Nachtbus hatte keine Endstation

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Die Anzeige passierte die Endstation und begann statt Straßennamen Personennamen zu zeigen. Die
Warnung war bereits vorhanden: Drücke nicht den Halteknopf, nachdem der Fahrer das Innenlicht
ausgeschaltet hat. Jeder Fahrgast stieg aus, sobald sein eigener Name erschien. Niemand erinnerte
sich an die Menschen, die bereits ausgestiegen waren. Das Verhalten folgte einer Regel: Der Bus
brachte Menschen zu Augenblicken, die sie bereuten, und verlangte dafür eine Erinnerung als
Fahrpreis. Ninas Name erschien neben dem Krankenhaus, in dem ihre Mutter gestorben war. Danach wurde
die Situation persönlich. Der Fahrscheinautomat druckte ein Datum aus Ninas Kindheit. Dann kehrte
das wiederkehrende Geräusch aus einem Ort zurück, den es physisch nicht erreichen konnte. Der
einzige brauchbare Plan lautete: Sie betätigte alle Halteknöpfe gleichzeitig und weigerte sich, den
Ort zu nennen, an den sie zurückwollte. Der Bus fuhr durch Straßen, die nicht mehr existierten,
während Fahrgäste Nina zum Wählen drängten. Sie folgte den Notausgangsmarkierungen statt der
Anzeige. Für einige Sekunden verstummte das wiederkehrende Motiv vollständig. Bei Tagesanbruch
entkam sie. Ihr Ticket zeigte später eine verbleibende Fahrt ohne Ziel.

---

## Episode Metadata

**Episode:** 082

**Primary title:** Der Nachtbus hatte keine Endstation

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 172

**Estimated spoken duration:** approximately 56–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
