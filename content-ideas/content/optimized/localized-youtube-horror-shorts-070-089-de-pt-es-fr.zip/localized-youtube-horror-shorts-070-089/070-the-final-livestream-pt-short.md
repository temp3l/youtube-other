# Episode 070 — A transmissão continuou depois que ela desapareceu

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Os comentários avisavam Laura sobre salas às quais ela ainda não tinha chegado. Treze minutos
depois, cada aviso se tornava realidade. Um segundo ângulo de câmera apareceu na transmissão, embora
Laura tivesse levado apenas uma câmera. Contas pertencentes a pessoas desaparecidas começaram a
comentar em tempo real. O comportamento seguia uma regra: A transmissão tinha exatamente treze
minutos de atraso, e tudo mostrado pelo ângulo alternativo se tornava inevitável se Laura não
mudasse de direção a tempo. Depois disso, a situação se tornou pessoal. O ângulo alternativo
mostrava uma figura seguindo Laura, enquanto a câmera real filmava um corredor vazio. O único plano
possível era este: Laura encenou um caminho falso diante da câmera e seguiu para uma saída que o
segundo ângulo não havia mostrado. A figura apareceu nos dois vídeos ao mesmo tempo. Laura apagou as
luzes, seguiu os comentários mais antigos e alcançou a doca antes que o atraso a alcançasse. A
transmissão terminou quando Laura escapou. O canal continuou transmitindo de dentro do hospital, com
Laura ainda na tela.

---

## Episode Metadata

**Episode:** 070

**Primary title:** A transmissão continuou depois que ela desapareceu

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 173

**Estimated spoken duration:** approximately 56–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
