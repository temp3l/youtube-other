# Episode 077 — Nada proyectaba sombra dentro de la casa

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Después del anochecer, los muebles dejaron de proyectar sombras. Luego desapareció la sombra de
Lukas. La advertencia ya estaba allí: Nunca entres al sótano sin dos fuentes de luz. Las fotografías
mostraban figuras oscuras donde deberían estar las sombras. La casa se enfriaba cada vez que
desaparecía otra sombra. El comportamiento seguía una regla: La mansión separaba a las personas de
sus sombras y usaba estas para imitar a antiguos residentes. Todos los propietarios anteriores se
habían marchado sin volver a ser vistos. Después, la situación se volvió personal. Lukas encontró un
sótano lleno de siluetas humanas en movimiento. Entonces el sonido regresó desde un lugar al que no
podía llegar físicamente. El único plan posible era este: Usó focos opuestos para obligar a cada
sombra a superponerse con su dueño. Las figuras imitaron a residentes desaparecidos e intentaron
guiar a Lukas hacia la silueta equivocada. Reconoció la suya por un hueco con forma de cicatriz en
la mano. Su sombra volvió antes del amanecer. Días después, comenzó a moverse un segundo antes que
Lukas.

---

## Episode Metadata

**Episode:** 077

**Primary title:** Nada proyectaba sombra dentro de la casa

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 175

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
