# Episode 085 — Une voix parla dans le babyphone

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Le babyphone murmura : « Elle ne dort pas », alors que Laura tenait le bébé au rez-de-chaussée.
L’avertissement était déjà présent : Ne réponds pas après qu’il a prononcé le nom de l’enfant. La
voix décrivait des mouvements dans une chambre vide. Les enregistrements montraient un second
berceau à côté du vrai. Le comportement suivait une règle : La présence copiait les habitudes
parentales et devenait plus forte lorsque quelqu’un suivait ses instructions. Les anciens
propriétaires avaient signalé la même berceuse. Puis la situation devint personnelle. Laura entendit
sa propre voix promettre de monter le bébé. Puis le son revint d’un endroit qu’il ne pouvait
physiquement atteindre. Le seul plan viable était le suivant : Elle changea toutes les routines du
soir et créa une nouvelle phrase connue seulement d’elle et de son partenaire. Le babyphone donna
des consignes contradictoires tandis que des pas traversaient la chambre. Laura refusa d’entrer
avant d’entendre la bonne réponse à la nouvelle phrase. Pendant quelques secondes, le motif sonore
s’arrêta complètement. La chambre était vide. Plus tard, l’appareil éteint diffusa la nouvelle
phrase depuis l’intérieur.

---

## Episode Metadata

**Episode:** 085

**Primary title:** Une voix parla dans le babyphone

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 176

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
