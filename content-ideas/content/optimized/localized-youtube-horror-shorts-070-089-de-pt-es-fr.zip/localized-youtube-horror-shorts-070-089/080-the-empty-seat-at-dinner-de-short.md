# Episode 080 — Der leere Platz war für jemanden gedeckt

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Dreizehn Plätze waren für zwölf Gäste gedeckt. Niemand konnte den leeren Stuhl erklären. Die Warnung
war bereits vorhanden: Entferne den zusätzlichen Teller nicht vor der Mitternachtsglocke. Vom
unberührten Teller verschwand Essen. Familienfotos zeigten eine verschwommene Person auf demselben
Platz. Das Verhalten folgte einer Regel: Der vergessene Gast wurde stärker, wenn die Familie eine
wahre Erinnerung durch eine bequemere ersetzte. Jeder Verwandte erinnerte sich an einen anderen
Namen. Danach wurde die Situation persönlich. Mara fand ein Familientagebuch, aus dem eine Seite
sorgfältig entfernt worden war. Dann kehrte das wiederkehrende Geräusch aus einem Ort zurück, den es
physisch nicht erreichen konnte. Der einzige brauchbare Plan lautete: Sie rekonstruierte die
Identität des vergessenen Kindes aus Daten, Fotos und erhaltenen Briefen. Der Stuhl rückte vom Tisch
weg, während Mara die wahre Geschichte vorlas. Die Familie erinnerte sich an das Kind, das sie
absichtlich ausgelöscht hatte. Für einige Sekunden verstummte das wiederkehrende Motiv vollständig.
Beim nächsten Abendessen wartete neben Mara ein zweiter leerer Platz. Die Geschichte bleibt
verstörend, weil die letzten Beweise keine saubere Flucht zeigten, sondern Anpassung.

---

## Episode Metadata

**Episode:** 080

**Primary title:** Der leere Platz war für jemanden gedeckt

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 173

**Estimated spoken duration:** approximately 56–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
