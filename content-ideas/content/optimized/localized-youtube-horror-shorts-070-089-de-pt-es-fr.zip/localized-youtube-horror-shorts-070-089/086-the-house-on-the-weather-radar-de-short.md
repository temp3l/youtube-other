# Episode 086 — Ein Haus erschien im Sturm

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Auf dem Radar erschien ein vollständiges Haus innerhalb der Sturmzelle und bewegte sich gegen den
Wind. Die Warnung war bereits vorhanden: Folge niemals einem stillstehenden Radarsignal in einem
rotierenden Sturm. Das Haus erschien kurz auf Straßenkameras, obwohl dort kein Gebäude stand. Jeder
Raum enthielt Lichter, die zu Häusern passten, die in früheren Katastrophen verschwunden waren. Das
Verhalten folgte einer Regel: Der Sturm sammelte Gebäude, die Menschen bei Notfällen verlassen
hatten, und baute sie um neue Zeugen herum wieder auf. Archivradar zeigte dasselbe Haus vor früheren
Vermisstenfällen. Danach wurde die Situation persönlich. Adrian sah durch ein Fenster sein
Elternhaus. Dann kehrte das wiederkehrende Geräusch aus einem Ort zurück, den es physisch nicht
erreichen konnte. Der einzige brauchbare Plan lautete: Er berechnete die Rotation des Sturms und
näherte sich aus der einzigen Richtung, der das Haus nicht zugewandt sein konnte. Das Haus drehte
sich Raum für Raum, während Stimmen aus dem Inneren riefen. Adrian markierte die Koordinaten und
überquerte die Zugbahn, bevor das Gebäude die Drehung vollendete. Der Sturm brach zusammen. Später
zeigte eine Wetterkarte das Haussymbol über Adrians aktueller Adresse.

---

## Episode Metadata

**Episode:** 086

**Primary title:** Ein Haus erschien im Sturm

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 179

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
