# Episode 071 — La laverie n’ouvrait qu’à minuit

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

La Machine Sept tournait sans électricité. Derrière le hublot, Felix vit sa propre veste. L’écran
cessa d’afficher le temps restant et montra le numéro de l’appartement de Felix. Les vêtements à
l’intérieur appartenaient à des personnes portées disparues. Le comportement suivait une règle :
Chaque cycle effaçait un souvenir du propriétaire des vêtements. Une femme près d’un sèche-linge
éteint connaissait le nom de Felix, mais avait oublié le sien. Puis la situation devint personnelle.
Felix oublia pourquoi il était entré et trouva un reçu indiquant sept cycles terminés. Puis le son
revint d’un endroit qu’il ne pouvait physiquement atteindre. Le seul plan viable était le suivant :
Il coupa l’eau, bloqua le tambour et força la porte avant que le compteur n’atteigne zéro. Toute la
laverie se mit à tourner comme si le bâtiment formait une seule machine. Felix retira chaque
vêtement portant un nom et les prononça à voix haute. Au matin, la laverie avait disparu. Une pièce
marquée du chiffre sept revenait sans cesse dans la poche de Felix.

---

## Episode Metadata

**Episode:** 071

**Primary title:** La laverie n’ouvrait qu’à minuit

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 169

**Estimated spoken duration:** approximately 55–58 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
