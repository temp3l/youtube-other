# Episode 072 — Die Vogelscheuche erschien vor Fenster Drei

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Die Vogelscheuche stand vor einem Fenster im dritten Stock, obwohl es dort weder Sims noch Baum oder
Dach gab. Stroh erschien in einem von innen verschlossenen Klassenraum. Alte Jahrbücher zeigten
dieselbe Vogelscheuche hinter Schülern, die später verschwanden. Das Verhalten folgte einer Regel:
Sie rückte näher, wenn ein Schüler log, und wich nur zurück, wenn eine vergessene Wahrheit
ausgesprochen wurde. Fenster Drei war versiegelt worden, nachdem Jahrzehnte zuvor ein Schüler
hinausgestürzt war. Danach wurde die Situation persönlich. Sophie fand den Namen des verschwundenen
Schülers aus allen Schulakten herausgeschnitten. Dann kehrte das wiederkehrende Geräusch aus einem
Ort zurück, den es physisch nicht erreichen konnte. Der einzige brauchbare Plan lautete: Sie heftete
die ausgelöschten Namen früherer Schüler an den Mantel der Vogelscheuche und öffnete das Fenster nur
weit genug, um sie vorzulesen. Die Vogelscheuche beugte sich in den Raum, während Krähen gegen das
Glas schlugen. Als Sophie den letzten Namen sagte, drehte sich die Gestalt erstmals vom Gebäude weg.
Das Stroh verschwand aus der Schule. Am Abend stand eine neue Vogelscheuche vor Sophies Haus.

---

## Episode Metadata

**Episode:** 072

**Primary title:** Die Vogelscheuche erschien vor Fenster Drei

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 171

**Estimated spoken duration:** approximately 55–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
