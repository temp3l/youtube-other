# Episode 074 — O livro escreveu o próprio final

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

O romance inacabado acrescentou um capítulo descrevendo o dia de Mia antes que ela terminasse de
vivê-lo. O aviso já estava presente: Nunca adormeça na mesma sala que o manuscrito. Cada correção de
Mia alterava um pequeno acontecimento fora do arquivo. Editores anteriores apareciam nos capítulos
seguintes como personagens desaparecidos. O comportamento seguia uma regra: O livro só podia prever
decisões tomadas depois da leitura; páginas não lidas permaneciam incertas. O capítulo final estava
vazio, exceto pelo nome de Mia. Depois disso, a situação se tornou pessoal. Mia descobriu que todas
as tentativas de destruir o manuscrito já apareciam em edições anteriores. Então o som voltou de um
lugar ao qual não poderia chegar fisicamente. O único plano possível era este: Ela escreveu finais
contraditórios em páginas separadas e se recusou a ler qual deles o livro aceitaria. O arquivo mudou
enquanto os finais competiam para se tornar reais. Mia fechou o livro antes da última frase e o
trancou no escuro. O cofre estava vazio na manhã seguinte. A página de rosto listava Mia como
autora.

---

## Episode Metadata

**Episode:** 074

**Primary title:** O livro escreveu o próprio final

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 177

**Estimated spoken duration:** approximately 57–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
