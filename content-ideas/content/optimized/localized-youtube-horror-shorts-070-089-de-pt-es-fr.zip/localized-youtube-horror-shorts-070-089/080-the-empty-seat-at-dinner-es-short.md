# Episode 080 — El asiento vacío estaba preparado para alguien

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Había trece cubiertos para doce invitados. Nadie podía explicar la silla vacía. La advertencia ya
estaba allí: No retires el plato adicional antes de la campana de medianoche. La comida desaparecía
del plato intacto. Las fotos familiares mostraban una persona borrosa en el mismo asiento. El
comportamiento seguía una regla: El invitado olvidado se fortalecía cada vez que la familia
sustituía un recuerdo verdadero por otro más cómodo. Cada pariente recordaba un nombre distinto.
Después, la situación se volvió personal. Mara encontró un diario familiar con una página arrancada
cuidadosamente. Entonces el sonido regresó desde un lugar al que no podía llegar físicamente. El
único plan posible era este: Reconstruyó la identidad del niño olvidado mediante fechas, fotografías
y cartas conservadas. La silla se alejó de la mesa mientras Mara leía la historia verdadera. La
familia recordó al niño que había borrado deliberadamente. Durante unos segundos, el motivo
recurrente se detuvo por completo. En la siguiente cena, un segundo asiento vacío esperaba junto a
Mara. En las horas siguientes, Mara anotó todos los detalles mientras el recuerdo seguía fresco.

---

## Episode Metadata

**Episode:** 080

**Primary title:** El asiento vacío estaba preparado para alguien

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 179

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
