# Episode 088 — La Cámara Nueve mostró a un guardia que no estaba allí

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

La Cámara Nueve mostraba a un guardia caminando por un pasillo que estaba vacío en persona. La
figura seguía rutas de patrulla de antiguos turnos. Cada vez que Noah cambiaba de cámara, el guardia
se acercaba a la sala de control. El comportamiento seguía una regla: La imagen solo podía salir de
la pantalla cuando un guardia real la reconocía. Las grabaciones históricas mostraban al mismo
hombre antes de un accidente mortal. Después, la situación se volvió personal. La figura llevaba el
número de identificación de Noah. Entonces el sonido regresó desde un lugar al que no podía llegar
físicamente. El único plan posible era este: Noah puso en bucle un pasillo vacío y utilizó señales
luminosas en lugar de radio. El falso guardia llegó a la puerta mientras cada monitor mostraba una
posición distinta. Noah cortó el cable físico de la Cámara Nueve sin reconocer los golpes. La imagen
desapareció. El siguiente turno vio a Noah en la Cámara Nueve mientras él estaba de pie a su lado.

---

## Episode Metadata

**Episode:** 088

**Primary title:** La Cámara Nueve mostró a un guardia que no estaba allí

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 169

**Estimated spoken duration:** approximately 55–58 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
