# Episode 082 — El autobús nocturno no tenía última parada

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

El panel dejó atrás la última parada y comenzó a mostrar nombres de personas en lugar de calles. La
advertencia ya estaba allí: No pulses el botón después de que el conductor apague las luces
interiores. Cada pasajero bajaba cuando aparecía su nombre. Nadie recordaba a quienes ya habían
descendido. El comportamiento seguía una regla: El autobús llevaba a las personas a momentos que
lamentaban y cobraba un recuerdo como tarifa. El nombre de Nina apareció junto al hospital donde
murió su madre. Después, la situación se volvió personal. La máquina de billetes imprimió una fecha
de la infancia de Nina. Entonces el sonido regresó desde un lugar al que no podía llegar
físicamente. El único plan posible era este: Pulsó todos los botones a la vez y se negó a nombrar el
lugar al que quería regresar. El autobús recorrió calles desaparecidas mientras los pasajeros le
suplicaban que eligiera. Nina siguió las señales de salida de emergencia en vez del panel. Escapó al
amanecer. Su billete mostraba después un viaje restante sin destino.

---

## Episode Metadata

**Episode:** 082

**Primary title:** El autobús nocturno no tenía última parada

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 174

**Estimated spoken duration:** approximately 56–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
