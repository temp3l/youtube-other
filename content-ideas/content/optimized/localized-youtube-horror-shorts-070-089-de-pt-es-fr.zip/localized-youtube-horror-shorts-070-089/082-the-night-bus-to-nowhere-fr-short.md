# Episode 082 — Le bus de nuit n’avait pas de terminus

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

L’affichage dépassa le terminus et commença à montrer des noms de personnes au lieu des rues.
L’avertissement était déjà présent : N’appuie pas sur le bouton après que le conducteur a éteint les
lumières. Chaque passager descendait lorsque son propre nom apparaissait. Personne ne se souvenait
de ceux qui avaient déjà quitté le bus. Le comportement suivait une règle : Le bus transportait les
gens vers les instants qu’ils regrettaient et exigeait un souvenir comme prix du trajet. Le nom de
Nina apparut à côté de l’hôpital où sa mère était morte. Puis la situation devint personnelle. La
machine à tickets imprima une date de l’enfance de Nina. Puis le son revint d’un endroit qu’il ne
pouvait physiquement atteindre. Le seul plan viable était le suivant : Elle actionna tous les
boutons à la fois et refusa de nommer l’endroit où elle voulait revenir. Le bus traversa des rues
disparues pendant que les passagers la suppliaient de choisir. Nina suivit les panneaux de sortie de
secours plutôt que l’affichage. Elle s’échappa à l’aube. Son ticket indiqua ensuite un dernier
trajet sans destination.

---

## Episode Metadata

**Episode:** 082

**Primary title:** Le bus de nuit n’avait pas de terminus

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 179

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
