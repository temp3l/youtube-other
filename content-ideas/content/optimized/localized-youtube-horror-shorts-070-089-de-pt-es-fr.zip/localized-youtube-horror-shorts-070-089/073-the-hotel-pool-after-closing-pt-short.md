# Episode 073 — Alguém nadava depois do fechamento da piscina

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Depois que a piscina foi trancada, Adrian ouviu alguém nadando. As câmeras mostravam a água se
movendo, mas nenhum nadador. Pegadas molhadas levavam da piscina até quartos ocupados. Os hóspedes
sonhavam com uma criança chamando debaixo d’água. O comportamento seguia uma regra: A presença só
podia sair da piscina por meio de água levada por outra pessoa. Os registros da construção
mencionavam uma criança desaparecida antes da abertura do hotel. Depois disso, a situação se tornou
pessoal. Adrian encontrou uma marca de mão sob o piso de azulejos mais antigo. Então o som voltou de
um lugar ao qual não poderia chegar fisicamente. O único plano possível era este: Ele esvaziou a
piscina, isolou todas as superfícies molhadas e abriu uma escotilha bloqueada sob a parte profunda.
Quando a última água desapareceu, algo se moveu sob os azulejos. Adrian seguiu o apito até um túnel
de serviço e liberou o ar de uma câmara antiga selada. Depois disso, a água permaneceu imóvel.
Naquela noite, Adrian ouviu respingos na banheira vazia do quarto.

---

## Episode Metadata

**Episode:** 073

**Primary title:** Alguém nadava depois do fechamento da piscina

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 172

**Estimated spoken duration:** approximately 56–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
