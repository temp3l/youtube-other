# Localized YouTube Horror Shorts — Episodes 070–089

This package contains 80 localized YouTube Shorts scripts:

- 20 German (`de`)
- 20 Portuguese (`pt`)
- 20 Spanish (`es`)
- 20 French (`fr`)

Episode titles and narration are localized. Production instructions and metadata remain in English.

Narration length is 154–180 words, targeting approximately 50–60 seconds including brief pauses and restrained sound design.
