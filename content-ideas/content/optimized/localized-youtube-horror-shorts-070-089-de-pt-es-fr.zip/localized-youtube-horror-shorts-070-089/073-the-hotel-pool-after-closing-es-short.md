# Episode 073 — Alguien nadaba después del cierre de la piscina

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Después de cerrar la piscina, Adrian oyó a alguien nadar largos. Las cámaras mostraban agua en
movimiento, pero ningún nadador. Huellas mojadas llevaban desde la piscina hasta habitaciones
ocupadas. Los huéspedes soñaban con un niño que los llamaba desde debajo del agua. El comportamiento
seguía una regla: La presencia solo podía salir de la piscina mediante agua transportada por otra
persona. Los registros de construcción mencionaban a un niño desaparecido antes de la apertura del
hotel. Después, la situación se volvió personal. Adrian encontró una huella de mano bajo el suelo de
azulejos más antiguo. Entonces el sonido regresó desde un lugar al que no podía llegar físicamente.
El único plan posible era este: Vació la piscina, aisló todas las superficies mojadas y abrió una
compuerta bloqueada bajo la zona profunda. Cuando desapareció la última capa de agua, algo se movió
bajo los azulejos. Adrian siguió el silbato hasta un túnel y liberó aire de una cámara antigua
sellada. Después, el agua quedó inmóvil. Esa noche, Adrian oyó chapoteos en la bañera vacía de su
habitación.

---

## Episode Metadata

**Episode:** 073

**Primary title:** Alguien nadaba después del cierre de la piscina

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 176

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
