# Episode 087 — Une cloche sonnait sous l’église

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Le clocher était vide, mais une cloche sonnait sous le sol. L’avertissement était déjà présent : Ne
réponds jamais à la cloche souterraine avec celle du clocher. Le son venait d’une crypte scellée.
Après chaque coup, un nom disparaissait du registre paroissial. Le comportement suivait une règle :
La cloche enterrée effaçait toute personne dont le nom n’était pas prononcé avant le coup suivant.
D’anciens plans montraient une chapelle inférieure supprimée de tous les documents ultérieurs. Puis
la situation devint personnelle. Mara vit son propre nom pâlir dans le registre. Puis le son revint
d’un endroit qu’il ne pouvait physiquement atteindre. Le seul plan viable était le suivant : Elle
descendit avec la liste complète des paroissiens effacés et lut chaque nom entre les coups. Les
portes de la crypte se fermèrent tandis que la cloche accélérait. Mara atteignit le dernier nom et
frappa la chaîne avant que son entrée ne disparaisse. Pendant quelques secondes, le motif sonore
s’arrêta complètement. La cloche se tut. Quelques semaines plus tard, un coup résonna sous
l’appartement de Mara.

---

## Episode Metadata

**Episode:** 087

**Primary title:** Une cloche sonnait sous l’église

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 172

**Estimated spoken duration:** approximately 56–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
