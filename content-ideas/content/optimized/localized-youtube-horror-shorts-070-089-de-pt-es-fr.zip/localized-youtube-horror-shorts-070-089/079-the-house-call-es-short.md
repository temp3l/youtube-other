# Episode 079 — El médico fue llamado a una casa vacía

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

La llamada de emergencia procedía de un número desconectado. El paciente era un niño en una casa
abandonada hacía veinte años. Una mujer condujo a Tom hasta un niño sin pulso que aun así pronunció
su nombre. Cada habitación contenía equipo médico de una década distinta. El comportamiento seguía
una regla: La casa repetía tratamientos incompletos hasta que un médico diera el alta oficialmente.
Tom reconoció el caso en unas notas que su padre había ocultado. Después, la situación se volvió
personal. El historial nombraba a Tom como médico años antes de su nacimiento. Entonces el sonido
regresó desde un lugar al que no podía llegar físicamente. El único plan posible era este: Completó
el último paso inofensivo del tratamiento sin firmar el alta. La familia le suplicó que se quedara
mientras la casa cambiaba de década. Tom pronunció el nombre completo del niño, registró la
observación final y dejó el documento sin firmar. La familia desapareció. Más tarde, Tom recibió un
informe de alta firmado por el niño muerto.

---

## Episode Metadata

**Episode:** 079

**Primary title:** El médico fue llamado a una casa vacía

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 170

**Estimated spoken duration:** approximately 55–58 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
