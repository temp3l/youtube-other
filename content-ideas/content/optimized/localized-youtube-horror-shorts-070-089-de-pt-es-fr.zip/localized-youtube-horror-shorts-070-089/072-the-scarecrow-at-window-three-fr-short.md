# Episode 072 — L’épouvantail apparut à la Fenêtre Trois

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

L’épouvantail se tenait devant une fenêtre du troisième étage, sans rebord, arbre ni toit sous lui.
De la paille apparut dans une salle de classe verrouillée depuis le couloir. D’anciens annuaires
montraient le même épouvantail derrière des élèves ensuite disparus. Le comportement suivait une
règle : Il s’approchait lorsqu’un élève mentait et ne reculait que lorsqu’une vérité oubliée était
dite à voix haute. La Fenêtre Trois avait été condamnée après la chute d’un élève plusieurs
décennies auparavant. Puis la situation devint personnelle. Sophie découvrit que le nom de l’élève
disparu avait été découpé de tous les dossiers. Puis le son revint d’un endroit qu’il ne pouvait
physiquement atteindre. Le seul plan viable était le suivant : Elle fixa les noms effacés sur le
manteau de l’épouvantail et ouvrit la fenêtre juste assez pour les lire. L’épouvantail se pencha
dans la classe pendant que des corbeaux frappaient la vitre. Lorsque Sophie prononça le dernier nom,
la silhouette se tourna enfin vers les champs. La paille disparut de l’école. Le soir même, un autre
épouvantail se dressait devant la maison de Sophie.

---

## Episode Metadata

**Episode:** 072

**Primary title:** L’épouvantail apparut à la Fenêtre Trois

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 178

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
