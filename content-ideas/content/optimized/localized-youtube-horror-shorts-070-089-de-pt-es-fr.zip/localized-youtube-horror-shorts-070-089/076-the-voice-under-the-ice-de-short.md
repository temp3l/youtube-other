# Episode 076 — Eine Stimme rief unter dem Eis

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Emma hörte ihren vermissten Bruder unter dem festen Eis rufen. Die Stimme bewegte sich unter ihren
Stiefeln, ohne einen Riss zu hinterlassen. Die Warnung war bereits vorhanden: Antworte niemals einer
Stimme, die nur alte Erinnerungen kennt. Jeder Retter hörte einen anderen verlorenen Angehörigen.
Eine alte Aufnahme enthielt dieselben Stimmen Jahrzehnte zuvor. Das Verhalten folgte einer Regel:
Die Nachahmung konnte Erinnerungen wiederholen, aber keine Informationen kennen, die erst nach der
Ankunft am See entstanden waren. Die Stimmen führten Menschen stets zum dünnsten Eis. Danach wurde
die Situation persönlich. Emma hörte ihren Bruder ein Kinderzimmer beschreiben, setzte aber das
Fenster an die falsche Wand. Dann kehrte das wiederkehrende Geräusch aus einem Ort zurück, den es
physisch nicht erreichen konnte. Der einzige brauchbare Plan lautete: Sie erfand mit dem Team einen
neuen Satz, den jeder echte Retter beantworten musste. Die falschen Stimmen umringten sie, während
das Eis in einem größer werdenden Kreis brach. Emma führte alle nur mithilfe des neuen Satzes ans
Ufer. Für einige Sekunden verstummte das wiederkehrende Motiv vollständig. In derselben Nacht wurde
der Satz unter Emmas Schlafzimmerboden geflüstert.

---

## Episode Metadata

**Episode:** 076

**Primary title:** Eine Stimme rief unter dem Eis

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 178

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
