# Episode 087 — Um sino tocava sob a igreja

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

A torre estava vazia, mas um sino tocava sob o chão. O aviso já estava presente: Nunca responda ao
sino subterrâneo com o sino da torre. O som vinha de uma cripta selada. Depois de cada toque, um
nome desaparecia do registro da paróquia. O comportamento seguia uma regra: O sino enterrado apagava
qualquer pessoa cujo nome não fosse pronunciado antes do toque seguinte. Plantas antigas mostravam
uma capela inferior removida de todos os registros posteriores. Depois disso, a situação se tornou
pessoal. Mara viu o próprio nome desaparecer do livro. Então o som voltou de um lugar ao qual não
poderia chegar fisicamente. O único plano possível era este: Ela desceu com a lista completa dos
paroquianos apagados e leu cada nome entre os toques. As portas da cripta se fecharam enquanto o
sino acelerava. Mara alcançou o último nome e puxou a corrente antes que sua entrada desaparecesse.
Durante alguns segundos, o motivo recorrente parou completamente. O sino ficou em silêncio. Semanas
depois, um toque soou sob o apartamento de Mara.

---

## Episode Metadata

**Episode:** 087

**Primary title:** Um sino tocava sob a igreja

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 173

**Estimated spoken duration:** approximately 56–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
