# Episode 077 — Im Haus warf nichts einen Schatten

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Nach Sonnenuntergang warfen die Möbel keine Schatten mehr. Dann verschwand auch Lukas' eigener
Schatten. Die Warnung war bereits vorhanden: Betritt den Keller niemals ohne zwei Lichtquellen. Auf
Fotos standen dunkle Gestalten dort, wo Schatten hätten sein müssen. Das Haus wurde kälter, sobald
ein weiterer Schatten verschwand. Das Verhalten folgte einer Regel: Das Herrenhaus trennte Menschen
von ihren Schatten und ließ die Schatten frühere Bewohner nachahmen. Jeder frühere Besitzer war
fortgegangen, ohne je wieder gesehen zu werden. Danach wurde die Situation persönlich. Lukas fand
einen Keller voller beweglicher menschlicher Silhouetten. Dann kehrte das wiederkehrende Geräusch
aus einem Ort zurück, den es physisch nicht erreichen konnte. Der einzige brauchbare Plan lautete:
Er richtete gegeneinander gerichtete Flutlichter ein, um jeden Schatten wieder mit seinem Besitzer
zu überlagern. Die Figuren ahmten vermisste Bewohner nach und führten Lukas zum falschen Schatten.
Seinen eigenen erkannte er an einer narbenförmigen Lücke in der Hand. Für einige Sekunden verstummte
das wiederkehrende Motiv vollständig. Vor Tagesanbruch kehrte sein Schatten zurück. Tage später
bewegte er sich eine Sekunde vor Lukas.

---

## Episode Metadata

**Episode:** 077

**Primary title:** Im Haus warf nichts einen Schatten

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 170

**Estimated spoken duration:** approximately 55–58 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
