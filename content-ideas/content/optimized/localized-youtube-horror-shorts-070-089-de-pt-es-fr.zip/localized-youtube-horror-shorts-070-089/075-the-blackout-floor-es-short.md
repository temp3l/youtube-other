# Episode 075 — El ascensor se abrió en la Planta del Apagón

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

El ascensor se abrió entre las plantas dieciocho y diecinueve, en un nivel que solo existía sin
electricidad. La advertencia ya estaba allí: No leas ningún correo de la Planta del Apagón. Las
luces de emergencia revelaron escritorios cubiertos de objetos personales. Cada ordenador mostraba
el último correo nunca enviado de un empleado distinto. El comportamiento seguía una regla: La
planta almacenaba decisiones abandonadas y las utilizaba para impedir que los visitantes se
marcharan. Los planos no mostraban ningún nivel entre el dieciocho y el diecinueve. Después, la
situación se volvió personal. Noah encontró abierto un correo de renuncia suyo que jamás había
escrito. Entonces el sonido regresó desde un lugar al que no podía llegar físicamente. El único plan
posible era este: Restableció corriente únicamente en el circuito de un ascensor, sin activar la red
de oficinas. Cientos de teclados comenzaron a escribir en la oscuridad. Noah llegó al ascensor antes
de que la planta completara su correo. Escapó cuando volvió la electricidad. Más tarde, su tarjeta
le dio acceso a una planta llamada BLACKOUT.

---

## Episode Metadata

**Episode:** 075

**Primary title:** El ascensor se abrió en la Planta del Apagón

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 176

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
