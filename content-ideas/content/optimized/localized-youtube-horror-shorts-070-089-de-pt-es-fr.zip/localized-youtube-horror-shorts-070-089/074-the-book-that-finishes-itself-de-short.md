# Episode 074 — Das Buch schrieb sein eigenes Ende

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Der unvollendete Roman fügte ein Kapitel hinzu, das Mias Tag beschrieb, bevor sie ihn zu Ende erlebt
hatte. Die Warnung war bereits vorhanden: Schlafe niemals im selben Raum wie das Manuskript. Jede
Korrektur von Mia veränderte draußen ein kleines Ereignis. Frühere Lektoren tauchten in späteren
Kapiteln als vermisste Figuren auf. Das Verhalten folgte einer Regel: Das Buch konnte nur
Entscheidungen vorhersagen, die nach dem Lesen getroffen wurden; ungelesene Seiten blieben unsicher.
Das letzte Kapitel war leer, bis auf Mias Namen. Danach wurde die Situation persönlich. Mia
entdeckte, dass jeder Versuch, das Manuskript zu zerstören, bereits in früheren Ausgaben beschrieben
war. Dann kehrte das wiederkehrende Geräusch aus einem Ort zurück, den es physisch nicht erreichen
konnte. Der einzige brauchbare Plan lautete: Sie schrieb mehrere widersprüchliche Enden auf
getrennte Seiten und weigerte sich zu lesen, welches das Buch akzeptierte. Das Archiv veränderte
sich, während die Enden darum kämpften, Wirklichkeit zu werden. Mia schlug das Buch zu, bevor der
letzte Satz beendet war, und sperrte es im Dunkeln ein. Am nächsten Morgen war der Safe leer. Auf
der Titelseite stand Mia als Autorin.

---

## Episode Metadata

**Episode:** 074

**Primary title:** Das Buch schrieb sein eigenes Ende

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 180

**Estimated spoken duration:** approximately 58–62 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
