# Episode 071 — La lavandería solo abría a medianoche

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

La Máquina Siete giraba sin electricidad. Detrás del cristal, Felix vio su propia chaqueta. La
pantalla dejó de mostrar el tiempo restante y enseñó el número del apartamento de Felix. La ropa del
interior pertenecía a personas desaparecidas. El comportamiento seguía una regla: Cada ciclo borraba
un recuerdo del dueño de la ropa. Una mujer junto a una secadora apagada conocía el nombre de Felix,
pero no recordaba el suyo. Después, la situación se volvió personal. Felix olvidó por qué había
entrado y encontró un recibo que mostraba siete ciclos completos. Entonces el sonido regresó desde
un lugar al que no podía llegar físicamente. El único plan posible era este: Cortó el agua, bloqueó
el tambor y forzó la puerta antes de que el contador llegara a cero. Toda la lavandería comenzó a
girar como si el edificio fuera una sola máquina. Felix sacó cada prenda con nombre y los leyó en
voz alta. La lavandería había desaparecido por la mañana. Una moneda marcada con el número siete
seguía apareciendo en el bolsillo de Felix.

---

## Episode Metadata

**Episode:** 071

**Primary title:** La lavandería solo abría a medianoche

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 175

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
