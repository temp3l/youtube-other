# Episode 077 — Nada projetava sombra dentro da casa

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Depois do anoitecer, os móveis pararam de projetar sombras. Então a sombra de Lukas desapareceu. O
aviso já estava presente: Nunca entre no porão sem duas fontes de luz. As fotografias mostravam
figuras escuras onde deveriam existir sombras. A casa ficava mais fria cada vez que outra sombra
desaparecia. O comportamento seguia uma regra: A mansão separava as pessoas de suas sombras e usava
essas sombras para imitar antigos moradores. Todos os proprietários anteriores haviam partido sem
jamais serem vistos novamente. Depois disso, a situação se tornou pessoal. Lukas encontrou um porão
cheio de silhuetas humanas em movimento. Então o som voltou de um lugar ao qual não poderia chegar
fisicamente. O único plano possível era este: Ele usou refletores opostos para forçar cada sombra a
se sobrepor ao dono. As formas imitaram moradores desaparecidos e tentaram levar Lukas à silhueta
errada. Ele reconheceu a própria por uma falha em forma de cicatriz na mão. Durante alguns segundos,
o motivo recorrente parou completamente. Sua sombra voltou antes do amanhecer. Dias depois, começou
a se mover um segundo antes de Lukas.

---

## Episode Metadata

**Episode:** 077

**Primary title:** Nada projetava sombra dentro da casa

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 180

**Estimated spoken duration:** approximately 58–62 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
