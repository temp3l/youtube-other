# Episode 080 — O lugar vazio estava preparado para alguém

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Havia treze lugares para doze convidados. Ninguém conseguia explicar a cadeira vazia. O aviso já
estava presente: Não retire o prato extra antes do sino da meia-noite. A comida desaparecia do prato
intocado. As fotos de família mostravam uma pessoa borrada no mesmo lugar. O comportamento seguia
uma regra: O convidado esquecido ficava mais forte sempre que a família substituía uma memória
verdadeira por uma versão mais confortável. Cada parente lembrava um nome diferente. Depois disso, a
situação se tornou pessoal. Mara encontrou um diário de família com uma página cuidadosamente
arrancada. Então o som voltou de um lugar ao qual não poderia chegar fisicamente. O único plano
possível era este: Ela reconstruiu a identidade da criança esquecida por meio de datas, fotos e
cartas preservadas. A cadeira se afastou da mesa enquanto Mara lia a história verdadeira. A família
se lembrou da criança que havia apagado de propósito. Durante alguns segundos, o motivo recorrente
parou completamente. No jantar seguinte, um segundo lugar vazio esperava ao lado de Mara.

---

## Episode Metadata

**Episode:** 080

**Primary title:** O lugar vazio estava preparado para alguém

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 169

**Estimated spoken duration:** approximately 55–58 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
