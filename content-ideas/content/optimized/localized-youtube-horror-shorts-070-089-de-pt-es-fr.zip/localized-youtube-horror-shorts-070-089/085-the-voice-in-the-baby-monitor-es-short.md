# Episode 085 — Una voz habló a través del vigilabebés

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

El vigilabebés susurró: «No está dormida», mientras Laura sostenía al bebé abajo. La advertencia ya
estaba allí: No respondas después de que diga el nombre del niño. La voz describía movimientos
dentro de una habitación infantil vacía. Las grabaciones mostraban una segunda cuna junto a la
verdadera. El comportamiento seguía una regla: La presencia copiaba rutinas parentales y se
fortalecía cuando alguien seguía sus instrucciones. Los propietarios anteriores habían informado de
la misma nana. Después, la situación se volvió personal. Laura oyó su propia voz prometiendo llevar
al bebé arriba. Entonces el sonido regresó desde un lugar al que no podía llegar físicamente. El
único plan posible era este: Cambió todas las rutinas y creó una frase nueva conocida solo por ella
y su pareja. El monitor dio instrucciones contradictorias mientras unos pasos cruzaban el cuarto.
Laura se negó a entrar hasta oír la respuesta correcta a la frase nueva. Durante unos segundos, el
motivo recurrente se detuvo por completo. La habitación estaba vacía. Después, el dispositivo
apagado reprodujo la frase desde su interior.

---

## Episode Metadata

**Episode:** 085

**Primary title:** Una voz habló a través del vigilabebés

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 174

**Estimated spoken duration:** approximately 56–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
