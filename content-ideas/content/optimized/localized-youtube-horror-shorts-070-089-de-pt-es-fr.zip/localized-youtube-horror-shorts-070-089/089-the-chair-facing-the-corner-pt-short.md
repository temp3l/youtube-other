# Episode 089 — A cadeira se virou para a sala

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

A cadeira sempre ficava voltada para o canto. Cada vez que Emma voltava, ela estava um pouco mais
virada para a sala. As marcas na poeira mostravam que ela se movia sem deslizar pelo chão. As
fotografias mostravam uma figura sentada apenas quando a cadeira estava voltada para a câmera. O
comportamento seguia uma regra: A cadeira se virava para a pessoa que passava mais tempo
observando-a. Os antigos proprietários haviam retirado todas as outras cadeiras. Depois disso, a
situação se tornou pessoal. Emma encontrou nomes gravados sob o assento, incluindo o seu. Então o
som voltou de um lugar ao qual não poderia chegar fisicamente. O único plano possível era este: Ela
posicionou espelhos para que a cadeira parecesse olhar para si mesma e saiu sem se virar. A cadeira
raspou o chão enquanto os espelhos quebravam um a um. Emma seguiu o som sem olhar para trás e
trancou a sala por fora. Na manhã seguinte, a cadeira havia desaparecido. Agora havia uma cadeira
voltada para o canto do quarto de Emma.

---

## Episode Metadata

**Episode:** 089

**Primary title:** A cadeira se virou para a sala

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 174

**Estimated spoken duration:** approximately 56–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
