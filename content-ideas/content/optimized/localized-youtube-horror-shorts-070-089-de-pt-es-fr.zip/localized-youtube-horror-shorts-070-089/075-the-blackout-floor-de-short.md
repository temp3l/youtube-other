# Episode 075 — Der Aufzug öffnete sich auf der Blackout-Etage

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Der Aufzug öffnete sich zwischen dem achtzehnten und neunzehnten Stock auf einer Etage, die nur ohne
Strom existierte. Die Warnung war bereits vorhanden: Lies keine E-Mail auf der Blackout-Etage.
Notbeleuchtung zeigte Schreibtische voller persönlicher Gegenstände von Angestellten. Jeder Computer
zeigte die letzte, nie gesendete E-Mail eines anderen Menschen. Das Verhalten folgte einer Regel:
Die Etage bewahrte Entscheidungen auf, die Menschen aufgegeben hatten, und benutzte sie, um Besucher
festzuhalten. In den Bauplänen gab es keinen Stock zwischen achtzehn und neunzehn. Danach wurde die
Situation persönlich. Noah fand seine eigene Kündigungsmail geöffnet auf einem Schreibtisch, obwohl
er sie nie geschrieben hatte. Dann kehrte das wiederkehrende Geräusch aus einem Ort zurück, den es
physisch nicht erreichen konnte. Der einzige brauchbare Plan lautete: Er versorgte nur einen
Aufzugskreis mit Strom, ohne das Büronetz zu aktivieren. Auf Hunderten dunklen Schreibtischen begann
gleichzeitig das Tippen. Noah erreichte den Aufzug, bevor die Etage seine E-Mail vollenden konnte.
Für einige Sekunden verstummte das wiederkehrende Motiv vollständig. Er entkam, als der Stadtstrom
zurückkehrte. Später gewährte ihm sein Ausweis Zugang zu einer Etage namens BLACKOUT.

---

## Episode Metadata

**Episode:** 075

**Primary title:** Der Aufzug öffnete sich auf der Blackout-Etage

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 175

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
