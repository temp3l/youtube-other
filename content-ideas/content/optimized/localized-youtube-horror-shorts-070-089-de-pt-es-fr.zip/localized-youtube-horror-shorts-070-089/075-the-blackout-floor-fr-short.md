# Episode 075 — L’ascenseur s’ouvrit sur l’Étage Blackout

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

L’ascenseur s’ouvrit entre les dix-huitième et dix-neuvième étages, sur un niveau qui n’existait que
sans électricité. L’avertissement était déjà présent : Ne lis aucun courriel affiché à l’Étage
Blackout. Les lumières de secours révélèrent des bureaux couverts d’objets personnels. Chaque
ordinateur affichait le dernier courriel jamais envoyé d’un employé différent. Le comportement
suivait une règle : L’étage conservait les décisions abandonnées et s’en servait pour empêcher les
visiteurs de partir. Les plans ne montraient aucun niveau entre les étages dix-huit et dix-neuf.
Puis la situation devint personnelle. Noah trouva son propre courriel de démission ouvert sur un
bureau, alors qu’il ne l’avait jamais écrit. Puis le son revint d’un endroit qu’il ne pouvait
physiquement atteindre. Le seul plan viable était le suivant : Il rétablit le courant uniquement
dans un circuit d’ascenseur sans alimenter le réseau de bureaux. Des centaines de claviers
commencèrent à taper dans l’obscurité. Noah atteignit la cabine avant que l’étage ne termine son
message. Il s’échappa lorsque le courant revint. Plus tard, son badge lui donna accès à un étage
nommé BLACKOUT.

---

## Episode Metadata

**Episode:** 075

**Primary title:** L’ascenseur s’ouvrit sur l’Étage Blackout

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 173

**Estimated spoken duration:** approximately 56–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
