# Episode 088 — La Caméra Neuf montra un gardien absent

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

La Caméra Neuf montrait un gardien marchant dans un couloir qui était vide en réalité.
L’avertissement était déjà présent : Ne parle jamais au gardien par radio. La silhouette suivait les
itinéraires d’anciens plannings. Chaque fois que Noah changeait de caméra, le gardien se rapprochait
de la salle de contrôle. Le comportement suivait une règle : L’image ne pouvait quitter l’écran que
lorsqu’un vrai gardien la reconnaissait. Les archives montraient le même homme avant un ancien
accident mortel. Puis la situation devint personnelle. La silhouette portait le numéro de badge de
Noah. Puis le son revint d’un endroit qu’il ne pouvait physiquement atteindre. Le seul plan viable
était le suivant : Noah mit en boucle l’image d’un couloir vide et utilisa des signaux lumineux
plutôt que la radio. Le faux gardien atteignit la porte alors que chaque écran indiquait un
emplacement différent. Noah coupa le câble physique de la Caméra Neuf sans répondre aux coups.
Pendant quelques secondes, le motif sonore s’arrêta complètement. L’image disparut. L’équipe
suivante vit Noah sur la Caméra Neuf alors qu’il se tenait à côté d’eux.

---

## Episode Metadata

**Episode:** 088

**Primary title:** La Caméra Neuf montra un gardien absent

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 177

**Estimated spoken duration:** approximately 57–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
