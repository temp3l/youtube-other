# Episode 076 — Uma voz chamava debaixo do gelo

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Emma ouviu o irmão desaparecido chamando sob o gelo sólido. A voz se movia sob suas botas sem abrir
rachaduras. O aviso já estava presente: Nunca responda a uma voz que conhece apenas memórias
antigas. Cada socorrista ouvia um parente perdido diferente. Uma gravação antiga continha as mesmas
vozes décadas antes. O comportamento seguia uma regra: A imitação podia repetir lembranças, mas não
responder com informações criadas depois da chegada ao lago. As vozes sempre conduziam ao gelo mais
fino. Depois disso, a situação se tornou pessoal. Emma ouviu o irmão descrever o quarto de infância,
mas ele colocou a janela na parede errada. Então o som voltou de um lugar ao qual não poderia chegar
fisicamente. O único plano possível era este: Ela criou uma frase nova com a equipe, que todo
socorrista verdadeiro precisava responder. As vozes falsas os cercaram enquanto o gelo se partia em
um círculo crescente. Emma guiou todos até a margem usando apenas a frase nova. Naquela noite, a
frase foi sussurrada debaixo do piso do quarto de Emma.

---

## Episode Metadata

**Episode:** 076

**Primary title:** Uma voz chamava debaixo do gelo

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 175

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
