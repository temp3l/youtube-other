# Episode 081 — La pièce répondit avant qu’il ne parle

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Daniel demanda si quelqu’un se trouvait dans la pièce. Elle répondit avant qu’il ait terminé.
L’avertissement était déjà présent : Ne pose jamais une question contenant ton propre nom. Les
enregistrements captaient des réponses plusieurs secondes avant que Daniel ne parle. Les réponses
devenaient plus précises chaque fois qu’il revenait seul. Le comportement suivait une règle : La
pièce apprenait les questions possibles et poussait les visiteurs vers la version à laquelle elle
avait déjà répondu. De vieux dossiers décrivaient des sujets repartis avec le souvenir de
conversations jamais vécues. Puis la situation devint personnelle. Daniel entendit sa propre voix
avouer un événement qu’il n’avait jamais connu. Puis le son revint d’un endroit qu’il ne pouvait
physiquement atteindre. Le seul plan viable était le suivant : Il prépara plusieurs questions aux
réponses incompatibles et les diffusa simultanément. La pièce tenta de répondre à toutes, et les
murs répétèrent plusieurs futurs. Daniel suivit la seule réponse comportant un défaut acoustique que
la salle ne savait jamais reproduire. Il s’échappa. Par la suite, chaque pièce vide répondit à sa
première pensée par un léger coup.

---

## Episode Metadata

**Episode:** 081

**Primary title:** La pièce répondit avant qu’il ne parle

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 180

**Estimated spoken duration:** approximately 58–62 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
