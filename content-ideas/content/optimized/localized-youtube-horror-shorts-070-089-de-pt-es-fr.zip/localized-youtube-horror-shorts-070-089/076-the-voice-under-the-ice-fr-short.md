# Episode 076 — Une voix appelait sous la glace

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Emma entendit son frère disparu l’appeler sous la glace solide. La voix se déplaçait sous ses bottes
sans produire de fissure. L’avertissement était déjà présent : Ne réponds jamais à une voix qui ne
connaît que d’anciens souvenirs. Chaque secouriste entendait un proche disparu différent. Un vieil
enregistrement contenait les mêmes voix plusieurs décennies auparavant. Le comportement suivait une
règle : L’imitation pouvait répéter des souvenirs, mais pas répondre avec des informations créées
après l’arrivée au lac. Les voix conduisaient toujours vers la glace la plus mince. Puis la
situation devint personnelle. Emma entendit son frère décrire leur chambre d’enfance, mais placer la
fenêtre sur le mauvais mur. Puis le son revint d’un endroit qu’il ne pouvait physiquement atteindre.
Le seul plan viable était le suivant : Elle inventa avec l’équipe une nouvelle phrase à laquelle
chaque véritable secouriste devait répondre. Les fausses voix les encerclèrent tandis que la glace
se fissurait en cercle. Emma guida l’équipe vers la rive uniquement grâce à la nouvelle phrase.
Cette nuit-là, la phrase fut murmurée sous le plancher de sa chambre.

---

## Episode Metadata

**Episode:** 076

**Primary title:** Une voix appelait sous la glace

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 175

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
