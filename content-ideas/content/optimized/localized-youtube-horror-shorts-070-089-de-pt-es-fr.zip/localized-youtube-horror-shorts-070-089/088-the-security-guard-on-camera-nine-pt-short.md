# Episode 088 — A Câmera Nove mostrou um guarda que não estava ali

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

A Câmera Nove mostrava um guarda caminhando por um corredor que estava vazio pessoalmente. O aviso
já estava presente: Nunca fale com o guarda pelo rádio. A figura seguia rotas de patrulha de turnos
antigos. Sempre que Noah mudava de câmera, o guarda se aproximava da sala de controle. O
comportamento seguia uma regra: A imagem só podia sair da tela quando um guarda real reconhecia sua
presença. As gravações antigas mostravam o mesmo homem antes de um acidente fatal. Depois disso, a
situação se tornou pessoal. A figura usava o número do crachá de Noah. Então o som voltou de um
lugar ao qual não poderia chegar fisicamente. O único plano possível era este: Noah colocou em loop
um corredor vazio e usou sinais de luz em vez do rádio. O falso guarda alcançou a porta enquanto
cada monitor mostrava uma posição diferente. Noah cortou o cabo físico da Câmera Nove sem responder
às batidas. A imagem desapareceu. A equipe seguinte viu Noah na Câmera Nove enquanto ele estava ao
lado deles.

---

## Episode Metadata

**Episode:** 088

**Primary title:** A Câmera Nove mostrou um guarda que não estava ali

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 173

**Estimated spoken duration:** approximately 56–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
