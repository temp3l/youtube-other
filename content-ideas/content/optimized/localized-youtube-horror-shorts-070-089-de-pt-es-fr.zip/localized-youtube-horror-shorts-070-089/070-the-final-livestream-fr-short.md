# Episode 070 — Son livestream a continué après sa disparition

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Les commentaires avertissaient Laura au sujet de pièces qu’elle n’avait pas encore atteintes. Treize
minutes plus tard, chaque avertissement se réalisait. Un second angle de caméra apparut dans le
direct alors que Laura n’avait emporté qu’une seule caméra. Le comportement suivait une règle : Le
direct avait exactement treize minutes de retard, et tout ce que montrait l’angle alternatif
devenait inévitable si Laura ne changeait pas de direction à temps. Puis la situation devint
personnelle. L’angle alternatif montrait une silhouette suivant Laura, tandis que sa vraie caméra
filmait un corridor vide. Le seul plan viable était le suivant : Laura simula un faux trajet devant
la caméra et se dirigea vers une sortie que le second angle n’avait pas montrée. La silhouette
apparut sur les deux flux à la fois. Laura éteignit les lumières, suivit les commentaires les plus
anciens et atteignit le quai de chargement avant que le retard ne la rattrape. Le direct se coupa
lorsqu’elle s’échappa. Sa chaîne continua pourtant à diffuser depuis l’hôpital, avec Laura toujours
à l’écran.

---

## Episode Metadata

**Episode:** 070

**Primary title:** Son livestream a continué après sa disparition

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 170

**Estimated spoken duration:** approximately 55–58 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
