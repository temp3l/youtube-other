# Episode 089 — La silla se volvió hacia la habitación

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

La silla siempre miraba hacia la esquina. Cada vez que Emma regresaba, se había girado un poco más
hacia la habitación. Las marcas de polvo mostraban que se movía sin deslizarse por el suelo. En las
fotografías aparecía una figura sentada únicamente cuando la silla miraba a la cámara. El
comportamiento seguía una regla: La silla se volvía hacia la persona que más tiempo la observaba.
Los dueños anteriores habían retirado todas las demás sillas. Después, la situación se volvió
personal. Emma encontró nombres grabados bajo el asiento, incluido el suyo. Entonces el sonido
regresó desde un lugar al que no podía llegar físicamente. El único plan posible era este: Colocó
espejos para que la silla pareciera mirarse a sí misma y salió sin volver la cabeza. La silla raspó
el suelo mientras los espejos se rompían uno a uno. Emma siguió el sonido sin mirar atrás y cerró la
habitación desde fuera. A la mañana siguiente la silla había desaparecido. Ahora una silla miraba
hacia la esquina del dormitorio de Emma.

---

## Episode Metadata

**Episode:** 089

**Primary title:** La silla se volvió hacia la habitación

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 172

**Estimated spoken duration:** approximately 56–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
