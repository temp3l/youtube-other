# Episode 086 — Une maison apparut dans la tempête

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Une maison entière apparut dans la cellule orageuse sur le radar et se déplaçait contre le vent. La
maison apparut brièvement sur des caméras routières là où aucun bâtiment n’existait. Chaque pièce
contenait des lumières correspondant à des maisons perdues lors d’anciennes catastrophes. Le
comportement suivait une règle : La tempête collectait les bâtiments abandonnés pendant les urgences
et les reconstruisait autour de nouveaux témoins. Les archives radar montraient la même maison avant
d’autres disparitions. Puis la situation devint personnelle. Adrian vit sa maison d’enfance par une
fenêtre. Puis le son revint d’un endroit qu’il ne pouvait physiquement atteindre. Le seul plan
viable était le suivant : Il calcula la rotation et s’approcha depuis la seule direction vers
laquelle la maison ne pouvait pas faire face. La maison pivota pièce après pièce tandis que des voix
appelaient à l’intérieur. Adrian nota les coordonnées et traversa la trajectoire avant la fin du
mouvement. La tempête s’effondra. Plus tard, une carte météo montra le symbole d’une maison sur
l’adresse actuelle d’Adrian.

---

## Episode Metadata

**Episode:** 086

**Primary title:** Une maison apparut dans la tempête

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 167

**Estimated spoken duration:** approximately 54–57 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
