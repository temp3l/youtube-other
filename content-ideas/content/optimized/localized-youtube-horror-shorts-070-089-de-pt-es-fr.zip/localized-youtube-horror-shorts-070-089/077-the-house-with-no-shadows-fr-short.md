# Episode 077 — Rien ne projetait d’ombre dans la maison

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Après le coucher du soleil, les meubles cessèrent de projeter des ombres. Puis l’ombre de Lukas
disparut. L’avertissement était déjà présent : N’entre jamais dans la cave sans deux sources de
lumière. Les photographies montraient des silhouettes sombres à la place des ombres. La maison
devenait plus froide chaque fois qu’une nouvelle ombre disparaissait. Le comportement suivait une
règle : Le manoir séparait les personnes de leurs ombres, puis utilisait celles-ci pour imiter
d’anciens habitants. Tous les anciens propriétaires étaient partis sans jamais être revus. Puis la
situation devint personnelle. Lukas trouva une cave remplie de silhouettes humaines mouvantes. Puis
le son revint d’un endroit qu’il ne pouvait physiquement atteindre. Le seul plan viable était le
suivant : Il utilisa des projecteurs opposés pour forcer chaque ombre à recouvrir son propriétaire.
Les formes imitèrent des résidents disparus et tentèrent de conduire Lukas vers la mauvaise
silhouette. Il reconnut la sienne grâce à une lacune en forme de cicatrice dans la main. Son ombre
revint avant l’aube. Quelques jours plus tard, elle commença à bouger une seconde avant lui.

---

## Episode Metadata

**Episode:** 077

**Primary title:** Rien ne projetait d’ombre dans la maison

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 175

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
