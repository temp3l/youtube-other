# Episode 084 — Le téléphone sonna dans une tombe

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Un téléphone portable sonna sous une tombe scellée depuis trente ans. L’avertissement était déjà
présent : Ne réponds jamais avec ton propre nom. L’appelant connaissait des détails sur des
enterrements récents. Chaque appel venait d’une tombe différente, mais affichait le même numéro. Le
comportement suivait une règle : La voix ne pouvait sortir que si une personne vivante
s’identifiait. D’anciens registres mentionnaient la même sonnerie avant plusieurs disparitions. Puis
la situation devint personnelle. Sophie entendit la voix de son père mort demander qui avait
répondu. Puis le son revint d’un endroit qu’il ne pouvait physiquement atteindre. Le seul plan
viable était le suivant : Elle donna le nom gravé sur la tombe au lieu du sien. Des téléphones se
mirent à sonner sous chaque rangée. Sophie suivit la seule tombe silencieuse et débrancha un câble
enterré sans source d’énergie. Pendant quelques secondes, le motif sonore s’arrêta complètement. La
sonnerie cessa. Cette nuit-là, le téléphone de Sophie reçut un appel depuis sa propre parcelle vide.
L’histoire reste troublante parce que la dernière preuve ne montrait pas une fuite parfaite, mais
une adaptation.

---

## Episode Metadata

**Episode:** 084

**Primary title:** Le téléphone sonna dans une tombe

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 178

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
