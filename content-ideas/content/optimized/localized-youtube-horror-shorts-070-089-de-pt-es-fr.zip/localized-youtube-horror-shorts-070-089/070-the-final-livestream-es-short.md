# Episode 070 — Su transmisión continuó después de que desapareciera

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Los comentarios advertían a Laura sobre habitaciones a las que aún no había llegado. Trece minutos
después, cada advertencia se cumplía. En la emisión apareció un segundo ángulo de cámara, aunque
Laura solo llevaba una. Cuentas pertenecientes a personas desaparecidas comenzaron a comentar en
tiempo real. El comportamiento seguía una regla: La transmisión tenía exactamente trece minutos de
retraso, y todo lo mostrado por la cámara alternativa se volvía inevitable si Laura no cambiaba de
rumbo a tiempo. Después, la situación se volvió personal. El ángulo alternativo mostraba una figura
siguiendo a Laura, mientras la cámara real grababa un corredor vacío. El único plan posible era
este: Laura fingió una ruta falsa ante la cámara y avanzó hacia una salida que el segundo ángulo no
había mostrado. La figura apareció en ambas imágenes al mismo tiempo. Laura apagó las luces, siguió
los comentarios más antiguos y llegó al muelle de carga antes de que el retraso la alcanzara. La
emisión se cortó cuando Laura escapó. Su canal siguió transmitiendo desde el hospital, con Laura
todavía en pantalla.

---

## Episode Metadata

**Episode:** 070

**Primary title:** Su transmisión continuó después de que desapareciera

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 177

**Estimated spoken duration:** approximately 57–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
