# Episode 081 — La habitación respondió antes de que hablara

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Daniel preguntó si había alguien dentro. La habitación respondió antes de que terminara la pregunta.
La advertencia ya estaba allí: Nunca hagas una pregunta que contenga tu propio nombre. Las
grabaciones captaban respuestas varios segundos antes de que Daniel hablara. Las respuestas se
volvían más precisas cada vez que regresaba solo. El comportamiento seguía una regla: La habitación
aprendía preguntas posibles y obligaba a los visitantes a entrar en la versión que ya había
respondido. Archivos antiguos describían sujetos que salían con recuerdos de conversaciones nunca
ocurridas. Después, la situación se volvió personal. Daniel oyó su propia voz confesando un hecho
que jamás había vivido. Entonces el sonido regresó desde un lugar al que no podía llegar
físicamente. El único plan posible era este: Preparó varias preguntas con respuestas incompatibles y
las reprodujo a la vez. La habitación intentó responderlas todas, y las paredes repitieron futuros
distintos. Daniel siguió la única respuesta con un error acústico que la sala nunca podía copiar
correctamente. Escapó. Después, cada habitación vacía respondía a su primer pensamiento con un golpe
suave.

---

## Episode Metadata

**Episode:** 081

**Primary title:** La habitación respondió antes de que hablara

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 177

**Estimated spoken duration:** approximately 57–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
