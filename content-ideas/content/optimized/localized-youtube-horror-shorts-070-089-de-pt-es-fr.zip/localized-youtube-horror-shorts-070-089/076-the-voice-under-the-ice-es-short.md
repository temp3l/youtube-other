# Episode 076 — Una voz llamaba desde debajo del hielo

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Emma oyó a su hermano desaparecido llamarla desde debajo del hielo sólido. La voz se movía bajo sus
botas sin abrir grietas. Cada rescatista escuchaba a un familiar perdido diferente. Una grabación
antigua contenía las mismas voces décadas atrás. El comportamiento seguía una regla: La imitación
podía repetir recuerdos, pero no responder con información creada después de llegar al lago. Las
voces siempre conducían hacia el hielo más delgado. Después, la situación se volvió personal. Emma
oyó a su hermano describir su habitación infantil, pero colocó la ventana en la pared equivocada.
Entonces el sonido regresó desde un lugar al que no podía llegar físicamente. El único plan posible
era este: Creó una frase nueva con el equipo que todo rescatista real debía responder. Las voces
falsas los rodearon mientras el hielo se rompía en un círculo creciente. Emma condujo al equipo
hacia la orilla usando solo la frase nueva. Esa noche, la frase fue susurrada desde debajo del suelo
de su dormitorio. En las horas siguientes, Emma anotó todos los detalles mientras el recuerdo seguía
fresco.

---

## Episode Metadata

**Episode:** 076

**Primary title:** Una voz llamaba desde debajo del hielo

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 177

**Estimated spoken duration:** approximately 57–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
