# Episode 074 — Le livre écrivit sa propre fin

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Le roman inachevé ajouta un chapitre décrivant la journée de Mia avant qu’elle ne l’ait terminée.
L’avertissement était déjà présent : Ne t’endors jamais dans la même pièce que le manuscrit. Chaque
correction de Mia modifiait un petit événement à l’extérieur des archives. D’anciens éditeurs
apparaissaient dans les chapitres suivants comme des personnages disparus. Le comportement suivait
une règle : Le livre ne pouvait prédire que les décisions prises après leur lecture ; les pages non
lues restaient incertaines. Le dernier chapitre était vide, à l’exception du nom de Mia. Puis la
situation devint personnelle. Mia découvrit que chaque tentative de destruction figurait déjà dans
des éditions antérieures. Puis le son revint d’un endroit qu’il ne pouvait physiquement atteindre.
Le seul plan viable était le suivant : Elle écrivit plusieurs fins contradictoires sur des pages
séparées et refusa de lire celle que le livre accepterait. Les archives changèrent pendant que les
différentes fins tentaient de devenir réelles. Mia referma le livre avant la dernière phrase et
l’enferma dans l’obscurité. Le coffre était vide le lendemain matin. La page de titre indiquait Mia
comme auteure.

---

## Episode Metadata

**Episode:** 074

**Primary title:** Le livre écrivit sa propre fin

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 180

**Estimated spoken duration:** approximately 58–62 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
