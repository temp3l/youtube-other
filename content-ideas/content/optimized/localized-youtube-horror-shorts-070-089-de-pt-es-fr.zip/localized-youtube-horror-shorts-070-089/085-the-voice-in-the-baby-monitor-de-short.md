# Episode 085 — Eine Stimme sprach durch das Babyphone

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Das Babyphone flüsterte: »Sie schläft nicht«, während Laura das Baby unten im Arm hielt. Die Warnung
war bereits vorhanden: Antworte dem Babyphone nicht, nachdem es den Namen des Kindes gesagt hat. Die
Stimme beschrieb Bewegungen in einem leeren Kinderzimmer. Aufnahmen zeigten neben dem echten Bett
ein zweites Kinderbett. Das Verhalten folgte einer Regel: Die Präsenz kopierte elterliche Routinen
und wurde stärker, wenn jemand ihren Anweisungen folgte. Frühere Bewohner hatten dasselbe Schlaflied
gemeldet. Danach wurde die Situation persönlich. Laura hörte ihre eigene Stimme versprechen, das
Baby nach oben zu bringen. Dann kehrte das wiederkehrende Geräusch aus einem Ort zurück, den es
physisch nicht erreichen konnte. Der einzige brauchbare Plan lautete: Sie änderte jede Abendroutine
und benutzte einen neuen Satz, den nur sie und ihr Partner kannten. Das Babyphone gab
widersprüchliche Anweisungen, während Schritte durch das Kinderzimmer gingen. Laura betrat es erst,
als der neue Satz richtig beantwortet wurde. Für einige Sekunden verstummte das wiederkehrende Motiv
vollständig. Der Raum war leer. Später spielte das ausgeschaltete Babyphone den neuen Satz aus
seinem Inneren ab.

---

## Episode Metadata

**Episode:** 085

**Primary title:** Eine Stimme sprach durch das Babyphone

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 171

**Estimated spoken duration:** approximately 55–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
