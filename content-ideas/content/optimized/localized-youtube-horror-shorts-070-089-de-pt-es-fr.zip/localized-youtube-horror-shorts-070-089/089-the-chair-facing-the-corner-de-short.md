# Episode 089 — Der Stuhl drehte sich zum Raum

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Der Stuhl stand immer zur Ecke. Bei jedem Besuch war er ein Stück weiter in den Raum gedreht.
Staubspuren zeigten, dass er sich bewegte, ohne über den Boden zu rutschen. Auf Fotos erschien eine
sitzende Gestalt nur dann, wenn der Stuhl zur Kamera zeigte. Das Verhalten folgte einer Regel: Der
Stuhl drehte sich zu der Person, die ihn am längsten beobachtete. Frühere Besitzer hatten alle
anderen Stühle aus dem Haus entfernt. Danach wurde die Situation persönlich. Emma fand unter der
Sitzfläche eingeritzte Namen, darunter ihren eigenen. Dann kehrte das wiederkehrende Geräusch aus
einem Ort zurück, den es physisch nicht erreichen konnte. Der einzige brauchbare Plan lautete: Sie
stellte Spiegel so auf, dass der Stuhl sich selbst gegenüberstand, und verließ den Raum, ohne sich
umzudrehen. Der Stuhl schabte über den Boden, während die Spiegel einer nach dem anderen zerbrachen.
Emma folgte dem Geräusch, ohne zurückzusehen, und schloss den Raum von außen ab. Am Morgen war der
Stuhl verschwunden. Nun stand einer in der Ecke von Emmas Schlafzimmer.

---

## Episode Metadata

**Episode:** 089

**Primary title:** Der Stuhl drehte sich zum Raum

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 166

**Estimated spoken duration:** approximately 54–57 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
