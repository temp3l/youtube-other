# Episode 070 — Ihr Livestream lief weiter, nachdem sie verschwunden war

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Die Kommentare warnten Laura vor Räumen, die sie noch gar nicht erreicht hatte. Dreizehn Minuten
später traf jede Warnung ein. Im Stream erschien plötzlich eine zweite Kameraperspektive, obwohl
Laura nur eine Kamera dabeihatte. Konten von vermissten Personen begannen in Echtzeit zu
kommentieren. Das Verhalten folgte einer Regel: Der Stream war exakt dreizehn Minuten verzögert, und
alles, was die zweite Kamera zeigte, wurde unvermeidlich, wenn Laura den Kurs nicht rechtzeitig
änderte. Danach wurde die Situation persönlich. Die zweite Perspektive zeigte eine Gestalt hinter
Laura, während ihre echte Kamera nur einen leeren Flur aufnahm. Dann kehrte das wiederkehrende
Geräusch aus einem Ort zurück, den es physisch nicht erreichen konnte. Der einzige brauchbare Plan
lautete: Laura täuschte auf der Kamera einen falschen Weg vor und bewegte sich zu einem Ausgang, den
die zweite Perspektive nicht gezeigt hatte. Die Gestalt erschien gleichzeitig in beiden Bildern.
Laura löschte das Licht, folgte den frühesten Kommentaren und erreichte die Laderampe, bevor die
Verzögerung sie einholte. Der Stream brach ab, als Laura entkam. Ihr Kanal sendete jedoch weiter aus
dem Krankenhaus – mit Laura noch immer im Bild.

---

## Episode Metadata

**Episode:** 070

**Primary title:** Ihr Livestream lief weiter, nachdem sie verschwunden war

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 179

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
