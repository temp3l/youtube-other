# Episode 082 — O ônibus noturno não tinha ponto final

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

O painel passou do ponto final e começou a mostrar nomes de pessoas em vez de ruas. O aviso já
estava presente: Não aperte o botão depois que o motorista apagar as luzes internas. Cada passageiro
descia quando o próprio nome aparecia. Ninguém se lembrava de quem já havia saído. O comportamento
seguia uma regra: O ônibus levava as pessoas a momentos de arrependimento e cobrava uma memória como
passagem. O nome de Nina apareceu ao lado do hospital onde sua mãe morreu. Depois disso, a situação
se tornou pessoal. A máquina de bilhetes imprimiu uma data da infância de Nina. Então o som voltou
de um lugar ao qual não poderia chegar fisicamente. O único plano possível era este: Ela apertou
todos os botões ao mesmo tempo e se recusou a dizer para onde queria voltar. O ônibus atravessou
ruas que não existiam mais enquanto os passageiros imploravam para que Nina escolhesse. Ela seguiu
as placas de saída de emergência, não o painel. Ela escapou ao amanhecer. O bilhete depois mostrou
uma viagem restante sem destino.

---

## Episode Metadata

**Episode:** 082

**Primary title:** O ônibus noturno não tinha ponto final

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 177

**Estimated spoken duration:** approximately 57–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
