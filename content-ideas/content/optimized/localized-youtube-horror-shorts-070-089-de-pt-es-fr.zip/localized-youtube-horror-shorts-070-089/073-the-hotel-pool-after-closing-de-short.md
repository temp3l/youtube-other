# Episode 073 — Nach Schließung schwamm noch jemand im Pool

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Nachdem der Pool abgeschlossen war, hörte Adrian jemanden Bahnen ziehen. Die Kamera zeigte bewegtes
Wasser, aber keinen Schwimmer. Die Warnung war bereits vorhanden: Antworte nach Schließung niemals
auf den Pfiff. Nasse Fußspuren führten vom Pool zu belegten Zimmern. Gäste träumten von einem Kind,
das sie unter Wasser rief. Das Verhalten folgte einer Regel: Die Erscheinung konnte den Pool nur
über Wasser verlassen, das jemand mitnahm. Bauunterlagen erwähnten ein Kind, das vor der Eröffnung
des Hotels verschwunden war. Danach wurde die Situation persönlich. Adrian fand unter dem ältesten
Fliesenboden des Pools einen Handabdruck. Dann kehrte das wiederkehrende Geräusch aus einem Ort
zurück, den es physisch nicht erreichen konnte. Der einzige brauchbare Plan lautete: Er ließ das
Becken ab, isolierte alle nassen Flächen und öffnete eine blockierte Wartungsluke unter dem tiefen
Ende. Als das letzte Wasser verschwand, bewegte sich etwas unter den Fliesen. Adrian folgte dem
Pfiff in einen Wartungstunnel und ließ Luft aus einer älteren versiegelten Kammer entweichen. Für
einige Sekunden verstummte das wiederkehrende Motiv vollständig. Danach blieb das Wasser still. In
derselben Nacht hörte Adrian Planschen aus seiner leeren Badewanne.

---

## Episode Metadata

**Episode:** 073

**Primary title:** Nach Schließung schwamm noch jemand im Pool

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 180

**Estimated spoken duration:** approximately 58–62 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
