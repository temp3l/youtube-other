# Episode 072 — O espantalho apareceu na Janela Três

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

O espantalho estava diante de uma janela do terceiro andar, sem beiral, árvore ou telhado por baixo.
Palha apareceu dentro de uma sala trancada pelo corredor. Anuários antigos mostravam o mesmo
espantalho atrás de alunos que depois desapareceram. O comportamento seguia uma regra: Ele se
aproximava quando um aluno mentia e só recuava quando uma verdade esquecida era dita em voz alta. A
Janela Três havia sido selada depois da queda de um estudante décadas antes. Depois disso, a
situação se tornou pessoal. Sophie descobriu que o nome do aluno desaparecido havia sido recortado
de todos os arquivos. Então o som voltou de um lugar ao qual não poderia chegar fisicamente. O único
plano possível era este: Ela prendeu os nomes apagados no casaco do espantalho e abriu a janela
apenas o suficiente para lê-los. O espantalho se inclinou para dentro enquanto corvos batiam no
vidro. Quando Sophie disse o último nome, a figura se virou para o campo. A palha desapareceu da
escola. Naquela noite, outro espantalho estava diante da casa de Sophie.

---

## Episode Metadata

**Episode:** 072

**Primary title:** O espantalho apareceu na Janela Três

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 174

**Estimated spoken duration:** approximately 56–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
