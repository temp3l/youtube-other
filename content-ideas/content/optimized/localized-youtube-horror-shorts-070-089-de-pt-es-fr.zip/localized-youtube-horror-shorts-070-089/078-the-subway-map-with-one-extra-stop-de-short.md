# Episode 078 — Der U-Bahn-Plan zeigte eine zusätzliche Station

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Zwischen zwei bekannten Haltestellen erschien eine neue Station. Ihr Name war LETZTES ZUHAUSE.
Fahrgäste, die den dunklen Bahnsteig betraten, verschwanden aus der Erinnerung aller anderen. Claras
Handy enthielt Fotos von ihr, wie sie dort wartete. Das Verhalten folgte einer Regel: Die Station
bot jedem Fahrgast den Ort, an den er am meisten zurückkehren wollte, und löschte danach den Weg
dorthin. Der Fahrer sagte, jeder müsse eine letzte Haltestelle wählen. Danach wurde die Situation
persönlich. Clara sah hinter dem Bahnsteig ihr Elternhaus, obwohl es längst abgerissen war. Dann
kehrte das wiederkehrende Geräusch aus einem Ort zurück, den es physisch nicht erreichen konnte. Der
einzige brauchbare Plan lautete: Sie zog die Notbremse, bevor sich die Türen schlossen, und deckte
den Plan mit einem älteren Liniennetz ab. Der Zug dehnte sich zwischen den Stationen, während die
Ansage Claras Namen wiederholte. Sie blockierte die Türen, bis die zusätzliche Station verschwand.
Sie kam nach Hause, doch ihre Fahrkarte berechnete weiter Fahrten nach LETZTES ZUHAUSE. Am Morgen
stand die Station auf jedem Plan.

---

## Episode Metadata

**Episode:** 078

**Primary title:** Der U-Bahn-Plan zeigte eine zusätzliche Station

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 167

**Estimated spoken duration:** approximately 54–57 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
