# Episode 087 — Una campana sonaba bajo la iglesia

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

El campanario estaba vacío, pero una campana sonaba bajo el suelo. La advertencia ya estaba allí:
Nunca respondas a la campana subterránea con la del campanario. El sonido procedía de una cripta
sellada. Después de cada toque desaparecía un nombre del registro parroquial. El comportamiento
seguía una regla: La campana enterrada borraba a cualquiera cuyo nombre no se pronunciara antes del
siguiente toque. Planos antiguos mostraban una capilla inferior eliminada de todos los registros
posteriores. Después, la situación se volvió personal. Mara vio cómo su propio nombre se desvanecía
del registro. Entonces el sonido regresó desde un lugar al que no podía llegar físicamente. El único
plan posible era este: Bajó con la lista completa de feligreses borrados y leyó cada nombre entre
toques. Las puertas de la cripta se cerraron mientras la campana aceleraba. Mara llegó al último
nombre y golpeó la cadena antes de que desapareciera su entrada. Durante unos segundos, el motivo
recurrente se detuvo por completo. La campana quedó en silencio. Semanas después, un toque sonó
debajo del apartamento de Mara.

---

## Episode Metadata

**Episode:** 087

**Primary title:** Una campana sonaba bajo la iglesia

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 175

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
