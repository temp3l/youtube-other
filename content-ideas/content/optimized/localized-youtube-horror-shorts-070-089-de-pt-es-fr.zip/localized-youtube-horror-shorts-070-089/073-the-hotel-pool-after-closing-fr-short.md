# Episode 073 — Quelqu’un nageait après la fermeture de la piscine

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Après avoir verrouillé la piscine, Adrian entendit quelqu’un faire des longueurs. Les caméras
montraient l’eau bouger, mais aucun nageur. L’avertissement était déjà présent : Ne réponds jamais
au sifflet après la fermeture. Des traces mouillées menaient de la piscine à des chambres occupées.
Les clients rêvaient d’un enfant qui les appelait sous l’eau. Le comportement suivait une règle : La
présence ne pouvait quitter la piscine que par de l’eau emportée par quelqu’un. Les archives du
chantier mentionnaient un enfant disparu avant l’ouverture de l’hôtel. Puis la situation devint
personnelle. Adrian trouva une empreinte de main sous le plus ancien carrelage du bassin. Puis le
son revint d’un endroit qu’il ne pouvait physiquement atteindre. Le seul plan viable était le
suivant : Il vida la piscine, isola toutes les surfaces humides et ouvrit une trappe bloquée sous la
partie profonde. Lorsque la dernière eau disparut, quelque chose bougea sous les carreaux. Adrian
suivit le sifflet dans un tunnel technique et libéra l’air d’une ancienne chambre scellée. L’eau
resta immobile ensuite. Cette nuit-là, Adrian entendit des éclaboussures dans la baignoire vide de
sa chambre.

---

## Episode Metadata

**Episode:** 073

**Primary title:** Quelqu’un nageait après la fermeture de la piscine

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 180

**Estimated spoken duration:** approximately 58–62 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
