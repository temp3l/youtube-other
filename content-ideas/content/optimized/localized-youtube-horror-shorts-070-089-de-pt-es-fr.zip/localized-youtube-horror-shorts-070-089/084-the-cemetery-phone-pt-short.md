# Episode 084 — O telefone tocou dentro de um túmulo

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Um telefone celular tocou sob um túmulo selado havia trinta anos. O aviso já estava presente: Nunca
responda usando seu próprio nome. A pessoa do outro lado conhecia detalhes de enterros recentes.
Cada chamada vinha de um túmulo diferente, mas mostrava o mesmo número. O comportamento seguia uma
regra: A voz só podia sair quando uma pessoa viva se identificava. Registros antigos mencionavam o
mesmo toque antes de desaparecimentos. Depois disso, a situação se tornou pessoal. Sophie ouviu a
voz do pai morto perguntando quem havia atendido. Então o som voltou de um lugar ao qual não poderia
chegar fisicamente. O único plano possível era este: Ela respondeu com o nome gravado no túmulo, não
com o seu. Telefones começaram a tocar sob todas as fileiras. Sophie seguiu o único túmulo
silencioso e desconectou um cabo enterrado sem fonte de energia. Durante alguns segundos, o motivo
recorrente parou completamente. O toque parou. Naquela noite, o telefone de Sophie recebeu uma
chamada de sua própria sepultura vazia.

---

## Episode Metadata

**Episode:** 084

**Primary title:** O telefone tocou dentro de um túmulo

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 166

**Estimated spoken duration:** approximately 54–57 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
