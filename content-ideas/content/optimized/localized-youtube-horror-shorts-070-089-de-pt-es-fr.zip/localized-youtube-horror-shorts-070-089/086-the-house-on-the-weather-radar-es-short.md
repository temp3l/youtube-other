# Episode 086 — Una casa apareció dentro de la tormenta

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Una casa completa apareció dentro de la célula en el radar y se movía contra el viento. La casa
apareció brevemente en cámaras de carretera donde no existía ningún edificio. Cada habitación
contenía luces que coincidían con hogares perdidos en desastres anteriores. El comportamiento seguía
una regla: La tormenta recogía estructuras abandonadas durante emergencias y las reconstruía
alrededor de nuevos testigos. El radar histórico mostraba la misma casa antes de otras
desapariciones. Después, la situación se volvió personal. Adrian vio su hogar de infancia a través
de una ventana. Entonces el sonido regresó desde un lugar al que no podía llegar físicamente. El
único plan posible era este: Calculó la rotación y se acercó desde la única dirección hacia la que
la casa no podía mirar. La casa giró habitación por habitación mientras voces llamaban desde dentro.
Adrian marcó las coordenadas y cruzó la trayectoria antes de que completara el giro. La tormenta
colapsó. Más tarde, un mapa meteorológico mostró el símbolo de una casa sobre la dirección actual de
Adrian.

---

## Episode Metadata

**Episode:** 086

**Primary title:** Una casa apareció dentro de la tormenta

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 171

**Estimated spoken duration:** approximately 55–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
