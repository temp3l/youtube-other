# Episode 075 — O elevador abriu no Andar do Apagão

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

O elevador abriu entre os andares dezoito e dezenove, em um nível que só existia sem eletricidade. O
aviso já estava presente: Não leia nenhum e-mail exibido no Andar do Apagão. As luzes de emergência
revelaram mesas cobertas de objetos pessoais. Cada computador mostrava o último e-mail nunca enviado
de um funcionário diferente. O comportamento seguia uma regra: O andar guardava decisões abandonadas
e as usava para impedir que visitantes partissem. Os projetos não mostravam nenhum nível entre os
andares dezoito e dezenove. Depois disso, a situação se tornou pessoal. Noah encontrou o próprio
e-mail de demissão aberto em uma mesa, embora nunca o tivesse escrito. Então o som voltou de um
lugar ao qual não poderia chegar fisicamente. O único plano possível era este: Ele restaurou energia
apenas para um circuito do elevador, sem ligar a rede dos escritórios. Centenas de teclados
começaram a digitar no escuro. Noah alcançou o elevador antes que o andar terminasse seu e-mail. Ele
escapou quando a energia voltou. Mais tarde, o crachá passou a dar acesso a um andar chamado
BLACKOUT.

---

## Episode Metadata

**Episode:** 075

**Primary title:** O elevador abriu no Andar do Apagão

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 178

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
