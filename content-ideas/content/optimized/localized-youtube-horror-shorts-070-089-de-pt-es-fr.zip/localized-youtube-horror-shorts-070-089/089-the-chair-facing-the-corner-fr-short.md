# Episode 089 — La chaise se tourna vers la pièce

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

La chaise faisait toujours face au coin. Chaque fois qu’Emma revenait, elle s’était tournée un peu
plus vers la pièce. Les marques dans la poussière montraient qu’elle bougeait sans glisser sur le
sol. Les photographies montraient une silhouette assise seulement lorsque la chaise faisait face à
l’appareil. Le comportement suivait une règle : La chaise se tournait vers la personne qui la
regardait le plus longtemps. Les anciens propriétaires avaient retiré toutes les autres chaises.
Puis la situation devint personnelle. Emma trouva des noms gravés sous le siège, dont le sien. Puis
le son revint d’un endroit qu’il ne pouvait physiquement atteindre. Le seul plan viable était le
suivant : Elle disposa des miroirs pour que la chaise semble se regarder elle-même, puis quitta la
pièce sans se retourner. La chaise racla le sol tandis que les miroirs se brisaient un à un. Emma
suivit le bruit sans regarder derrière elle et verrouilla la pièce de l’extérieur. Le lendemain
matin, la chaise avait disparu. Une autre faisait maintenant face au coin de la chambre d’Emma.

---

## Episode Metadata

**Episode:** 089

**Primary title:** La chaise se tourna vers la pièce

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 173

**Estimated spoken duration:** approximately 56–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
