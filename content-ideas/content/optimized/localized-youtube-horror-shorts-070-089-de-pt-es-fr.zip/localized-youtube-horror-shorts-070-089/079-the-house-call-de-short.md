# Episode 079 — Der Arzt wurde zu einem leeren Haus gerufen

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Der Notruf kam von einer abgeschalteten Nummer. Der Patient war ein Kind in einem seit zwanzig
Jahren verlassenen Haus. Die Warnung war bereits vorhanden: Unterschreibe im Haus kein medizinisches
Formular. Eine Frau führte Tom zu einem Kind ohne Puls, das trotzdem seinen Namen sagte. In jedem
Raum standen medizinische Geräte aus einem anderen Jahrzehnt. Das Verhalten folgte einer Regel: Das
Haus wiederholte unvollendete Behandlungen, bis ein Arzt den Patienten offiziell entließ. Tom
erkannte den Fall aus Aufzeichnungen, die sein Vater versteckt hatte. Danach wurde die Situation
persönlich. Die Akte nannte Tom als behandelnden Arzt Jahre vor seiner Geburt. Dann kehrte das
wiederkehrende Geräusch aus einem Ort zurück, den es physisch nicht erreichen konnte. Der einzige
brauchbare Plan lautete: Er beendete den harmlosen letzten Behandlungsschritt, ohne das
Entlassungsformular zu unterschreiben. Die Familie flehte ihn an zu bleiben, während das Haus durch
verschiedene Jahrzehnte wechselte. Tom nannte den vollständigen Namen des Kindes, dokumentierte den
letzten Befund und ließ die Akte ununterschrieben. Für einige Sekunden verstummte das wiederkehrende
Motiv vollständig. Die Familie verschwand. Später erhielt Tom einen Entlassungsbericht,
unterschrieben von dem toten Kind.

---

## Episode Metadata

**Episode:** 079

**Primary title:** Der Arzt wurde zu einem leeren Haus gerufen

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 180

**Estimated spoken duration:** approximately 58–62 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
