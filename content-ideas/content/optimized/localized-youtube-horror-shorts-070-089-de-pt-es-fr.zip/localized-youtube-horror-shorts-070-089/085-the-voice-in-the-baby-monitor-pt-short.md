# Episode 085 — Uma voz falou pelo monitor do bebê

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

O monitor sussurrou: “Ela não está dormindo”, enquanto Laura segurava o bebê no andar de baixo. O
aviso já estava presente: Não responda depois que o monitor disser o nome da criança. A voz
descrevia movimentos dentro de um quarto vazio. As gravações mostravam um segundo berço ao lado do
verdadeiro. O comportamento seguia uma regra: A presença copiava rotinas dos pais e ficava mais
forte quando alguém seguia suas instruções. Os antigos moradores haviam relatado a mesma canção de
ninar. Depois disso, a situação se tornou pessoal. Laura ouviu a própria voz prometendo levar o bebê
para cima. Então o som voltou de um lugar ao qual não poderia chegar fisicamente. O único plano
possível era este: Ela mudou todas as rotinas e criou uma frase nova conhecida apenas por ela e pelo
parceiro. O monitor deu instruções contraditórias enquanto passos cruzavam o quarto. Laura se
recusou a entrar até ouvir a resposta correta à frase nova. O quarto estava vazio. Mais tarde, o
aparelho desligado reproduziu a frase de dentro dele.

---

## Episode Metadata

**Episode:** 085

**Primary title:** Uma voz falou pelo monitor do bebê

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 173

**Estimated spoken duration:** approximately 56–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
