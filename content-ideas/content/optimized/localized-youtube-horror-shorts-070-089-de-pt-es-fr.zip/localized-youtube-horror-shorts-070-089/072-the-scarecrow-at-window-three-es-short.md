# Episode 072 — El espantapájaros apareció en la Ventana Tres

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

El espantapájaros estaba frente a una ventana del tercer piso sin cornisa, árbol ni tejado debajo.
Había paja dentro de un aula cerrada desde el pasillo. Anuarios antiguos mostraban al mismo
espantapájaros detrás de alumnos que luego desaparecieron. El comportamiento seguía una regla: Se
acercaba cada vez que un alumno mentía y solo retrocedía cuando alguien decía una verdad olvidada.
La Ventana Tres había sido sellada después de que un alumno cayera décadas atrás. Después, la
situación se volvió personal. Sophie descubrió que el nombre del estudiante desaparecido había sido
recortado de todos los archivos. Entonces el sonido regresó desde un lugar al que no podía llegar
físicamente. El único plan posible era este: Prendió en el abrigo del espantapájaros los nombres
borrados y abrió la ventana solo lo suficiente para leerlos. El espantapájaros se inclinó hacia el
aula mientras los cuervos golpeaban el cristal. Cuando Sophie dijo el último nombre, la figura se
volvió hacia el campo. La paja desapareció de la escuela. Esa noche, otro espantapájaros estaba
frente a la casa de Sophie.

---

## Episode Metadata

**Episode:** 072

**Primary title:** El espantapájaros apareció en la Ventana Tres

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 175

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
