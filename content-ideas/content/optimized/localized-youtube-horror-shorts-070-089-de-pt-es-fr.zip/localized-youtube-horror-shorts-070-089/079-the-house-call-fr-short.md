# Episode 079 — Le médecin fut appelé dans une maison vide

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

L’appel d’urgence venait d’un numéro déconnecté. Le patient était un enfant dans une maison
abandonnée depuis vingt ans. L’avertissement était déjà présent : Ne signe aucun document médical
dans la maison. Une femme mena Tom auprès d’un enfant sans pouls qui prononça pourtant son nom.
Chaque pièce contenait du matériel médical d’une décennie différente. Le comportement suivait une
règle : La maison répétait les traitements inachevés jusqu’à ce qu’un médecin prononce
officiellement la sortie du patient. Tom reconnut l’affaire dans des notes que son père avait
cachées. Puis la situation devint personnelle. Le dossier désignait Tom comme médecin traitant
plusieurs années avant sa naissance. Puis le son revint d’un endroit qu’il ne pouvait physiquement
atteindre. Le seul plan viable était le suivant : Il effectua la dernière étape inoffensive du
traitement sans signer le document de sortie. La famille le supplia de rester tandis que la maison
changeait d’époque. Tom prononça le nom complet de l’enfant, nota l’observation finale et laissa le
formulaire sans signature. La famille disparut. Plus tard, Tom reçut un compte rendu de sortie signé
par l’enfant mort.

---

## Episode Metadata

**Episode:** 079

**Primary title:** Le médecin fut appelé dans une maison vide

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 178

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
