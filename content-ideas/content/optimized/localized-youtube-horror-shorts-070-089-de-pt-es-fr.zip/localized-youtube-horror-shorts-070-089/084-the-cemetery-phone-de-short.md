# Episode 084 — Das Telefon klingelte in einem Grab

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Ein Mobiltelefon klingelte unter einem Grab, das seit dreißig Jahren versiegelt war. Die Warnung war
bereits vorhanden: Antworte niemals mit deinem eigenen Namen. Der Anrufer kannte Einzelheiten über
kürzliche Beerdigungen. Jeder Anruf kam aus einem anderen Grab, zeigte aber dieselbe Nummer. Das
Verhalten folgte einer Regel: Die Stimme konnte ein Grab nur verlassen, wenn eine lebende Person
sich identifizierte. Alte Wartungsprotokolle vermerkten dasselbe Klingeln vor früheren
Vermisstenfällen. Danach wurde die Situation persönlich. Sophie hörte die Stimme ihres toten Vaters
fragen, wer abgenommen hatte. Dann kehrte das wiederkehrende Geräusch aus einem Ort zurück, den es
physisch nicht erreichen konnte. Der einzige brauchbare Plan lautete: Sie antwortete mit dem Namen
auf dem Grabstein statt mit ihrem eigenen. Unter jeder Reihe begannen Telefone zu klingeln. Sophie
folgte dem einzigen stillen Grab und trennte dort ein vergrabenes Kabel ohne Stromquelle. Für einige
Sekunden verstummte das wiederkehrende Motiv vollständig. Das Klingeln hörte auf. In derselben Nacht
zeigte Sophies Handy einen Anruf von ihrer noch leeren Grabstelle. Die Geschichte bleibt verstörend,
weil die letzten Beweise keine saubere Flucht zeigten, sondern Anpassung.

---

## Episode Metadata

**Episode:** 084

**Primary title:** Das Telefon klingelte in einem Grab

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 175

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
