# Episode 071 — A lavanderia só abria à meia-noite

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

A Máquina Sete girava sem eletricidade. Atrás do vidro, Felix viu a própria jaqueta. O visor deixou
de mostrar o tempo restante e exibiu o número do apartamento de Felix. As roupas no interior
pertenciam a pessoas desaparecidas. O comportamento seguia uma regra: Cada ciclo apagava uma memória
do dono das roupas. Uma mulher perto de uma secadora desligada sabia o nome de Felix, mas não
lembrava o próprio. Depois disso, a situação se tornou pessoal. Felix esqueceu por que tinha entrado
e encontrou um recibo indicando sete ciclos concluídos. Então o som voltou de um lugar ao qual não
poderia chegar fisicamente. O único plano possível era este: Ele cortou a água, travou o tambor e
forçou a porta antes que o contador chegasse a zero. Toda a lavanderia começou a girar como se o
prédio fosse uma única máquina. Felix retirou cada peça com nome e os pronunciou em voz alta. Na
manhã seguinte, a lavanderia havia desaparecido. Uma moeda marcada com o número sete continuava
voltando ao bolso de Felix.

---

## Episode Metadata

**Episode:** 071

**Primary title:** A lavanderia só abria à meia-noite

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 173

**Estimated spoken duration:** approximately 56–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
