# Episode 078 — El mapa del metro añadió una parada extra

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Entre dos estaciones conocidas apareció una parada nueva llamada ÚLTIMO HOGAR. Los pasajeros que
pisaban el andén oscuro desaparecían de la memoria de los demás. El teléfono de Clara contenía fotos
de ella esperando allí. El comportamiento seguía una regla: La estación ofrecía a cada pasajero el
lugar al que más deseaba regresar y luego borraba el viaje que lo había llevado. El conductor
anunció que todos debían elegir una última parada. Después, la situación se volvió personal. Clara
vio su casa de la infancia detrás del andén, aunque había sido demolida. Entonces el sonido regresó
desde un lugar al que no podía llegar físicamente. El único plan posible era este: Tiró del freno de
emergencia antes de que se cerraran las puertas y cubrió el mapa con un plano antiguo. El tren se
estiró entre estaciones mientras el anuncio repetía el nombre de Clara. Mantuvo bloqueadas las
puertas hasta que la parada desapareció. Regresó a casa, pero su tarjeta siguió cobrando viajes a
ÚLTIMO HOGAR. Al amanecer, la parada aparecía en todos los mapas.

---

## Episode Metadata

**Episode:** 078

**Primary title:** El mapa del metro añadió una parada extra

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 175

**Estimated spoken duration:** approximately 57–60 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
