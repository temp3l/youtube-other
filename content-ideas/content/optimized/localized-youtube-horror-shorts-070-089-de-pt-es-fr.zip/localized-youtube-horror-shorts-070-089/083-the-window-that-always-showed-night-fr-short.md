# Episode 083 — La fenêtre ne montrait jamais la lumière du jour

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Le soleil se leva devant toutes les autres fenêtres. Celle de la chambre montrait toujours minuit.
L’avertissement était déjà présent : N’ouvre pas la fenêtre pendant que le reste de l’immeuble est
en plein jour. La vue nocturne montrait des personnes dans des appartements inexistants. Une
silhouette s’approchait de la vitre chaque matin. Le comportement suivait une règle : La fenêtre
montrait une nuit parallèle et échangeait des objets lorsque les deux côtés l’ouvraient ensemble.
D’anciens locataires avaient disparu au lever du soleil. Puis la situation devint personnelle. Felix
vit son propre appartement de l’autre côté, avec quelqu’un vivant sa vie. Puis le son revint d’un
endroit qu’il ne pouvait physiquement atteindre. Le seul plan viable était le suivant : Il bloqua la
poignée et utilisa des miroirs pour envoyer la lumière du jour vers la nuit sans ouvrir la fenêtre.
La silhouette atteignit la vitre au moment où la lumière traversa la pièce. Felix ouvrit brusquement
les rideaux et la nuit s’effondra en simple reflet. Le jour revint. Pourtant, toutes les photos
prises à travers la fenêtre montraient encore la nuit.

---

## Episode Metadata

**Episode:** 083

**Primary title:** La fenêtre ne montrait jamais la lumière du jour

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 179

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
