# Episode 078 — Le plan du métro ajouta une station supplémentaire

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Une nouvelle station apparut entre deux arrêts familiers. Elle s’appelait DERNIER FOYER. Les
passagers qui posaient le pied sur le quai sombre disparaissaient de la mémoire des autres. Le
téléphone de Clara contenait des photos d’elle attendant sur le quai. Le comportement suivait une
règle : La station offrait à chacun l’endroit où il désirait le plus revenir, puis effaçait le
voyage qui l’y avait mené. Le conducteur annonça que chaque passager devait choisir un dernier
arrêt. Puis la situation devint personnelle. Clara vit sa maison d’enfance derrière le quai alors
qu’elle avait été démolie. Puis le son revint d’un endroit qu’il ne pouvait physiquement atteindre.
Le seul plan viable était le suivant : Elle tira le frein d’urgence avant la fermeture des portes et
recouvrit le plan avec une ancienne carte. La rame s’étira entre les stations pendant que l’annonce
répétait le nom de Clara. Elle bloqua les portes jusqu’à ce que l’arrêt disparaisse. Elle rentra
chez elle, mais sa carte continua à facturer des trajets vers DERNIER FOYER. Au matin, la station
figurait sur tous les plans.

---

## Episode Metadata

**Episode:** 078

**Primary title:** Le plan du métro ajouta une station supplémentaire

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 177

**Estimated spoken duration:** approximately 57–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
