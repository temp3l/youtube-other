# Episode 088 — Kamera Neun zeigte einen Wachmann, der nicht da war

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Kamera Neun zeigte einen Wachmann in einem Korridor, der vor Ort leer war. Die Warnung war bereits
vorhanden: Sprich niemals über Funk mit dem Wachmann. Die Gestalt folgte Patrouillenwegen aus alten
Schichtplänen. Jedes Mal, wenn Noah die Kamera wechselte, kam der Wachmann dem Kontrollraum näher.
Das Verhalten folgte einer Regel: Das Bild konnte den Bildschirm nur verlassen, wenn ein echter
Wachmann es bestätigte. Archivaufnahmen zeigten denselben Mann vor einem früheren tödlichen Unfall.
Danach wurde die Situation persönlich. Die Gestalt trug Noahs Ausweisnummer. Dann kehrte das
wiederkehrende Geräusch aus einem Ort zurück, den es physisch nicht erreichen konnte. Der einzige
brauchbare Plan lautete: Noah schleifte eine Aufnahme eines leeren Korridors und benutzte
Lichtsignale statt Funk. Der falsche Wachmann erreichte die Tür des Kontrollraums, während jeder
Monitor einen anderen Standort zeigte. Noah kappte das Kabel von Kamera Neun, bevor er das Klopfen
bestätigte. Für einige Sekunden verstummte das wiederkehrende Motiv vollständig. Das Bild
verschwand. Die nächste Schicht sah Noah auf Kamera Neun, obwohl er neben ihnen stand. Die
Geschichte bleibt verstörend, weil die letzten Beweise keine saubere Flucht zeigten, sondern
Anpassung.

---

## Episode Metadata

**Episode:** 088

**Primary title:** Kamera Neun zeigte einen Wachmann, der nicht da war

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 179

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
