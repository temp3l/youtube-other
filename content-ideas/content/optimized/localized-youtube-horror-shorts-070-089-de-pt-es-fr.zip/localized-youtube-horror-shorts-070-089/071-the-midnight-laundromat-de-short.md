# Episode 071 — Der Waschsalon öffnete nur um Mitternacht

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Maschine Sieben lief ohne Strom. Hinter der Scheibe sah Felix seine eigene Jacke. Die Warnung war
bereits vorhanden: Lass Maschine Sieben niemals den Waschgang beenden. Die Anzeige wechselte von der
Restzeit zu Felix' Wohnungsnummer. Die Kleidung in der Trommel gehörte Menschen, die als vermisst
galten. Das Verhalten folgte einer Regel: Jeder Waschgang löschte eine Erinnerung des Besitzers der
Kleidung. Eine Frau neben einem dunklen Trockner kannte Felix' Namen, erinnerte sich aber nicht an
ihren eigenen. Danach wurde die Situation persönlich. Felix vergaß, warum er den Waschsalon betreten
hatte, und fand einen Beleg über sieben abgeschlossene Waschgänge. Dann kehrte das wiederkehrende
Geräusch aus einem Ort zurück, den es physisch nicht erreichen konnte. Der einzige brauchbare Plan
lautete: Er kappte die Wasserzufuhr, blockierte die Trommel und zwang die Tür auf, bevor der Timer
null erreichte. Der gesamte Waschsalon begann sich zu drehen, als wäre das Gebäude selbst eine
Maschine. Felix zog jedes Kleidungsstück mit Namensschild heraus und sprach die Namen laut aus. Am
Morgen war der Waschsalon verschwunden. Eine Münze mit der Zahl Sieben kehrte immer wieder in Felix'
Tasche zurück.

---

## Episode Metadata

**Episode:** 071

**Primary title:** Der Waschsalon öffnete nur um Mitternacht

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 179

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
