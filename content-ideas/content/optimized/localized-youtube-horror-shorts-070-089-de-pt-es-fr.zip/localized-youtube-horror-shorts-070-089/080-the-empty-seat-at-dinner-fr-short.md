# Episode 080 — La place vide était préparée pour quelqu’un

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Treize couverts étaient dressés pour douze invités. Personne ne pouvait expliquer la chaise vide.
L’avertissement était déjà présent : N’enlève pas l’assiette supplémentaire avant la cloche de
minuit. La nourriture disparaissait de l’assiette intacte. Les photos de famille montraient une
personne floue à la même place. Le comportement suivait une règle : L’invité oublié devenait plus
fort chaque fois que la famille remplaçait un vrai souvenir par une version plus confortable. Chaque
membre de la famille se rappelait un nom différent. Puis la situation devint personnelle. Mara
trouva un journal familial dont une page avait été soigneusement arrachée. Puis le son revint d’un
endroit qu’il ne pouvait physiquement atteindre. Le seul plan viable était le suivant : Elle
reconstitua l’identité de l’enfant oublié à partir des dates, photographies et lettres restantes. La
chaise s’éloigna de la table pendant que Mara lisait la véritable histoire. La famille se souvint de
l’enfant qu’elle avait volontairement effacé. Pendant quelques secondes, le motif sonore s’arrêta
complètement. Au dîner suivant, une seconde place vide attendait à côté de Mara.

---

## Episode Metadata

**Episode:** 080

**Primary title:** La place vide était préparée pour quelqu’un

**Language code:** fr

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 171

**Estimated spoken duration:** approximately 55–59 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
