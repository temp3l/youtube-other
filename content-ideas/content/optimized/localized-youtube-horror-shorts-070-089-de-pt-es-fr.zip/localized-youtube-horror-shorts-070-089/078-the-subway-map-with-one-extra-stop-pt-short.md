# Episode 078 — O mapa do metrô acrescentou uma parada extra

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Uma nova estação apareceu entre duas paradas conhecidas. O nome era ÚLTIMO LAR. Os passageiros que
pisavam na plataforma escura desapareciam da memória dos demais. O telefone de Clara continha fotos
dela esperando ali. O comportamento seguia uma regra: A estação oferecia a cada passageiro o lugar
para onde mais desejava voltar e depois apagava a viagem que o havia levado até lá. O motorista
anunciou que todos precisavam escolher uma última parada. Depois disso, a situação se tornou
pessoal. Clara viu a casa da infância atrás da plataforma, embora ela tivesse sido demolida. Então o
som voltou de um lugar ao qual não poderia chegar fisicamente. O único plano possível era este: Ela
puxou o freio de emergência antes que as portas fechassem e cobriu o mapa com uma versão antiga. O
trem se esticou entre estações enquanto o anúncio repetia o nome de Clara. Ela manteve as portas
bloqueadas até a parada desaparecer. Ela voltou para casa, mas o cartão continuou cobrando viagens
até ÚLTIMO LAR. Pela manhã, a estação aparecia em todos os mapas.

---

## Episode Metadata

**Episode:** 078

**Primary title:** O mapa do metrô acrescentou uma parada extra

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 177

**Estimated spoken duration:** approximately 57–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
