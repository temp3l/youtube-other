# Episode 081 — Der Raum antwortete, bevor er sprach

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Daniel fragte, ob jemand im Raum sei. Die Antwort kam, bevor er die Frage beendet hatte. Die Warnung
war bereits vorhanden: Stelle dem Raum niemals eine Frage, die deinen eigenen Namen enthält.
Aufnahmen enthielten Antworten mehrere Sekunden vor Daniels Worten. Die Antworten wurden genauer,
wenn er allein zurückkehrte. Das Verhalten folgte einer Regel: Der Raum lernte mögliche Fragen und
zwang Besucher in die Version, die er bereits beantwortet hatte. Alte Akten beschrieben
Versuchspersonen, die mit Erinnerungen an nie geführte Gespräche zurückkehrten. Danach wurde die
Situation persönlich. Daniel hörte seine eigene Stimme ein Ereignis gestehen, das er nie erlebt
hatte. Dann kehrte das wiederkehrende Geräusch aus einem Ort zurück, den es physisch nicht erreichen
konnte. Der einzige brauchbare Plan lautete: Er bereitete mehrere Fragen mit sich gegenseitig
ausschließenden Antworten vor und spielte sie gleichzeitig ab. Der Raum versuchte alle Fragen
zugleich zu beantworten, sodass die Wände verschiedene Zukünfte wiederholten. Daniel folgte der
einzigen Antwort mit einem akustischen Fehler, den der Raum nie korrekt kopiert hatte. Er entkam.
Später beantwortete jeder leere Raum seinen ersten Gedanken mit einem leisen Klopfen.

---

## Episode Metadata

**Episode:** 081

**Primary title:** Der Raum antwortete, bevor er sprach

**Language code:** de

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 178

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
