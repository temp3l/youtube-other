# Episode 083 — La ventana nunca mostraba luz del día

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

El sol salió frente a todas las demás ventanas. La del dormitorio continuaba mostrando medianoche.
La advertencia ya estaba allí: No abras la ventana mientras el resto del edificio esté a plena luz.
La vista nocturna contenía personas en apartamentos inexistentes. Una figura se acercaba al cristal
cada mañana. El comportamiento seguía una regla: La ventana mostraba una noche paralela e
intercambiaba objetos cuando ambos lados la abrían al mismo tiempo. Los inquilinos anteriores habían
desaparecido al amanecer. Después, la situación se volvió personal. Felix vio su propio apartamento
al otro lado, con otra persona viviendo su vida. Entonces el sonido regresó desde un lugar al que no
podía llegar físicamente. El único plan posible era este: Bloqueó el cierre y utilizó espejos para
dirigir la luz del día hacia la noche sin abrir la ventana. La figura alcanzó el cristal cuando la
luz cruzó la habitación. Felix abrió las cortinas de golpe y la noche se derrumbó en un reflejo.
Volvió la luz del día. Sin embargo, todas las fotos tomadas a través de la ventana seguían mostrando
noche.

---

## Episode Metadata

**Episode:** 083

**Primary title:** La ventana nunca mostraba luz del día

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 180

**Estimated spoken duration:** approximately 58–62 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
