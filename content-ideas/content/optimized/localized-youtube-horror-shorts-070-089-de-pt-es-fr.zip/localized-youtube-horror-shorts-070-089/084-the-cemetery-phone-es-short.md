# Episode 084 — El teléfono sonó dentro de una tumba

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Un teléfono móvil sonó debajo de una tumba sellada hacía treinta años. La advertencia ya estaba
allí: Nunca respondas con tu propio nombre. La persona que llamaba conocía detalles de entierros
recientes. Cada llamada venía de una tumba diferente, pero mostraba el mismo número. El
comportamiento seguía una regla: La voz solo podía salir si una persona viva se identificaba. Los
registros antiguos anotaban el mismo sonido antes de varias desapariciones. Después, la situación se
volvió personal. Sophie oyó la voz de su padre muerto preguntando quién había contestado. Entonces
el sonido regresó desde un lugar al que no podía llegar físicamente. El único plan posible era este:
Respondió con el nombre grabado en la tumba, no con el suyo. Empezaron a sonar teléfonos bajo todas
las filas. Sophie siguió la única tumba silenciosa y desconectó un cable enterrado sin fuente de
energía. Durante unos segundos, el motivo recurrente se detuvo por completo. El sonido cesó. Esa
noche, el teléfono de Sophie recibió una llamada desde su parcela vacía.

---

## Episode Metadata

**Episode:** 084

**Primary title:** El teléfono sonó dentro de una tumba

**Language code:** es

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 169

**Estimated spoken duration:** approximately 55–58 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
