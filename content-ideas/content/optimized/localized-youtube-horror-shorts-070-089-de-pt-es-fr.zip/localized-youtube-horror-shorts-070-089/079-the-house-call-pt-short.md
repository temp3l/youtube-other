# Episode 079 — O médico foi chamado a uma casa vazia

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

A chamada de emergência veio de um número desconectado. O paciente era uma criança em uma casa
abandonada havia vinte anos. Uma mulher levou Tom até uma criança sem pulso que ainda assim
pronunciou seu nome. Cada cômodo continha equipamentos médicos de uma década diferente. O
comportamento seguia uma regra: A casa repetia tratamentos incompletos até que um médico desse alta
oficialmente. Tom reconheceu o caso em anotações que seu pai havia escondido. Depois disso, a
situação se tornou pessoal. O prontuário listava Tom como médico responsável anos antes de seu
nascimento. Então o som voltou de um lugar ao qual não poderia chegar fisicamente. O único plano
possível era este: Ele concluiu a etapa final inofensiva do tratamento sem assinar a alta. A família
implorou para que ele ficasse enquanto a casa mudava de década. Tom disse o nome completo da
criança, registrou a observação final e deixou o documento sem assinatura. A família desapareceu.
Mais tarde, Tom recebeu um relatório de alta assinado pela criança morta.

---

## Episode Metadata

**Episode:** 079

**Primary title:** O médico foi chamado a uma casa vazia

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 168

**Estimated spoken duration:** approximately 54–58 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
