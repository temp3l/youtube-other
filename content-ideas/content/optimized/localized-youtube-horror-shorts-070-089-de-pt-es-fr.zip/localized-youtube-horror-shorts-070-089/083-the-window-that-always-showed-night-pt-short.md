# Episode 083 — A janela nunca mostrava a luz do dia

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

O sol nasceu diante de todas as outras janelas. A do quarto continuou mostrando meia-noite. A vista
noturna mostrava pessoas em apartamentos que não existiam. Uma figura se aproximava do vidro a cada
manhã. O comportamento seguia uma regra: A janela mostrava uma noite paralela e trocava objetos
quando os dois lados a abriam ao mesmo tempo. Moradores anteriores haviam desaparecido ao nascer do
sol. Depois disso, a situação se tornou pessoal. Felix viu o próprio apartamento do outro lado, com
outra pessoa vivendo sua vida. Então o som voltou de um lugar ao qual não poderia chegar
fisicamente. O único plano possível era este: Ele bloqueou o fecho e usou espelhos para levar luz do
dia até o lado noturno sem abrir a janela. A figura alcançou o vidro quando a luz cruzou o quarto.
Felix abriu as cortinas de uma vez, e a noite desabou em um reflexo. A luz do dia voltou. Mesmo
assim, todas as fotos tiradas pela janela continuavam mostrando noite.

---

## Episode Metadata

**Episode:** 083

**Primary title:** A janela nunca mostrava a luz do dia

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 166

**Estimated spoken duration:** approximately 54–57 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
