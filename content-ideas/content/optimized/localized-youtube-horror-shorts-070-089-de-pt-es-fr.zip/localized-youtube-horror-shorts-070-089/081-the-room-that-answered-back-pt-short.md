# Episode 081 — A sala respondeu antes que ele falasse

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Keep the opening immediate and deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use short pauses only before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and bring it back immediately before the final reveal.

# Narration Script

Daniel perguntou se havia alguém dentro. A sala respondeu antes que ele terminasse. O aviso já
estava presente: Nunca faça à sala uma pergunta que contenha seu próprio nome. As gravações captavam
respostas vários segundos antes de Daniel falar. As respostas se tornavam mais precisas quando ele
voltava sozinho. O comportamento seguia uma regra: A sala aprendia perguntas possíveis e forçava os
visitantes em direção à versão que já havia respondido. Arquivos antigos descreviam pessoas que
saíam com lembranças de conversas que nunca aconteceram. Depois disso, a situação se tornou pessoal.
Daniel ouviu a própria voz confessando um acontecimento que jamais viveu. Então o som voltou de um
lugar ao qual não poderia chegar fisicamente. O único plano possível era este: Ele preparou várias
perguntas com respostas incompatíveis e as reproduziu ao mesmo tempo. A sala tentou responder a
todas, e as paredes repetiram futuros diferentes. Daniel seguiu a única resposta com uma falha
acústica que a sala nunca conseguia copiar corretamente. Ele escapou. Depois disso, toda sala vazia
respondia ao primeiro pensamento dele com uma batida suave.

---

## Episode Metadata

**Episode:** 081

**Primary title:** A sala respondeu antes que ele falasse

**Language code:** pt

**Content disclosure:** Original fictional horror story.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 178

**Estimated spoken duration:** approximately 58–61 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
