# Optimization Report — Episodes 010–029

## Shared findings

- The original files contained strong hooks and viable premises, but most narration sections were closer to expanded outlines than finished stories.
- Repeated framework phrases described narrative function instead of dramatizing action.
- Several stories changed tense and used placeholders such as “the protagonist,” “a witness,” or “the recurring object.”
- Important discoveries and climaxes were often compressed into one sentence.
- The optimized versions use concrete scenes, named actions, recurring motifs, explicit supernatural rules, failed safety measures, emotional choices and post-escape evidence.

## Ratings

| Episode | Title | Original | Optimized | Narration words | Raw narration time |
|---|---|---:|---:|---:|---:|
| 010 | She Cleaned Rooms Before People Died | 5.0/10 | 8.2/10 | 1206 | 6.5-6.9 min |
| 011 | The Children Asked to Come Inside | 5.0/10 | 8.2/10 | 1142 | 6.2-6.5 min |
| 012 | She Followed the Elevator Ritual | 5.0/10 | 8.2/10 | 1161 | 6.3-6.6 min |
| 013 | What Really Happened at Dyatlov Pass? | 5.5/10 | 8.6/10 | 1111 | 6.0-6.3 min |
| 014 | The Eight-Foot Woman Called Her Name | 5.0/10 | 8.2/10 | 1183 | 6.4-6.8 min |
| 015 | The Voice That Haunted the Bell Family | 5.0/10 | 8.2/10 | 1138 | 6.2-6.5 min |
| 016 | The Train Stopped at a Station That Doesn't Exist | 5.0/10 | 8.2/10 | 1137 | 6.1-6.5 min |
| 017 | They Invited the Midnight Man Inside | 5.0/10 | 8.2/10 | 1118 | 6.0-6.4 min |
| 018 | The Smiling Man Followed Her Home | 5.0/10 | 8.2/10 | 1170 | 6.3-6.7 min |
| 019 | The Truth Behind the Russian Sleep Experiment | 5.0/10 | 8.2/10 | 1130 | 6.1-6.5 min |
| 020 | She Heard Teke Teke Behind Her | 5.0/10 | 8.2/10 | 1107 | 6.0-6.3 min |
| 021 | Something Was Watching From the Bedroom Window | 5.5/10 | 8.2/10 | 1136 | 6.1-6.5 min |
| 022 | The Whistler in the Woods Was Getting Closer | 5.5/10 | 8.2/10 | 1122 | 6.1-6.4 min |
| 023 | The Hitchhiker Vanished From the Back Seat | 5.5/10 | 8.2/10 | 1111 | 6.0-6.3 min |
| 024 | The Red Room Pop-Up Knew Her Name | 5.5/10 | 8.2/10 | 1109 | 6.0-6.3 min |
| 025 | He Fell Into the Endless Backrooms | 5.5/10 | 8.2/10 | 1161 | 6.3-6.6 min |
| 026 | She Said Bloody Mary Three Times | 5.5/10 | 8.2/10 | 1153 | 6.2-6.6 min |
| 027 | They Found a Hook Hanging From the Car Door | 5.5/10 | 8.2/10 | 1134 | 6.1-6.5 min |
| 028 | Someone Was Living in the Attic | 5.5/10 | 8.2/10 | 1131 | 6.1-6.5 min |
| 029 | The Ghost Train Arrives at 4:19 A.M. | 5.5/10 | 8.2/10 | 1151 | 6.2-6.6 min |

## Production recommendations

- Keep the opening hook under 25 seconds and introduce the first impossible detail within the first minute.
- Change the visual every 6–10 seconds, but reserve faster cuts for pursuit or countdown sequences.
- Repeat the episode-specific sound motif only at escalation points so the audience learns to anticipate danger.
- Allow 0.5–1.5 seconds of silence before major reveals and the final sentence.
- For factual or folklore episodes, distinguish documented evidence, later claims and dramatized reconstruction explicitly.
- Do not pad runtime with generic atmosphere. Add investigations, failed safety measures, hard choices, consequences and new evidence instead.

## Important limitation

These revisions target the requested 6–10 minute format, but many land near the lower end at a 175–185 WPM delivery. Longer pauses, dialogue performance and sound design should bring them into the 6–8 minute range. Episodes intended to exceed eight minutes should be expanded with an additional investigation scene or failed escape rather than slower narration alone.