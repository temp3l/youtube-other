# Episode 021 — Something Was Watching From the Bedroom Window

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak naturally in the story language with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Deliver the first impossible detail within the first three seconds.
- Build tension continuously without long pauses.
- Use only a short pause before the climax and final reveal.
- Keep supernatural voice processing subtle.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave approximately half a second of silence before the final line.

### YouTube Shorts sound design

Use one restrained recurring sound motif tied to the central threat. Introduce it quietly, repeat it once during escalation, and return to it immediately before the final reveal.

# Narration Script

Paul's bedroom was on the second floor. There was no balcony, tree or ladder. Paul Mercer moved into
his brother's remote farmhouse after an accident left his brother unable to walk. At first, the
detail seemed small enough to dismiss. That explanation lasted only until the next night. From that
point, the pattern stopped looking accidental. The first real warning came when the ordinary rules
failed. What followed changed the meaning of everything before it. The danger then became personal.
A reasonable attempt to escape made the situation worse. For a few minutes, the plan appeared to
work. The apparent ending did not survive until morning. The final piece of evidence arrived later.
In the final frame, Paul opened his eyes and looked directly into the lens. Before the final
decision, the surviving record describes a deliberate verification attempt. A second escape attempt
failed for a different reason. The farmhouse is empty now. Yet every night, something tapped on the
glass.

---

## Episode Metadata

**Episode:** 021

**Primary title:** Something Was Watching From the Bedroom Window

**Language code:** en

**Content disclosure:** Original fictional horror story or clearly framed folklore/reality-based horror adaptation.

**Format:** YouTube Short, vertical 9:16, 1080 × 1920

**Narration word count:** 161

**Estimated spoken duration:** approximately 52–55 seconds at 185–175 words per minute, before brief dramatic pauses.

**Target duration:** approximately 50–60 seconds including restrained sound design.

**Hashtags:** #HorrorShorts #ScaryStories #DarkTruthEpisodes #Shorts
