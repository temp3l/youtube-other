# YouTube Horror Shorts — Episodes 010–029

This package contains 100 YouTube Shorts scripts:

- 20 English (`en`)
- 20 German (`de`)
- 20 Portuguese (`pt`)
- 20 Spanish (`es`)
- 20 French (`fr`)

Localized versions use localized titles and narration. Production instructions and metadata remain in English.

Narration length is 154–180 words, targeting approximately 50–60 seconds including brief pauses and restrained sound design.

Episodes based on folklore, legends, or debated real events retain clear framing and do not present unsupported claims as established fact.
