# Localized Horror Stories — Episodes 020–039

Contains German (`de`), Portuguese (`pt`), Spanish (`es`) and French (`fr`) narration versions.

Episode titles and narration are localized. Audio generation instructions, available optimization notes, and episode metadata remain in English.

Total localized story files: 80.
