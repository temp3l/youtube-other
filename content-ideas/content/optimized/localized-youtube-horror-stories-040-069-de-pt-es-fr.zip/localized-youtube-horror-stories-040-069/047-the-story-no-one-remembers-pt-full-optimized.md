# Episode 047 — A história que apaga quem a escuta

## Audio Generation Instructions

> Production directions only. Do not narrate this section.

- Use one consistent adult male narrator.
- Speak in natural English with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Do not narrate headings, metadata, or production directions.

### Sound motif

library clock, turning pages, and whispered words fading out

# Narration Script

Todos lembravam que a história era assustadora. Ninguém conseguia contar o enredo.

Tom Avery trabalhava como pesquisador de folclore quando o relato começou em uma biblioteca
costeira. O primeiro acontecimento não parecia violento nem claramente sobrenatural. Surgiu durante
uma tarefa comum e deu a todos um motivo para permanecer calmos.

A caligrafia mudava no meio dos parágrafos. Tom repetiu a observação, comparou horários e testou
explicações razoáveis. O resultado não mudou.

As pessoas citadas no texto desapareciam de fotos e registros. Uma segunda testemunha, uma gravação
ou uma marca física confirmou parte do incidente e criou uma contradição.

O comportamento seguia uma regra: A história sobrevivia transformando pessoas reais em personagens e
apagando quem pudesse explicá-la. Quando Tom a compreendeu, os acontecimentos anteriores deixaram de
parecer aleatórios.

Tom pesquisou arquivos, relatórios e gravações. Outras testemunhas haviam vivido a mesma escalada e
voltado com falhas de memória ou documentos alterados.

A investigação revelou que as vítimas anteriores haviam tomado as mesmas medidas razoáveis: isolar a fonte, avisar outras pessoas ou abandonar o local. Nenhuma havia interrompido o padrão. Apenas transferira o incidente seguinte para outro espaço.

Mesmo assim, uma prova verificável permanecia estável. Podia ser fotografada, copiada ou confirmada por outra pessoa. Essa estabilidade tornava a situação mais perigosa, porque a ameaça parecia entender quais detalhes seriam considerados confiáveis por alguém de fora.

Quanto mais precisamente o padrão era documentado, mais precisamente respondia. Os horários se
tornavam exatos e detalhes pessoais surgiam em lugares impossíveis.

Tom tentou isolar a fonte, pedir ajuda e registrar a sequência. Durante alguns minutos, tudo pareceu
calmo.

Então o som ou sinal central voltou de um lugar fisicamente impossível. As saídas deixaram de ser
confiáveis e os ambientes conhecidos começaram a mudar.

A cada escalada, o ambiente ficava mais silencioso. Sons comuns desapareciam, portas levavam a cômodos errados e pequenos objetos surgiam em posições que ninguém lembrava. O lugar parecia estar se reorganizando de forma deliberada.

A pressão pessoal também aumentava. A presença usava vozes conhecidas, memórias ou lugares familiares para fazer uma decisão errada parecer segura. O protagonista precisava distinguir um sinal emocionalmente convincente da única regra que podia ser verificada.

Um som recorrente, um horário exato ou um objeto que não mudava servia como âncora. Todo o resto podia se alterar, mas esse detalhe permanecia estável. Ele permitia medir a proximidade do perigo e escolher o momento da tentativa final.

O único plano possível era este: Tom removeu seu nome de todas as cópias e o substituiu por um
personagem fictício. Ele dependia de observação, não de força, e explorava o único limite que o
fenômeno não conseguia alterar.

Antes da tentativa final, Tom deixou passar um ciclo completo sem interferir. Isso confirmou o
momento exato e revelou a próxima escalada.

O catálogo imediatamente passou a listar o personagem como autor. Tom escreveu um final no qual a
história esquecia o próprio título. Tom teve apenas uma oportunidade de seguir o plano. Recuar teria
fortalecido a armadilha.

Durante alguns segundos, tudo ficou em silêncio. Essa ausência de som foi mais inquietante do que
qualquer grito.

Tom sobreviveu, mas os amigos só lembravam dele como personagem. O manuscrito agora começa: “Tom
Avery ouviu isso primeiro de você.”

Depois do aparente fim, a documentação continuava contraditória. Gravações perdiam segundos, arquivos continham linhas vazias e testemunhas lembravam do aviso, mas não de quem o havia feito. Essas ausências se repetiam em todas as versões.

Nas horas seguintes, Tom anotou todos os detalhes. Pela manhã, alguns horários, nomes ou posições já
haviam mudado nas provas.

Autoridades e familiares só conseguiram confirmar fragmentos. A explicação oficial falou em
estresse, falhas técnicas ou desaparecimento não resolvido.

A história continua perturbadora porque a última prova não mostrava uma fuga completa. Talvez a
ameaça não apenas tenha sobrevivido a Tom, mas aprendido uma forma mais silenciosa de alcançar a
próxima pessoa.

---

## Optimization Notes

- Replaced outline and template commentary with concrete scenes and consequences.
- Standardized narration in past tense.
- Preserved a recurring sound motif and attached it to escalation points.
- Added a supernatural rule, investigation, failed safety response, evidence trail, active plan and final reversal.
- Narration word count: **1139 words**.
- Estimated narration runtime: **6.2–6.5 minutes** at 185–175 WPM, before dramatic pauses.

## Episode Metadata

**Episode number:** 047

**Primary title:** The Story That Erases Everyone Who Hears It

**Thumbnail text:** YOU WILL FORGET

**Description:** Tom Avery encountered a handwritten story with missing pages. What seemed like an isolated incident became a pattern that knew exactly how to follow. An original fictional horror story produced for Dark Truth Episodes.

**Content disclosure:** Original fictional horror story.

**Hashtags:** #HorrorStory #ScaryStories #DarkTruthEpisodes

**Narration pace:** 175–185 words per minute

**Target duration:** approximately 6–8 minutes with natural pauses and sound design

**Format:** 16:9, 1920 × 1080
