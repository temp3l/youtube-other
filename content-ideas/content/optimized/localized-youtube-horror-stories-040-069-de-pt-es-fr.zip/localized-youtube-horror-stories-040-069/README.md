# Localized Horror Stories — Episodes 040–069

Contains German (`de`), Portuguese (`pt`), Spanish (`es`) and French (`fr`) narration versions.

Episode titles and narration are localized. Audio generation instructions, optimization notes and episode metadata remain in English.

Total localized story files: 120.
