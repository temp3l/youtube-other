# Episode 170 — The Face in Every Window

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak in natural English with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Begin calmly and build tension steadily.
- Keep dialogue grounded and believable.
- Slow slightly during discoveries and the final reveal.
- Use only subtle processing for supernatural voices.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave a brief silence before the final line.

### Episode-specific sound motif

Use camera shutter snaps, blinds tapping glass, and breath fogging windows from outside. Keep the motif subtle and repeat it only at major escalation points.

# Narration Script

The vacant building had one face in every window, and all of them were looking at Erin.

Erin Lake was a property photographer working in a vacant apartment complex awaiting luxury redevelopment when the first impossible detail appeared. It was not dramatic enough to make the night feel unreal immediately. That was the worst part. It entered the world like a maintenance issue, a customer complaint, a bad sensor, a tired mistake. Erin had seen enough long shifts and cheap equipment to distrust panic before evidence. So the first response was practical: check the obvious thing, document the time, keep one exit clear, and do not say anything out loud that would sound insane in the morning.

The detail was a condemned apartment block with hundreds of empty windows facing a train yard. It should have belonged to the building, the road, the room or the job in some harmless way. Instead, it behaved as if it had been waiting for someone professional enough to notice the difference. At first, Erin thought the face was a reflection from a billboard or someone moving through empty units. That explanation helped for a few minutes. It gave Erin something ordinary to hold onto, and horror often survives longest when it wears the shape of a normal problem.

Then the normal problem answered back.

Her wide-angle shots showed the same pale face behind windows on different floors at the same second. The change was small enough to be checked and clear enough to be feared. Erin wrote down the time, took a photograph, and tried to repeat the conditions. The second attempt made the situation worse. The sound returned first: camera shutter snaps, blinds tapping glass, and breath fogging windows from outside. It did not come from a single direction. It moved through the place like a signal being passed from wall to wall, from object to object, learning where Erin stood.

That was when the first rule became clear, although nobody understood it completely yet: If the same face appears in more than one window, stop photographing. Like most useful warnings, it sounded too narrow to save a person and too specific to ignore. Erin did not believe in curses, but the human mind respects instructions that arrive before danger. The rule had the hard edge of something learned through loss.

Someone else already knew part of the story. A security guard said the building kept one watcher for every tenant forced out during redevelopment. The warning was not delivered like folklore. It sounded administrative, embarrassed, almost tired. It came from a person who had decided years earlier that explanation was less important than survival. When Erin asked for proof, there was no single clean answer, only records, omissions and old local habits that suddenly lined up too well.

Old eviction records contained blurred ID photos that resembled the face but never matched one person completely. That discovery changed the fear. Before then, the event could still be treated as an anomaly. After that, it became a pattern with witnesses. The evidence did not explain what was happening. It proved that disbelief was late. It proved that other people had reached the same point, made decisions under pressure, and left behind just enough for the next person to fail more intelligently.

Erin tried the reasonable solution first. Power was cut where power mattered. Doors were locked where doors existed. Calls were made, notes were taken, and every ordinary explanation was tested before being discarded. The problem respected none of it. When Erin switched lenses, the face appeared in the glass of her camera itself, closer than any window. It did not behave like an animal, exactly. It behaved like a procedure. It had inputs, responses and thresholds. The more carefully Erin measured it, the more carefully it measured back.

The next escalation was personal. The phenomenon stopped occupying the setting and began using the setting to address Erin directly. Familiar words appeared in unfamiliar places. Reflections hesitated. A route that should have led away returned to a place already checked. Something knew which detail would make caution feel cruel, which voice would make a locked door feel like a moral failure, which memory would make the rule sound negotiable. That was the real attack. Not teeth. Not claws. Decision pressure.

A second attempt to escape failed for a different reason. The physical route remained available, but the meaning of the route changed. Erin could still walk, drive, call, unlock, delete, refuse or turn back, yet every choice seemed to satisfy one part of the pattern. That was when the rule became cruel rather than helpful. The safest action demanded stillness. The most human action invited the thing closer.

For a while, the plan appeared to work. Erin followed the narrow warning as literally as possible. No improvisation. No bargaining. No clever loophole. The space around the event became quiet. The developer approved the photos, saying the building looked clean and empty. Ordinary sound returned slowly, as if the world were pretending nothing had happened. The return of normality felt like rescue, but it was only a pause long enough for relief to become carelessness.

The record after that is incomplete. Some of it comes from photographs. Some from timestamps. Some from people who heard something and later denied hearing it. What can be said with confidence is that the event did not end when the immediate danger stopped. It changed ownership. It moved from place to person, from witness to evidence, from evidence to habit. The warning survived because the threat survived inside the warning.

When the demolition charges fired, every window filled with faces, and Erin heard her camera take pictures by itself from inside her bag. That detail turned survival into implication. Erin had not escaped by solving the pattern. Erin had become part of the pattern's next method of approach. The thing had learned what a careful person would do, and that meant it could prepare for the next careful person.

The official explanation, if there was one, remained small. Faulty wiring. Stress. Hoax. Weather. Bad data. Trespassers. Sleep deprivation. People prefer explanations that do not require them to change their behavior. But the people closest to the event kept one habit afterward. They avoided the place, the object or the hour. They did not joke about it. They did not test it for friends. And whenever that same sound returned—camera shutter snaps, blinds tapping glass, and breath fogging windows from outside—they stopped talking until it passed.

The final photo showed her behind glass, waiting with the rest.

---

## Episode Metadata

**Episode number:** 170

**Primary title:** The Face in Every Window

**Source title:** The Window Face

**Suggested thumbnail text:** EVERY WINDOW

**Content disclosure:** Original supernatural thriller inspired by established folklore, urban-legend, liminal-horror, or cursed-media conventions.

**Narration word count:** 1102

**Estimated spoken duration:** 6.0–6.3 minutes before longer dramatic pauses; approximately 6.4–7.3 minutes with restrained sound design.

**Suggested tags:** window horror, abandoned building horror, scary story, photographer horror, horror story, scary story, narrated horror, dark truth episodes, creepy story

**Hashtags:** #HorrorStory #ScaryStories #DarkTruthEpisodes

**Visual direction:** cinematic 16:9 illustrations with consistent character design, restrained dark-documentary horror tone, slow push-ins, selective parallax, visible environmental texture, readable facial fear, and a new visual beat every 6–10 seconds.
