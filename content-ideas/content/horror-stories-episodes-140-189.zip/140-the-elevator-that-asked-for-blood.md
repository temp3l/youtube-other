# Episode 140 — The Elevator That Asked for Blood

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak in natural English with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Begin calmly and build tension steadily.
- Keep dialogue grounded and believable.
- Slow slightly during discoveries and the final reveal.
- Use only subtle processing for supernatural voices.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave a brief silence before the final line.

### Episode-specific sound motif

Use elevator cables groaning, a soft arrival chime, and one slow drop of liquid hitting metal. Keep the motif subtle and repeat it only at major escalation points.

# Narration Script

The elevator did not malfunction until it asked Mara which floor should die first.

Mara Voss was a night maintenance engineer working in a half-empty financial tower in the city center when the first impossible detail appeared. It was not dramatic enough to make the night feel unreal immediately. That was the worst part. It entered the world like a maintenance issue, a customer complaint, a bad sensor, a tired mistake. Mara had seen enough long shifts and cheap equipment to distrust panic before evidence. So the first response was practical: check the obvious thing, document the time, keep one exit clear, and do not say anything out loud that would sound insane in the morning.

The detail was a service elevator with scratched brass buttons and a voice panel that had been disconnected for years. It should have belonged to the building, the road, the room or the job in some harmless way. Instead, it behaved as if it had been waiting for someone professional enough to notice the difference. At first, Mara blamed moisture in the shaft, a bad relay, or one of the executives playing a drunk joke after a late meeting. That explanation helped for a few minutes. It gave Mara something ordinary to hold onto, and horror often survives longest when it wears the shape of a normal problem.

Then the normal problem answered back.

The button for floor twenty-two lit by itself, then every floor above it went dark in order, like something counting down through the building. The change was small enough to be checked and clear enough to be feared. Mara wrote down the time, took a photograph, and tried to repeat the conditions. The second attempt made the situation worse. The sound returned first: elevator cables groaning, a soft arrival chime, and one slow drop of liquid hitting metal. It did not come from a single direction. It moved through the place like a signal being passed from wall to wall, from object to object, learning where Mara stood.

That was when the first rule became clear, although nobody understood it completely yet: If the elevator asks for a floor you did not press, do not answer it. Like most useful warnings, it sounded too narrow to save a person and too specific to ignore. Mara did not believe in curses, but the human mind respects instructions that arrive before danger. The rule had the hard edge of something learned through loss.

Someone else already knew part of the story. The night guard told her the old staff never rode that car after midnight because it had once returned with no passengers and wet handprints inside. The warning was not delivered like folklore. It sounded administrative, embarrassed, almost tired. It came from a person who had decided years earlier that explanation was less important than survival. When Mara asked for proof, there was no single clean answer, only records, omissions and old local habits that suddenly lined up too well.

Inside the machine room, Mara found maintenance logs from 1989 describing a crushed technician whose blood had shorted the control board. That discovery changed the fear. Before then, the event could still be treated as an anomaly. After that, it became a pattern with witnesses. The evidence did not explain what was happening. It proved that disbelief was late. It proved that other people had reached the same point, made decisions under pressure, and left behind just enough for the next person to fail more intelligently.

Mara tried the reasonable solution first. Power was cut where power mattered. Doors were locked where doors existed. Calls were made, notes were taken, and every ordinary explanation was tested before being discarded. The problem respected none of it. Each time Mara cut power, the car stopped between floors and the voice calmly asked for a different name instead of a destination. It did not behave like an animal, exactly. It behaved like a procedure. It had inputs, responses and thresholds. The more carefully Mara measured it, the more carefully it measured back.

The next escalation was personal. The phenomenon stopped occupying the setting and began using the setting to address Mara directly. Familiar words appeared in unfamiliar places. Reflections hesitated. A route that should have led away returned to a place already checked. Something knew which detail would make caution feel cruel, which voice would make a locked door feel like a moral failure, which memory would make the rule sound negotiable. That was the real attack. Not teeth. Not claws. Decision pressure.

A second attempt to escape failed for a different reason. The physical route remained available, but the meaning of the route changed. Mara could still walk, drive, call, unlock, delete, refuse or turn back, yet every choice seemed to satisfy one part of the pattern. That was when the rule became cruel rather than helpful. The safest action demanded stillness. The most human action invited the thing closer.

For a while, the plan appeared to work. Mara followed the narrow warning as literally as possible. No improvisation. No bargaining. No clever loophole. The space around the event became quiet. At dawn, the elevator opened normally in the lobby, dry, polished, and empty. Ordinary sound returned slowly, as if the world were pretending nothing had happened. The return of normality felt like rescue, but it was only a pause long enough for relief to become carelessness.

The record after that is incomplete. Some of it comes from photographs. Some from timestamps. Some from people who heard something and later denied hearing it. What can be said with confidence is that the event did not end when the immediate danger stopped. It changed ownership. It moved from place to person, from witness to evidence, from evidence to habit. The warning survived because the threat survived inside the warning.

The security footage showed Mara stepping out alive, then showed a second Mara still inside the elevator, pressing every button with red fingers. That detail turned survival into implication. Mara had not escaped by solving the pattern. Mara had become part of the pattern's next method of approach. The thing had learned what a careful person would do, and that meant it could prepare for the next careful person.

The official explanation, if there was one, remained small. Faulty wiring. Stress. Hoax. Weather. Bad data. Trespassers. Sleep deprivation. People prefer explanations that do not require them to change their behavior. But the people closest to the event kept one habit afterward. They avoided the place, the object or the hour. They did not joke about it. They did not test it for friends. And whenever that same sound returned—elevator cables groaning, a soft arrival chime, and one slow drop of liquid hitting metal—they stopped talking until it passed.

When the chime rings now, nobody in that tower says which floor they want.

---

## Episode Metadata

**Episode number:** 140

**Primary title:** The Elevator That Asked for Blood

**Source title:** The Hungry Elevator

**Suggested thumbnail text:** IT ASKED FOR BLOOD

**Content disclosure:** Original supernatural thriller inspired by established folklore, urban-legend, liminal-horror, or cursed-media conventions.

**Narration word count:** 1151

**Estimated spoken duration:** 6.2–6.6 minutes before longer dramatic pauses; approximately 6.6–7.6 minutes with restrained sound design.

**Suggested tags:** elevator horror, office horror, scary story, haunted elevator, horror story, scary story, narrated horror, dark truth episodes, creepy story

**Hashtags:** #HorrorStory #ScaryStories #DarkTruthEpisodes

**Visual direction:** cinematic 16:9 illustrations with consistent character design, restrained dark-documentary horror tone, slow push-ins, selective parallax, visible environmental texture, readable facial fear, and a new visual beat every 6–10 seconds.
