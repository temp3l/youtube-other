# Horror Stories Episodes 140–189

Production-ready Markdown stories in the requested format.

| Episode | Title | Core rule | Words | Thumbnail text |
|---:|---|---|---:|---|
| 140 | The Elevator That Asked for Blood | If the elevator asks for a floor you did not press, do not answer it. | 1151 | IT ASKED FOR BLOOD |
| 141 | The Smiling Man on the Security Feed | If someone smiles directly into a camera that has no public access, do not zoom in. | 1141 | HE SAW ME |
| 142 | The Well Behind the Gas Station | Never drop money into the well unless you know exactly what you are paying for. | 1142 | DON'T PAY IT |
| 143 | The Postcard from the House I Never Visited | If a postcard shows your house from inside a window, do not turn the card over. | 1122 | NOT MY HOUSE |
| 144 | The Snowplow Found Fresh Skin | If the snowbank bleeds, turn the plow around without clearing it. | 1127 | THE SNOW BLED |
| 145 | The Classroom That Appeared at Midnight | If the class is already seated, do not write your name on the board. | 1117 | CLASS STARTED |
| 146 | The Woman in the Emergency Exit Sign | If the figure in the exit sign points the wrong way, do not follow it. | 1118 | WRONG EXIT |
| 147 | The Lake That Refused to Reflect Stars | If the lake reflects something that is not in the sky, leave before the moon rises. | 1123 | NO STARS |
| 148 | The Last VHS at the Video Store | Never rewind a tape that ends with your house on screen. | 1117 | DON'T REWIND |
| 149 | The Motel Bible Had My Name Written Inside | If your name appears in the motel Bible, do not sleep in that room. | 1121 | MY NAME INSIDE |
| 150 | The Drone Swarm Over Black Farm | If the drones begin circling without command, do not stand in the center. | 1113 | THEY CIRCLED ME |
| 151 | The Basement Window Looking Out to Sea | If the basement window shows water, do not open it. | 1098 | OCEAN BELOW |
| 152 | The Crow That Delivered Teeth | If the crow leaves teeth in your mailbox, do not count them. | 1114 | DON'T COUNT |
| 153 | The Door in the Hospital Ceiling | If the ceiling door opens, do not look up. | 1098 | DON'T LOOK UP |
| 154 | The Old GPS Route Through Nowhere | If the GPS says continue onto an unnamed road, turn around before the map disappears. | 1109 | ROUTE TO DEATH |
| 155 | The Wedding Guest No One Invited | If an uninvited guest appears in the seating chart, do not move their chair. | 1109 | UNINVITED |
| 156 | The Wardrobe That Returned Different Clothes | Never wear clothing returned by the wardrobe after midnight. | 1102 | DON'T WEAR IT |
| 157 | The Ice Cream Truck After Midnight | Do not buy anything from the truck after the music slows down. | 1107 | MIDNIGHT TRUCK |
| 158 | The Recording Booth With Another Voice | If the playback contains a sentence you did not read, do not record over it. | 1113 | NOT MY VOICE |
| 159 | The Cemetery Angel Changed Faces | If the angel statue has your face, leave before sunset. | 1095 | MY FACE IN STONE |
| 160 | The Laundromat Washer Full of Hair | If machine seven starts without payment, do not open it. | 1115 | MACHINE SEVEN |
| 161 | The Ambulance That Came Before the Call | If an ambulance arrives before you dispatch it, do not let them load the patient. | 1090 | TOO EARLY |
| 162 | The Red Light in the Cornfield | If the red light moves between rows, do not follow it. | 1123 | RED LIGHT MOVED |
| 163 | The Tenant Who Paid Rent in Teeth | Never accept rent from a tenant whose lease has no birth date. | 1118 | RENT IN TEETH |
| 164 | The Fire Alarm That Whispered Names | If a fire alarm whispers instead of beeps, evacuate without using the marked exits. | 1102 | IT WHISPERED NAMES |
| 165 | The Houseplants Grew Toward the Closet | If every plant bends toward one closed door, do not water anything. | 1106 | DON'T WATER THEM |
| 166 | The Bridge That Charges a Toll | If the toll collector has no face, pay with metal and never paper. | 1126 | PAY THE TOLL |
| 167 | The Voice Mail from Beneath the Bed | If a voicemail plays from under the bed, do not reach for the phone. | 1113 | UNDER THE BED |
| 168 | The Observatory Saw Something Looking Back | If the telescope tracks an object without coordinates, close the dome immediately. | 1105 | IT LOOKED BACK |
| 169 | The Dolls in the Flooded Church | If the dolls face the altar, leave before they turn around. | 1104 | THEY TURNED |
| 170 | The Face in Every Window | If the same face appears in more than one window, stop photographing. | 1102 | EVERY WINDOW |
| 171 | The Ninth Camper Returned | Count campers before dark. If there is one extra, do not ask who they are. | 1103 | COUNT AGAIN |
| 172 | The Grocery Aisle That Never Ends | If an aisle has no end cap, turn around before the shelves repeat. | 1107 | AISLE NEVER ENDS |
| 173 | The Station Clock Ran Backwards | If the station clock runs backward, do not wait for the next train. | 1103 | TIME RAN BACK |
| 174 | The Door with No Room Behind It | If a door has hinges but no room on the plan, do not knock. | 1114 | NO ROOM BEHIND |
| 175 | The Last Customer at the Barber Shop | Never cut the hair of a customer who casts no reflection. | 1117 | NO REFLECTION |
| 176 | The Tunnel Workers Heard a Choir | If the choir sings your name, stop drilling. | 1094 | THE ROCK SANG |
| 177 | The Hotel Pool on the Roof | If the rooftop pool is full after closing, do not swim alone. | 1104 | NO POOL HERE |
| 178 | The House Where Shoes Walk Alone | If the shoes face the door, do not stay the night. | 1099 | SHOES WALKED |
| 179 | The Phone Booth in the Field | If the phone booth rings in an empty field, do not answer with your name. | 1101 | DON'T ANSWER |
| 180 | The Power Outage That Moved House | During a blackout, never count rooms by touch. | 1103 | HOUSE MOVED |
| 181 | The Old Woman on the Traffic Camera | If the old woman appears at a red light, do not turn it green. | 1122 | DON'T TURN GREEN |
| 182 | The Message Written in Condensation | If a message appears on cold glass, do not wipe it away until you read the last word. | 1104 | READ IT ALL |
| 183 | The Train Seat Reserved for the Dead | If a reservation has no passenger name, do not seat anyone there. | 1107 | RESERVED FOR DEAD |
| 184 | The Quarry Siren | When the quarry siren sounds, leave before the echo answers. | 1096 | ECHO ANSWERED |
| 185 | The Window in the Floor | If a floor window shows someone looking up, do not step on the glass. | 1119 | LOOKING UP |
| 186 | The Funeral Procession That Followed Me Home | If a funeral procession has no headlights, do not overtake it. | 1122 | DON'T PASS IT |
| 187 | The Black Tent at the Campsite | If a black tent appears without stakes, do not assign the neighboring site. | 1100 | BLACK TENT |
| 188 | The Static That Learned to Breathe | If static begins breathing in sync with you, stop playback before it inhales first. | 1075 | STATIC BREATHED |
| 189 | The New Grave in My Backyard | If a grave appears on your property, do not read the marker aloud. | 1106 | TOMORROW'S DATE |
