# Episode 186 — The Funeral Procession That Followed Me Home

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak in natural English with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Begin calmly and build tension steadily.
- Keep dialogue grounded and believable.
- Slow slightly during discoveries and the final reveal.
- Use only subtle processing for supernatural voices.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave a brief silence before the final line.

### Episode-specific sound motif

Use turn signals, funeral tires on wet asphalt, and muffled organ music through closed windows. Keep the motif subtle and repeat it only at major escalation points.

# Narration Script

Leah passed the funeral procession once and saw it waiting outside her apartment an hour later.

Leah Marrow was a rideshare driver working in a rain-soaked city ring road after midnight when the first impossible detail appeared. It was not dramatic enough to make the night feel unreal immediately. That was the worst part. It entered the world like a maintenance issue, a customer complaint, a bad sensor, a tired mistake. Leah had seen enough long shifts and cheap equipment to distrust panic before evidence. So the first response was practical: check the obvious thing, document the time, keep one exit clear, and do not say anything out loud that would sound insane in the morning.

The detail was six black cars and a hearse driving without headlights, following the exact speed of whoever noticed them. It should have belonged to the building, the road, the room or the job in some harmless way. Instead, it behaved as if it had been waiting for someone professional enough to notice the difference. At first, Leah thought it was a late funeral transfer, a film shoot, or a group of mourners lost in the rain. That explanation helped for a few minutes. It gave Leah something ordinary to hold onto, and horror often survives longest when it wears the shape of a normal problem.

Then the normal problem answered back.

Every time she changed lanes, the procession changed with her, and the hearse's side window reflected her back seat as occupied. The change was small enough to be checked and clear enough to be feared. Leah wrote down the time, took a photograph, and tried to repeat the conditions. The second attempt made the situation worse. The sound returned first: turn signals, funeral tires on wet asphalt, and muffled organ music through closed windows. It did not come from a single direction. It moved through the place like a signal being passed from wall to wall, from object to object, learning where Leah stood.

That was when the first rule became clear, although nobody understood it completely yet: If a funeral procession has no headlights, do not overtake it. Like most useful warnings, it sounded too narrow to save a person and too specific to ignore. Leah did not believe in curses, but the human mind respects instructions that arrive before danger. The rule had the hard edge of something learned through loss.

Someone else already knew part of the story. An old taxi dispatcher said some processions collect drivers who cut through mourning because they are in a hurry to get home. The warning was not delivered like folklore. It sounded administrative, embarrassed, almost tired. It came from a person who had decided years earlier that explanation was less important than survival. When Leah asked for proof, there was no single clean answer, only records, omissions and old local habits that suddenly lined up too well.

Traffic cameras showed Leah's car driving alone, but audio captured organ music and seven sets of tires on wet road. That discovery changed the fear. Before then, the event could still be treated as an anomaly. After that, it became a pattern with witnesses. The evidence did not explain what was happening. It proved that disbelief was late. It proved that other people had reached the same point, made decisions under pressure, and left behind just enough for the next person to fail more intelligently.

Leah tried the reasonable solution first. Power was cut where power mattered. Doors were locked where doors existed. Calls were made, notes were taken, and every ordinary explanation was tested before being discarded. The problem respected none of it. When Leah parked in a brightly lit garage, the hearse backed into the space beside her without opening the gate. It did not behave like an animal, exactly. It behaved like a procedure. It had inputs, responses and thresholds. The more carefully Leah measured it, the more carefully it measured back.

The next escalation was personal. The phenomenon stopped occupying the setting and began using the setting to address Leah directly. Familiar words appeared in unfamiliar places. Reflections hesitated. A route that should have led away returned to a place already checked. Something knew which detail would make caution feel cruel, which voice would make a locked door feel like a moral failure, which memory would make the rule sound negotiable. That was the real attack. Not teeth. Not claws. Decision pressure.

A second attempt to escape failed for a different reason. The physical route remained available, but the meaning of the route changed. Leah could still walk, drive, call, unlock, delete, refuse or turn back, yet every choice seemed to satisfy one part of the pattern. That was when the rule became cruel rather than helpful. The safest action demanded stillness. The most human action invited the thing closer.

For a while, the plan appeared to work. Leah followed the narrow warning as literally as possible. No improvisation. No bargaining. No clever loophole. The space around the event became quiet. At sunrise, the garage was empty except for oil marks shaped like tire tracks. Ordinary sound returned slowly, as if the world were pretending nothing had happened. The return of normality felt like rescue, but it was only a pause long enough for relief to become carelessness.

The record after that is incomplete. Some of it comes from photographs. Some from timestamps. Some from people who heard something and later denied hearing it. What can be said with confidence is that the event did not end when the immediate danger stopped. It changed ownership. It moved from place to person, from witness to evidence, from evidence to habit. The warning survived because the threat survived inside the warning.

Leah opened her apartment door and found a funeral program slid beneath it, listing her as the driver. That detail turned survival into implication. Leah had not escaped by solving the pattern. Leah had become part of the pattern's next method of approach. The thing had learned what a careful person would do, and that meant it could prepare for the next careful person.

The official explanation, if there was one, remained small. Faulty wiring. Stress. Hoax. Weather. Bad data. Trespassers. Sleep deprivation. People prefer explanations that do not require them to change their behavior. But the people closest to the event kept one habit afterward. They avoided the place, the object or the hour. They did not joke about it. They did not test it for friends. And whenever that same sound returned—turn signals, funeral tires on wet asphalt, and muffled organ music through closed windows—they stopped talking until it passed.

Outside, the procession waited patiently with one door open.

---

## Episode Metadata

**Episode number:** 186

**Primary title:** The Funeral Procession That Followed Me Home

**Source title:** The Procession

**Suggested thumbnail text:** DON'T PASS IT

**Content disclosure:** Original supernatural thriller inspired by established folklore, urban-legend, liminal-horror, or cursed-media conventions.

**Narration word count:** 1122

**Estimated spoken duration:** 6.1–6.4 minutes before longer dramatic pauses; approximately 6.5–7.4 minutes with restrained sound design.

**Suggested tags:** funeral procession horror, rideshare horror, road horror, scary story, horror story, scary story, narrated horror, dark truth episodes, creepy story

**Hashtags:** #HorrorStory #ScaryStories #DarkTruthEpisodes

**Visual direction:** cinematic 16:9 illustrations with consistent character design, restrained dark-documentary horror tone, slow push-ins, selective parallax, visible environmental texture, readable facial fear, and a new visual beat every 6–10 seconds.
