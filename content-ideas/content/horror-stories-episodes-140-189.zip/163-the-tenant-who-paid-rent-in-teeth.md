# Episode 163 — The Tenant Who Paid Rent in Teeth

## Audio Generation Instructions

> Production directions only. Do not narrate headings, Markdown, metadata, or sound-effect labels.

- Use one consistent adult male narrator.
- Speak in natural English with a restrained dark-documentary tone.
- Target approximately 175–185 words per minute.
- Begin calmly and build tension steadily.
- Keep dialogue grounded and believable.
- Slow slightly during discoveries and the final reveal.
- Use only subtle processing for supernatural voices.
- Keep sound effects beneath narration and avoid loud jump scares.
- Leave a brief silence before the final line.

### Episode-specific sound motif

Use envelopes sliding under a door, teeth rattling in ceramic, and pipes knocking inside walls. Keep the motif subtle and repeat it only at major escalation points.

# Narration Script

Apartment 6C paid rent on time every month in a sealed envelope full of teeth.

Marisol Vega was a apartment building manager working in a prewar apartment block above a row of shuttered shops when the first impossible detail appeared. It was not dramatic enough to make the night feel unreal immediately. That was the worst part. It entered the world like a maintenance issue, a customer complaint, a bad sensor, a tired mistake. Marisol had seen enough long shifts and cheap equipment to distrust panic before evidence. So the first response was practical: check the obvious thing, document the time, keep one exit clear, and do not say anything out loud that would sound insane in the morning.

The detail was a locked apartment listed as occupied, though no resident had been seen in the building for years. It should have belonged to the building, the road, the room or the job in some harmless way. Instead, it behaved as if it had been waiting for someone professional enough to notice the difference. At first, Marisol thought the teeth were fake props, a threat from a debtor, or evidence of a crime. That explanation helped for a few minutes. It gave Marisol something ordinary to hold onto, and horror often survives longest when it wears the shape of a normal problem.

Then the normal problem answered back.

Every tooth came with exact rent, counted in enamel and roots, and the bank accepted the deposit slips without comment. The change was small enough to be checked and clear enough to be feared. Marisol wrote down the time, took a photograph, and tried to repeat the conditions. The second attempt made the situation worse. The sound returned first: envelopes sliding under a door, teeth rattling in ceramic, and pipes knocking inside walls. It did not come from a single direction. It moved through the place like a signal being passed from wall to wall, from object to object, learning where Marisol stood.

That was when the first rule became clear, although nobody understood it completely yet: Never accept rent from a tenant whose lease has no birth date. Like most useful warnings, it sounded too narrow to save a person and too specific to ignore. Marisol did not believe in curses, but the human mind respects instructions that arrive before danger. The rule had the hard edge of something learned through loss.

Someone else already knew part of the story. The previous manager said 6C had been in the building longer than any landlord and left only when overcharged. The warning was not delivered like folklore. It sounded administrative, embarrassed, almost tired. It came from a person who had decided years earlier that explanation was less important than survival. When Marisol asked for proof, there was no single clean answer, only records, omissions and old local habits that suddenly lined up too well.

Old ledgers showed rent paid in hair, nails, baby teeth, and once, a whole jaw marked late fee. That discovery changed the fear. Before then, the event could still be treated as an anomaly. After that, it became a pattern with witnesses. The evidence did not explain what was happening. It proved that disbelief was late. It proved that other people had reached the same point, made decisions under pressure, and left behind just enough for the next person to fail more intelligently.

Marisol tried the reasonable solution first. Power was cut where power mattered. Doors were locked where doors existed. Calls were made, notes were taken, and every ordinary explanation was tested before being discarded. The problem respected none of it. When Marisol refused the envelope, every tenant in the building woke with toothaches and identical dreams of Room 6C opening. It did not behave like an animal, exactly. It behaved like a procedure. It had inputs, responses and thresholds. The more carefully Marisol measured it, the more carefully it measured back.

The next escalation was personal. The phenomenon stopped occupying the setting and began using the setting to address Marisol directly. Familiar words appeared in unfamiliar places. Reflections hesitated. A route that should have led away returned to a place already checked. Something knew which detail would make caution feel cruel, which voice would make a locked door feel like a moral failure, which memory would make the rule sound negotiable. That was the real attack. Not teeth. Not claws. Decision pressure.

A second attempt to escape failed for a different reason. The physical route remained available, but the meaning of the route changed. Marisol could still walk, drive, call, unlock, delete, refuse or turn back, yet every choice seemed to satisfy one part of the pattern. That was when the rule became cruel rather than helpful. The safest action demanded stillness. The most human action invited the thing closer.

For a while, the plan appeared to work. Marisol followed the narrow warning as literally as possible. No improvisation. No bargaining. No clever loophole. The space around the event became quiet. She accepted one final payment and slipped an eviction notice under the door. Ordinary sound returned slowly, as if the world were pretending nothing had happened. The return of normality felt like rescue, but it was only a pause long enough for relief to become carelessness.

The record after that is incomplete. Some of it comes from photographs. Some from timestamps. Some from people who heard something and later denied hearing it. What can be said with confidence is that the event did not end when the immediate danger stopped. It changed ownership. It moved from place to person, from witness to evidence, from evidence to habit. The warning survived because the threat survived inside the warning.

The notice slid back immediately, folded around a key and a single tooth that matched Marisol's dental crown. That detail turned survival into implication. Marisol had not escaped by solving the pattern. Marisol had become part of the pattern's next method of approach. The thing had learned what a careful person would do, and that meant it could prepare for the next careful person.

The official explanation, if there was one, remained small. Faulty wiring. Stress. Hoax. Weather. Bad data. Trespassers. Sleep deprivation. People prefer explanations that do not require them to change their behavior. But the people closest to the event kept one habit afterward. They avoided the place, the object or the hour. They did not joke about it. They did not test it for friends. And whenever that same sound returned—envelopes sliding under a door, teeth rattling in ceramic, and pipes knocking inside walls—they stopped talking until it passed.

Apartment 6C was not behind on rent. It was collecting a deposit.

---

## Episode Metadata

**Episode number:** 163

**Primary title:** The Tenant Who Paid Rent in Teeth

**Source title:** The Tooth Tenant

**Suggested thumbnail text:** RENT IN TEETH

**Content disclosure:** Original supernatural thriller inspired by established folklore, urban-legend, liminal-horror, or cursed-media conventions.

**Narration word count:** 1118

**Estimated spoken duration:** 6.0–6.4 minutes before longer dramatic pauses; approximately 6.4–7.4 minutes with restrained sound design.

**Suggested tags:** apartment horror, tenant horror, teeth horror, scary story, horror story, scary story, narrated horror, dark truth episodes, creepy story

**Hashtags:** #HorrorStory #ScaryStories #DarkTruthEpisodes

**Visual direction:** cinematic 16:9 illustrations with consistent character design, restrained dark-documentary horror tone, slow push-ins, selective parallax, visible environmental texture, readable facial fear, and a new visual beat every 6–10 seconds.
