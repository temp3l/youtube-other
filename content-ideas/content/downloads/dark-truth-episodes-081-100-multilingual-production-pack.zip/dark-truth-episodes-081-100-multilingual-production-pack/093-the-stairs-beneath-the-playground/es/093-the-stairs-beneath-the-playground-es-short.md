# Short 093 — Encontraron unas escaleras bajo el parque infantil

## Instrucciones para generar el audio

- Usa la misma voz del episodio completo.
- Empieza inmediatamente, sin introducción.
- Habla a unas 180 palabras por minuto.
- Pronuncia la última frase algo más despacio.

# Guion de narración

La historia comienza con un detalle imposible en un lugar aparentemente normal. Regresa a la misma hora, reacciona a la atención y se vuelve más personal con cada aparición. La amenaza sigue una regla. Necesita una respuesta, una invitación, un nombre, una puerta abierta o un momento en el que nadie esté mirando. La única posibilidad de escapar consiste en descubrir una incoherencia que la amenaza no pueda copiar correctamente. Justo antes de escapar, la amenaza utiliza una voz o un recuerdo familiar para que la decisión equivocada parezca segura. La última pista demuestra que el peligro no fue destruido. Solamente encontró una forma más silenciosa de permanecer cerca.

---

## Metadatos del episodio

**Episode:** 093

**Primary title:** Encontraron unas escaleras bajo el parque infantil

**Thumbnail text:** THE STAIRS WENT DOWN

**Description:** Encontraron unas escaleras bajo el parque infantil.

**Hashtags:** #Shorts #HistoriaDeTerror #HistoriasDeMiedo #DarkTruthEpisodes

**Target duration:** approximately 45–65 seconds

**Format:** 9:16, 1080 × 1920
