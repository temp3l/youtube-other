# Short 088 — La caméra neuf montrait un gardien inexistant

## Instructions de génération audio

- Utilisez la même voix que pour l’épisode complet.
- Commencez immédiatement, sans introduction.
- Parlez à environ 180 mots par minute.
- Ralentissez légèrement sur la dernière phrase.

# Texte de narration

L’histoire commence par un détail impossible dans un lieu apparemment ordinaire. Il revient à la même heure, réagit à l’attention et devient plus personnel à chaque apparition. La menace obéit à une règle. Elle a besoin d’une réponse, d’une invitation, d’un nom, d’une porte ouverte ou d’un instant où personne ne regarde. La seule possibilité de fuite consiste à identifier une incohérence que la menace ne peut pas reproduire correctement. Juste avant la fuite, la menace utilise une voix ou un souvenir familier pour rendre le mauvais choix rassurant. Le dernier indice prouve que le danger n’a pas été détruit. Il a seulement trouvé une manière plus discrète de rester à proximité.

---

## Métadonnées de l’épisode

**Episode:** 088

**Primary title:** La caméra neuf montrait un gardien inexistant

**Thumbnail text:** CAMERA 9 WAS LIVE

**Description:** La caméra neuf montrait un gardien inexistant.

**Hashtags:** #Shorts #HistoireDHorreur #HistoiresEffrayantes #DarkTruthEpisodes

**Target duration:** approximately 45–65 seconds

**Format:** 9:16, 1080 × 1920
