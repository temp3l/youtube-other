# Short 088 — Kamera Neun zeigte einen Wachmann, den es nicht gab

## Anweisungen zur Audiogenerierung

- Verwende dieselbe Stimme wie in der langen Episode.
- Beginne sofort ohne Einleitung.
- Sprich ungefähr 180 Wörter pro Minute.
- Sprich den letzten Satz etwas langsamer.

# Sprechtext

Die Geschichte beginnt mit einem unmöglichen Detail an einem scheinbar gewöhnlichen Ort. Es kehrt zur gleichen Zeit zurück, reagiert auf Aufmerksamkeit und wird mit jeder Wiederholung persönlicher. Die Bedrohung folgt einer Regel. Sie benötigt eine Antwort, eine Einladung, einen Namen, eine geöffnete Tür oder einen Moment, in dem niemand hinsieht. Die einzige Fluchtmöglichkeit besteht darin, eine Unstimmigkeit zu erkennen, die die Bedrohung nicht korrekt nachahmen kann. Unmittelbar vor der Flucht verwendet die Bedrohung eine vertraute Stimme oder Erinnerung, damit die falsche Entscheidung sicher wirkt. Der letzte Hinweis beweist, dass die Gefahr nicht zerstört wurde. Sie hat nur eine leisere Möglichkeit gefunden, in der Nähe zu bleiben.

---

## Episoden-Metadaten

**Episode:** 088

**Primary title:** Kamera Neun zeigte einen Wachmann, den es nicht gab

**Thumbnail text:** CAMERA 9 WAS LIVE

**Description:** Kamera Neun zeigte einen Wachmann, den es nicht gab.

**Hashtags:** #Shorts #Horrorgeschichte #Gruselgeschichten #DarkTruthEpisodes

**Target duration:** approximately 45–65 seconds

**Format:** 9:16, 1080 × 1920
