# Short 066 — Die Frau im roten Aufzug sprach nie

## Anweisungen zur Audiogenerierung

- Verwende dieselbe Stimme wie in der langen Episode.
- Beginne sofort ohne Einleitung.
- Sprich mit ungefähr 180 Wörtern pro Minute.
- Sprich den letzten Satz etwas langsamer.

# Sprechtext

Die Frau im roten Aufzug sprach nie. Was zunächst wie ein einzelner Vorfall wirkte, entwickelte sich zu einem Muster, das der Hauptfigur überallhin folgte. Zuerst, wird das erste unmögliche Detail entdeckt. Kurz darauf, kehrt das zentrale Motiv näher und deutlicher zurück. Bei der Untersuchung, enthüllen alte Aufzeichnungen frühere Opfer. Nach der Flucht, bleibt ein überprüfbarer Beweis zurück. Später, beweist das letzte Detail, dass die Gefahr nicht verschwunden ist.

---

## Episoden-Metadaten

**Episode:** 066

**Primary title:** Die Frau im roten Aufzug sprach nie

**Thumbnail text:** FOLGE IHR NICHT

**Description:** Die Frau im roten Aufzug sprach nie. Was zunächst wie ein einzelner Vorfall wirkte, entwickelte sich zu einem Muster, das der Hauptfigur überallhin folgte.

**Hashtags:** #Shorts #Horrorgeschichte #Gruselgeschichten #DarkTruthEpisodes

**Target duration:** approximately 45–65 seconds

**Format:** 9:16, 1080 × 1920
