# Dark Truth Episodes — Production Pack 021–040

This archive contains corrected production drafts for episodes 021 through 040.

Each episode folder contains:

- `*-full.md`: corrected full narration, audio directions, metadata and disclosure
- `*-short.md`: standalone vertical Short with narration and metadata

## Editorial changes applied

- Removed duplicated template passages and `Narration Script` leakage.
- Removed inconsistent protagonist names.
- Replaced the repeated doppelgänger plot with a topic-specific story.
- Aligned titles, plots, hooks, motifs and endings.
- Added clear fiction, folklore or cultural-context disclosures.
- Replaced oversized thumbnail text and ineffective single-word tags.
- Kept violence mostly implied and non-graphic.
- Made every Short self-contained rather than a cropped long-video excerpt.

## Cultural note

The Wendigo episode avoids presenting a generic antlered movie monster as an authoritative
representation of Indigenous traditions. The story frames the subject around hunger, greed,
isolation and the risks of flattening distinct traditions into one pop-culture creature.
