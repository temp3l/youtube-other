# Dark Truth Episodes — Episodes 101–110 Multilingual Production Pack

Languages: English, German, Spanish and French.

Each episode includes one corrected full production draft and one standalone Short in every language, with localized titles, thumbnail text, descriptions, narration directions and metadata.

The repeated-template drafts were cleaned of duplicate headings, inconsistent protagonist names and template leakage. Native-language review is recommended before publication for final phrasing and SEO.
