# Fixed Horror Story Production Pack — Episodes 090–139

This pack contains cleaned, production-oriented versions of all 50 episode Markdown files.

## Brief weakness outline

- The original files used the same visible story template across all episodes, making the middle sections feel repetitive.
- Several passages were too abstract for video production: “the system,” “the phenomenon,” “the pattern,” and similar wording replaced concrete action.
- Some generic safety lines did not fit the setting, especially phrases like “abandon the road” appearing outside road stories.
- Multiple scripts had grammar/casing issues, including lower-cased protagonist names, wrong articles, plural subjects using singular verbs, and “Dr.” used as a first name.
- The escalation beats needed clearer cause-and-effect: action, check, contradiction, consequence.
- The motifs were good, but needed to function as recurring signals rather than repeated decoration.

## Fix pass applied

- Rewrote the narration body of every episode while preserving the episode format, title, hook, rule, sound motif, metadata block, tags, and final reveal.
- Replaced the weakest repeated template sections with more concrete, incident-report-style escalation.
- Removed scenario-mismatched generic phrasing.
- Fixed common grammar, capitalization, article, and subject-agreement problems.
- Updated narration word counts and estimated spoken duration.


This ZIP contains 50 fully authored Markdown episode files in the requested production format.

- Episode 090 — The Door That Opens Backward (`090-the-door-that-opens-backward.md`)
- Episode 091 — The Woman in the Weather Alert (`091-the-woman-in-the-weather-alert.md`)
- Episode 092 — The Man Who Stands in Deleted Photos (`092-the-man-who-stands-in-deleted-photos.md`)
- Episode 093 — The Last Room on Floor Thirteen (`093-the-last-room-on-floor-thirteen.md`)
- Episode 094 — Do Not Count the Knocks (`094-do-not-count-the-knocks.md`)
- Episode 095 — The Road That Blinks Back (`095-the-road-that-blinks-back.md`)
- Episode 096 — The Mirror That Hates Liars (`096-the-mirror-that-hates-liars.md`)
- Episode 097 — The Emergency Broadcast From Tomorrow (`097-the-emergency-broadcast-from-tomorrow.md`)
- Episode 098 — The Tunnel With No Echo (`098-the-tunnel-with-no-echo.md`)
- Episode 099 — The House That Learned My Name (`099-the-house-that-learned-my-name.md`)
- Episode 100 — The Village That Sleeps at Noon (`100-the-village-that-sleeps-at-noon.md`)
- Episode 101 — The Cold Caller on Line Zero (`101-the-cold-caller-on-line-zero.md`)
- Episode 102 — We Found a Church Under the Basement (`102-we-found-a-church-under-the-basement.md`)
- Episode 103 — The Baby Monitor Picked Up the Wrong Room (`103-the-baby-monitor-picked-up-the-wrong-room.md`)
- Episode 104 — The Hiker Who Returned Twice (`104-the-hiker-who-returned-twice.md`)
- Episode 105 — The Painting That Finished Itself (`105-the-painting-that-finished-itself.md`)
- Episode 106 — The Train That Stops Between Stations (`106-the-train-that-stops-between-stations.md`)
- Episode 107 — The Black Dog at Mile Marker 44 (`107-the-black-dog-at-mile-marker-44.md`)
- Episode 108 — The Voice Beneath the Ice (`108-the-voice-beneath-the-ice.md`)
- Episode 109 — The Cemetery With Fresh Footprints (`109-the-cemetery-with-fresh-footprints.md`)
- Episode 110 — The Apartment That Skipped Night (`110-the-apartment-that-skipped-night.md`)
- Episode 111 — The Man in the Attic Repeats Everything (`111-the-man-in-the-attic-repeats-everything.md`)
- Episode 112 — The Museum Exhibit That Was Still Breathing (`112-the-museum-exhibit-that-was-still-breathing.md`)
- Episode 113 — The Staircase Under the Carpet (`113-the-staircase-under-the-carpet.md`)
- Episode 114 — The Last Message From My Dead Phone (`114-the-last-message-from-my-dead-phone.md`)
- Episode 115 — The Forest Where Cameras Face You (`115-the-forest-where-cameras-face-you.md`)
- Episode 116 — The Doorbell Camera Saw Me Outside (`116-the-doorbell-camera-saw-me-outside.md`)
- Episode 117 — The Lighthouse That Shines Inland (`117-the-lighthouse-that-shines-inland.md`)
- Episode 118 — The Neighbor Who Never Turned On Lights (`118-the-neighbor-who-never-turned-on-lights.md`)
- Episode 119 — The Prayer App That Answered (`119-the-prayer-app-that-answered.md`)
- Episode 120 — The River That Runs Uphill (`120-the-river-that-runs-uphill.md`)
- Episode 121 — The Hospital Room That Calls Back (`121-the-hospital-room-that-calls-back.md`)
- Episode 122 — The Cemetery Radio Station (`122-the-cemetery-radio-station.md`)
- Episode 123 — The Library Book That Rewrites You (`123-the-library-book-that-rewrites-you.md`)
- Episode 124 — The Man Beneath the Escalator (`124-the-man-beneath-the-escalator.md`)
- Episode 125 — The Graveyard Shift at the Doll Factory (`125-the-graveyard-shift-at-the-doll-factory.md`)
- Episode 126 — The Forgotten Floor in the Parking Garage (`126-the-forgotten-floor-in-the-parking-garage.md`)
- Episode 127 — The House Across the Lake (`127-the-house-across-the-lake.md`)
- Episode 128 — The Siren Test That Wouldn't Stop (`128-the-siren-test-that-wouldnt-stop.md`)
- Episode 129 — The Man Who Sold Empty Graves (`129-the-man-who-sold-empty-graves.md`)
- Episode 130 — The Motel Room With Two Bathrooms (`130-the-motel-room-with-two-bathrooms.md`)
- Episode 131 — The Drone Flew Back With Something Attached (`131-the-drone-flew-back-with-something-attached.md`)
- Episode 132 — The Funeral Home Doorbell (`132-the-funeral-home-doorbell.md`)
- Episode 133 — The Snowman Facing the Window (`133-the-snowman-facing-the-window.md`)
- Episode 134 — The Password Was My Death Date (`134-the-password-was-my-death-date.md`)
- Episode 135 — The Elevator Button Marked Home (`135-the-elevator-button-marked-home.md`)
- Episode 136 — The Lake House Guestbook (`136-the-lake-house-guestbook.md`)
- Episode 137 — The Church Bell Rang Underground (`137-the-church-bell-rang-underground.md`)
- Episode 138 — The Radio Tower That Repeated the Dead (`138-the-radio-tower-that-repeated-the-dead.md`)
- Episode 139 — The Man at the End of Every Dream (`139-the-man-at-the-end-of-every-dream.md`)
