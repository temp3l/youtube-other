# Execution paths

The paths below are deterministic source-surface reconstructions, not runtime traces. They identify package and CLI ownership present in this pack.

- CLI/workflow: apps/cli/src → application/workflow-engine → domain/persistence
- Story production: source-ingestion → story-localization/rewriting → speech/transcription → scene-planning/visual-planning → image-generation → rendering → metadata → youtube-upload
- History: apps/cli/src/history-commands.ts → @mediaforge/history → shared image-generation/rendering/metadata surfaces
- Dark Truth/Horror: apps/cli story commands → @mediaforge/dark-truth + story-localization → speech/image-generation/rendering
- Veronica: apps/cli Veronica commands → strategic-reinvention + veronica-media → speech/image-generation/rendering/metadata
- Education: apps/cli math commands → math-education + math-rendering → speech/rendering

Evidence files: 101 CLI sources and 1052 package sources.
