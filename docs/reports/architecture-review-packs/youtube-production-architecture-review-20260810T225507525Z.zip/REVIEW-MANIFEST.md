# Architecture review manifest

- UTC timestamp: 2026-08-10T22:55:07.525Z
- Profile: full
- Branch: codex/veronicabenini-positioning-visual-planning
- Commit SHA: 414e4ef662a0404af08ccc4ad5fb4498b55117de
- Working tree dirty: true
- Node: v24.18.0
- Detected applications: @mediaforge/api, @mediaforge/cli, @mediaforge/web
- Detected packages: @mediaforge/alignment, @mediaforge/api-sdk, @mediaforge/application, @mediaforge/config, @mediaforge/dark-truth, @mediaforge/domain, @mediaforge/dynamic-genre, @mediaforge/educational-renderer, @mediaforge/history, @mediaforge/image-generation, @mediaforge/math-education, @mediaforge/math-rendering, @mediaforge/metadata, @mediaforge/observability, @mediaforge/persistence, @mediaforge/process-runner, @mediaforge/rendering, @mediaforge/rewriting, @mediaforge/scene-planning, @mediaforge/shared, @mediaforge/source-ingestion, @mediaforge/speech, @mediaforge/story-localization, @mediaforge/strategic-reinvention, @mediaforge/testing, @mediaforge/transcript-cleaning, @mediaforge/transcription, @mediaforge/veronica-media, @mediaforge/visual-planning, @mediaforge/workflow-engine, @mediaforge/youtube-upload
- Detected genres: darktruth, history, other, veronica
- Semantic content hash: 95f933916a83feb98ab1e60ff9e5d44d624f8246be932cca56d1763c020ed550

## Architecture surface

- Required sources: 11
- Included: 11
- Sanitized: 1
- Missing: 0
- Excluded critical: 0
- Architecture surface completeness: PASS
- Secret safety: PASS

## Included source areas

- apps/api/src
- apps/cli/src
- apps/web/src
- config/speech-profiles/education-natural-teacher
- config/speech-profiles/veronica-elevenlabs-main-v1.example.json
- config/speech-profiles/veronicaBenini-genre-policy.example.yaml
- config/voices/dark-truth-documentary
- config/voices/strategic-reinvention
- docker/postgres/bootstrap.sql
- packages/alignment/src
- packages/api-sdk/src
- packages/application/src
- packages/config/src
- packages/dark-truth/src
- packages/domain/src
- packages/dynamic-genre/src
- packages/educational-renderer/src
- packages/history/src
- packages/image-generation/src
- packages/math-education/src
- packages/math-rendering/src
- packages/metadata/src
- packages/observability/src
- packages/persistence/src
- packages/process-runner/src
- packages/rendering/src
- packages/rewriting/src
- packages/scene-planning/src
- packages/shared/src
- packages/source-ingestion/src
- packages/speech/src
- packages/story-localization/src
- packages/strategic-reinvention/src
- packages/testing/src
- packages/transcript-cleaning/src
- packages/transcription/src
- packages/veronica-media/src
- packages/visual-planning/src
- packages/workflow-engine/src
- packages/youtube-upload/src
- scripts/ai-pack.mjs
- scripts/build-veronica-semantic-regression-archive.ts
- scripts/check-docs-diagrams.mjs
- scripts/cross-genre-production-hardening-dry-run.ts
- scripts/generate-history-v36-bounded-llm-shadow-review.ts
- scripts/generate-history-v36-relation-contract-docs.ts
- scripts/generate-history-v36-relation-ir-review.mjs
- scripts/generate-history-v36-representative-shadow-review.ts
- scripts/generate-veronica-bulk-approval-zip.ts
- scripts/generate-veronica-review-packs.ts
- scripts/history-regenerate-scene-images.mjs
- scripts/history-v34-regenerate-combined.mjs
- scripts/history-v35-acceptance-audit.mjs
- scripts/history-v35-combine-episode-range.mjs
- scripts/history-v35-combine-episodes-11-20-pack.mjs
- scripts/history-v35-combine-ten-episode-pack.mjs
- scripts/history-v35-modality-metrics.mjs
- scripts/history-v35-regenerate-combined.mjs
- scripts/history-v35-regenerate-p0-episodes.mjs
- scripts/history-v35-representative-audit.mjs
- scripts/history-v35-spatial-semantic-delta.mjs
- scripts/lib/verification-command-policy.mjs
- scripts/lib/verification-session-state.mjs
- scripts/produce-veronica-short.mjs
- scripts/remote-render-worker.mjs
- scripts/render-docs-diagrams.mjs
- scripts/reslice-narration-segments.mjs
- scripts/run-affected-workspace-command.mjs
- scripts/run-eslint.mjs
- scripts/run-with-telemetry.mjs
- scripts/youtube-auth.ts
- scripts/youtube-auth.unit.test.ts
- vitest.e2e.config.ts
- vitest.integration.config.ts
- vitest.unit.config.ts

## Representative samples

- darktruth-long: repository/content-ideas/content/dark-truth-episodes/batches/slb-20260710034438503-001/batch-plan.json
  - Selection: Canonical production root is preferred when known; otherwise the first lexicographically sorted eligible metadata artifact for the discovered genre and variant is selected. No readiness status is trusted as a selection authority.
- history-long: repository/content-packs/youtube-history-10-video-story-pack/manifest.json
  - Selection: Canonical production root is preferred when known; otherwise the first lexicographically sorted eligible metadata artifact for the discovered genre and variant is selected. No readiness status is trusted as a selection authority.
- other-math-long: repository/assets/math-teacher/alex/v1/manifest.json
  - Selection: Canonical production root is preferred when known; otherwise the first lexicographically sorted eligible metadata artifact for the discovered genre and variant is selected. No readiness status is trusted as a selection authority.
- veronica-long: repository/episodes/l01-why-being-good-at-your-job-isnt-enough/locales/en/full/canonical-timing.v1.json
  - Selection: Canonical production root is preferred when known; otherwise the first lexicographically sorted eligible metadata artifact for the discovered genre and variant is selected. No readiness status is trusted as a selection authority.
- veronica-short: repository/episodes/l01-s01-being-good-isnt-enough/locales/de/short/renders/vertical/final-media-validation.json
  - Selection: Canonical production root is preferred when known; otherwise the first lexicographically sorted eligible metadata artifact for the discovered genre and variant is selected. No readiness status is trusted as a selection authority.

## Major exclusions

- excluded by secret-safety scan
- excluded generated/cache/media directory

## Missing evidence

- Bulk media, provider caches, credentials, and unsafe or oversized files are intentionally not archived.
- A missing genre/variant is reported as missing rather than fabricated.

> Existing automated PASS results, readiness statuses, semantic scores, blocker counts, hashes, timing validations, architecture reports, and prior audit conclusions are included as evidence only. They must not be assumed correct by the independent reviewer.
