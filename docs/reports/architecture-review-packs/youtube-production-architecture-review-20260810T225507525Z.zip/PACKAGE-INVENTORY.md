# Package inventory

## @mediaforge/api
- Path: repository/apps/api/package.json
- Workspace dependencies: @mediaforge/api-sdk, @mediaforge/application, @mediaforge/config, @mediaforge/domain, @mediaforge/dynamic-genre, @mediaforge/persistence, @mediaforge/shared, @mediaforge/speech, @mediaforge/youtube-upload
- Public exports: not declared
- Role evidence: application/CLI

## @mediaforge/cli
- Path: repository/apps/cli/package.json
- Workspace dependencies: @mediaforge/alignment, @mediaforge/api-sdk, @mediaforge/application, @mediaforge/config, @mediaforge/dark-truth, @mediaforge/domain, @mediaforge/dynamic-genre, @mediaforge/history, @mediaforge/image-generation, @mediaforge/math-education, @mediaforge/math-rendering, @mediaforge/metadata, @mediaforge/observability, @mediaforge/persistence, @mediaforge/process-runner, @mediaforge/rendering, @mediaforge/rewriting, @mediaforge/scene-planning, @mediaforge/shared, @mediaforge/source-ingestion, @mediaforge/speech, @mediaforge/story-localization, @mediaforge/strategic-reinvention, @mediaforge/testing, @mediaforge/transcript-cleaning, @mediaforge/transcription, @mediaforge/veronica-media, @mediaforge/visual-planning, @mediaforge/workflow-engine, @mediaforge/youtube-upload
- Public exports: not declared
- Role evidence: application/CLI

## @mediaforge/web
- Path: repository/apps/web/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/shared
- Public exports: not declared
- Role evidence: application/CLI

## mediaforge
- Path: repository/package.json
- Workspace dependencies: none
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/alignment
- Path: repository/packages/alignment/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/shared
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/api-sdk
- Path: repository/packages/api-sdk/package.json
- Workspace dependencies: none
- Public exports: .
- Role evidence: shared platform

## @mediaforge/application
- Path: repository/packages/application/package.json
- Workspace dependencies: @mediaforge/config, @mediaforge/dark-truth, @mediaforge/domain, @mediaforge/history, @mediaforge/math-education, @mediaforge/workflow-engine
- Public exports: ., ./errors.js
- Role evidence: shared platform

## @mediaforge/config
- Path: repository/packages/config/package.json
- Workspace dependencies: @mediaforge/domain
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/dark-truth
- Path: repository/packages/dark-truth/package.json
- Workspace dependencies: @mediaforge/config, @mediaforge/domain, @mediaforge/image-generation, @mediaforge/process-runner, @mediaforge/rendering, @mediaforge/shared, @mediaforge/speech, @mediaforge/story-localization, @mediaforge/visual-planning, @mediaforge/workflow-engine
- Public exports: not declared
- Role evidence: genre-specific

## @mediaforge/domain
- Path: repository/packages/domain/package.json
- Workspace dependencies: none
- Public exports: ., ./visual-retention/treatment-catalog.js
- Role evidence: shared platform

## @mediaforge/dynamic-genre
- Path: repository/packages/dynamic-genre/package.json
- Workspace dependencies: @mediaforge/shared
- Public exports: .
- Role evidence: shared platform

## @mediaforge/educational-renderer
- Path: repository/packages/educational-renderer/package.json
- Workspace dependencies: none
- Public exports: ., ./contracts, ./errors
- Role evidence: shared platform

## @mediaforge/history
- Path: repository/packages/history/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/metadata, @mediaforge/shared, @mediaforge/workflow-engine
- Public exports: .
- Role evidence: genre-specific

## @mediaforge/image-generation
- Path: repository/packages/image-generation/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/history, @mediaforge/observability, @mediaforge/process-runner, @mediaforge/shared, @mediaforge/story-localization, @mediaforge/workflow-engine
- Public exports: ., ./focal-metadata.js, ./shorts-image-strategy.js
- Role evidence: shared platform

## @mediaforge/math-education
- Path: repository/packages/math-education/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/observability, @mediaforge/shared, @mediaforge/speech, @mediaforge/workflow-engine
- Public exports: ., ./canonical-json.js, ./timing.js
- Role evidence: genre-specific

## @mediaforge/math-rendering
- Path: repository/packages/math-rendering/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/math-education, @mediaforge/process-runner, @mediaforge/rendering, @mediaforge/shared, @mediaforge/speech
- Public exports: not declared
- Role evidence: genre-specific

## @mediaforge/metadata
- Path: repository/packages/metadata/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/observability, @mediaforge/process-runner, @mediaforge/shared
- Public exports: ., ./delivery-bundle
- Role evidence: shared platform

## @mediaforge/observability
- Path: repository/packages/observability/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/shared, @mediaforge/visual-planning
- Public exports: ., ./telemetry.js
- Role evidence: shared platform

## @mediaforge/persistence
- Path: repository/packages/persistence/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/shared
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/process-runner
- Path: repository/packages/process-runner/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/observability, @mediaforge/shared
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/rendering
- Path: repository/packages/rendering/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/process-runner, @mediaforge/shared
- Public exports: ., ./composition-contract.js
- Role evidence: shared platform

## @mediaforge/rewriting
- Path: repository/packages/rewriting/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/observability, @mediaforge/process-runner, @mediaforge/shared
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/scene-planning
- Path: repository/packages/scene-planning/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/shared
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/shared
- Path: repository/packages/shared/package.json
- Workspace dependencies: @mediaforge/domain
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/source-ingestion
- Path: repository/packages/source-ingestion/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/shared
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/speech
- Path: repository/packages/speech/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/observability, @mediaforge/process-runner, @mediaforge/shared, @mediaforge/story-localization
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/story-localization
- Path: repository/packages/story-localization/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/observability, @mediaforge/shared, @mediaforge/workflow-engine
- Public exports: ., ./locale-edition
- Role evidence: shared platform

## @mediaforge/strategic-reinvention
- Path: repository/packages/strategic-reinvention/package.json
- Workspace dependencies: @mediaforge/config, @mediaforge/domain, @mediaforge/shared, @mediaforge/veronica-media, @mediaforge/workflow-engine, @mediaforge/youtube-upload
- Public exports: .
- Role evidence: shared platform

## @mediaforge/testing
- Path: repository/packages/testing/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/shared
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/transcript-cleaning
- Path: repository/packages/transcript-cleaning/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/observability, @mediaforge/process-runner, @mediaforge/shared
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/transcription
- Path: repository/packages/transcription/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/observability, @mediaforge/process-runner, @mediaforge/shared
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/veronica-media
- Path: repository/packages/veronica-media/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/metadata, @mediaforge/observability, @mediaforge/process-runner, @mediaforge/rendering, @mediaforge/shared, @mediaforge/source-ingestion, @mediaforge/story-localization, @mediaforge/visual-planning, @mediaforge/youtube-upload
- Public exports: .
- Role evidence: genre-specific

## @mediaforge/visual-planning
- Path: repository/packages/visual-planning/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/shared
- Public exports: not declared
- Role evidence: shared platform

## @mediaforge/workflow-engine
- Path: repository/packages/workflow-engine/package.json
- Workspace dependencies: @mediaforge/domain, @mediaforge/shared
- Public exports: .
- Role evidence: shared platform

## @mediaforge/youtube-upload
- Path: repository/packages/youtube-upload/package.json
- Workspace dependencies: @mediaforge/config, @mediaforge/domain, @mediaforge/metadata, @mediaforge/observability, @mediaforge/shared
- Public exports: ., ./generic-media-publish, ./multilingual-audio-capability, ./publication-intent, ./publish-approval, ./strategic-publish-routing
- Role evidence: shared platform
