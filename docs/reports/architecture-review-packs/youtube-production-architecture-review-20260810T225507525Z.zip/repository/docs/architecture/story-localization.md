# Story Localization

## Purpose

This subsystem handles structured English full rewrites, localized full rewrites, and localized or English short rewrites from canonical source stories. It is separate from the older episode-production commands, even though both flows can feed the same episode workspace structure.

## Entry Points

- `apps/cli/src/story-localization-commands.ts`
- `apps/cli/src/story-full-rewrite-command.ts`
- `apps/cli/src/story-short-rewrite-command.ts`
- `apps/cli/src/story-analysis-command.ts`

## Main Services

- `packages/story-localization/src/story-localization.service.ts`
- `packages/story-localization/src/short-rewrite.service.ts`
- Supporting modules handle source discovery, deterministic source cleaning, prompt building, canonical fact extraction, cache reads and writes, batch manifests, validation, and artifact rendering.
- `packages/story-localization/src/story-artifact-model.ts` adds an additive normalized `StoryIR`, `StoryArtifactVariant`, and `StoryOutputConstraints` model for future migration work. Baseline details live in `docs/plans/story-ir-and-artifact-variant-modeling.md`.
- `packages/story-localization/src/genre-policy.ts`, `full-story-contract.ts`, `character-rename.service.ts`, `narration-constraints.ts`, and `stable-json.ts` now own deterministic story constraints: genre policy resolution, full-story contract construction, persisted character pseudonymization, fast narration pacing defaults, duration-derived short word ranges, and canonical hashing/serialization.
- `packages/story-localization/src/story-generation-preflight.ts` owns deterministic token-budget preflight for narration model requests before sync or batch provider submission.
- `packages/story-localization/src/canonical-story-contract.ts` is the typed canonical narrative boundary. `story-contract-preflight.ts` rejects malformed critical narrative fields before prompt compilation; legacy prose mechanics enter only through the adapter in the canonical-contract module.
- `packages/story-localization/src/story-prompt-compiler.ts` is the canonical narration prompt compiler for full and short variants. It records section and event metrics, rejects contradictory task/schema contracts, and enforces hard prompt budgets.
- `packages/story-localization/src/horror-affect-plan.ts` derives a versioned, source-grounded Dark Truth affect strategy from the canonical story contract, mechanics, and beats. It remains separate from `StoryIR`, adds no provider call, and is governed by the canonical-English full-story rollout mode.
- `packages/story-localization/src/model-resolution.ts` owns configured/resolved/actual model comparison, approved fallback evaluation, and retryable provider-error classification.

## Ordered Stages

1. Source discovery and cleaning
   Canonical English sources are discovered, the exact original source is preserved, production-only source contamination is removed conservatively, and `source-cleaning-report.json` records hashes, removed segments, flagged segments, and cleaner versions.
   Short rewrites that derive from generated full-story markdown persist their cleaning sidecars separately as `cleaned-short-story.md`, `original-short-story.md`, and `short-story-cleaning-report.json` so they do not overwrite canonical source-cleaning artifacts.
2. Source parsing
   Cleaned canonical sources are parsed into structured story input. Metadata sections are no longer required for cleaned narration sources.
3. Canonical fact extraction
   Fact extraction prefers structured mechanics, strips provenance and hash markers, and records whether facts came from a structured contract, canonical scene, legacy inference, or fallback extraction. Opening impossible details, escalation evidence, climax, final reveal, and immutable ending lines are distinct fact kinds.
4. Deterministic character pseudonymization
   Human characters are mapped once per episode to fictionalized names through a deterministic scored candidate pool. The persisted rename map is attached to the canonical full artifact and reused unchanged by localized full rewrites, short rewrites, repair, and regeneration.
5. StoryIR policy and contract modeling
   Typed genre policies and full-story contracts are derived deterministically from validated `StoryIR`. The contract now carries the authoritative character rename map and narration constraints used downstream.
   `professional-story-contracts.ts` defines the runtime-validated immutable-facts, supernatural-mechanics, experiment, 12–16 beat, editorial-review, narration-metrics, Short-contract, repair-scope, stage-gate, and complete cache-identity contracts. Critical mechanics, beat, or deterministic narration issues prevent readiness.
   The structured supernatural mechanic separates trigger, activation effect, interaction requirement, cost, interaction ending, exceptions, limits, failed-response discoveries, threat capabilities or migration, and climax use.
6. Prompt construction
   Prompt builders pseudonymize model-facing source narration, facts, written messages, and StoryIR before any provider call. Typed module ownership checks reject metadata, audio/TTS, scene, image, render, thumbnail, and publication-owned prompt modules before any provider call.
   Narration, localization, metadata, scene planning, validation, and repair are discriminated task types. Narration-only schemas cannot request metadata. Only selected events and relevant locale policy fragments are emitted.
   Eligible canonical English Dark Truth fiction can derive a deterministic `HorrorAffectPlan`: one concrete audience question, beat-level knowledge changes, source-supported response narrowing, rule discovery, local tension/release bands, emotional cost, causal continuity, and an earned payoff. `off` omits planning, `shadow` (the default) builds and validates the plan without changing provider request text or narration cache identity, and `enforce` emits the plan directives and includes their version/hash in the prompt fingerprint. The versioned plan envelope is persisted canonically at `<episode>/en/full/horror-affect-plan.json`; local inspection classifies it as `missing`, `current`, `stale`, or `invalid`, and sync/batch preparation reuses current bytes or refreshes non-current state before provider work. Unsupported response evidence is omitted or rejected locally rather than promoted into the prompt.
7. Token-budget preflight
   The compiled request is checked locally against model context limits, model output limits, expected output requirements, schema overhead, and a safety reserve. Blocked requests do not call the provider.
8. OpenAI structured generation
   The services call the Responses API with schema-backed output formats and configurable model, reasoning, and token settings.
9. Validation and repair
   Generated output is checked for schema validity, authoritative-name reuse, original-name leakage, message preservation, duration or word-count constraints, and filler or editorial drift. Repair prompts reuse the same rename map and do not choose fresh pseudonyms.
   Professional narration validation rejects meta-writing, editorial commentary, unresolved alternatives, generic character/evidence/stake placeholders, abstract escalation, and explanation after the final reveal. `READY_WITH_MINOR_EDITS` is advisory and blocks downstream work unless a content profile explicitly opts in.
   Analysis V2 may authorize one bounded beat or beat-range affect repair only for a typed local omission or contradiction with valid paragraph evidence, cited existing modifiable beat IDs, and explicit protected facts. Missing central questions, unsupported rules, arbitrary climaxes, cross-story causal failures, and incompatible payoffs regenerate the full artifact or block at a Short parent boundary.
   Source, lineage, accepted-ending, rename-map, canonical-identity, duration, narration-only, and affect-projection failures take precedence. Repair instructions lock parent hashes, immutable facts, unaffected beats, the selected Short/localization projection, word/duration budgets, and narration ownership; the complete applicable contract is rerun after the single repair attempt.
10. Cache writes and artifact materialization
    Cache entries, production artifacts, narration-only canonical JSON artifacts, compatibility markdown, JSON sidecars, and debug artifacts are persisted into episode output directories. Canonical lineage now includes the character-rename-map hash so dependent artifacts invalidate when the rename contract changes.

11. Production analysis
    `stories analyze` reads a persisted story artifact, evaluates production readiness, writes `story-production-analysis.json` beside the target story, and exposes the current or stale state through inspect/status surfaces without regenerating story content. V1 remains the default and readable contract. Operator-selected V2 adds evidence-bearing information-gap, response-narrowing, surprise, continuity, coping, tension-modulation, and presence dimensions in shadow/advisory mode. V2 validates paragraph spans and existing affect-plan semantic IDs; its scores cannot change production thresholds or override source, lineage, accepted-ending, rename-map, canonical-identity, duration, narration-only, or affect-projection failures.

12. Controlled evaluation and rollout
    `horror-evaluation-rollout.ts` provides an offline, versioned control plane rather than another story pipeline. It immutably persists the evaluation manifest before outcome import, derives separate seeded blind packets for full stories and Shorts, validates non-secret rater provenance, and accepts only explicitly imported aggregate audience metrics with a matching authorization record. It never fetches YouTube data.
    Retention-curve area, early retention, average percentage viewed, and ending retention are story outcomes. CTR is title/thumbnail evidence unless those inputs were controlled. Undersized strata are exploratory. The decision artifact records every source-plan gate, confidence, regressions, cost, failures, stale-cache behavior, dissent, scope, and approval. Missing decisions or approval remain `shadow`; promotion cannot bypass a gate. Rollback emits only a configuration transition, retains evaluation artifacts, makes no provider call, and never rewrites accepted stories.

## Downstream Ownership Boundaries

- Validated narration is the upstream owner for downstream metadata and audio stages.
- OpenAI speech generation is now split into a staged narration owner under `audio narration`. It consumes localized story markdown, writes target-specific artifacts under `locales/<locale>/<variant>/audio/narration/`, and publishes only compatibility audio outputs when rollout mode is `new`.
- Metadata is owned by `@mediaforge/metadata` and persists its own parent narration fingerprint, model/config fingerprint, prompt/schema fingerprint, status, and failure metadata.
- Audio instructions and TTS are owned by `@mediaforge/speech` and persist their own narration fingerprint, voice/config fingerprints, dependency fingerprint, and failure metadata.
- Metadata or audio failures do not invalidate narration and do not route through narration repair policy.
- Scene/image/render/publication remain separate downstream owners; Task 14 owns their boundary work.

## Localized Unicode Policy

- Localized narration, titles, descriptions, metadata, tags, and TTS input must preserve native Unicode characters. Content text is normalized only to Unicode NFC.
- ASCII cleanup is allowed only for slugs, filenames, IDs, and provider-safe asset names. Do not reuse slug helpers for human-readable localized content.
- Localization prompts explicitly require natural accents, diacritics, umlauts, ß, ñ, ç, inverted Spanish punctuation, and other language-specific characters.
- Unicode quality validation runs after generation/import and before Markdown materialization is consumed by TTS or video production. German has a hard gate for obvious ASCII transliteration or long German text with no umlauts/ß; Spanish, French, Portuguese, Italian, and future languages use softer warnings for suspicious long ASCII-only text.
- Add new language validators in `packages/story-localization/src/localized-content-text.ts` by defining native-character patterns, suspicious ASCII replacement terms, and a word threshold. Keep auto-correction limited to safe NFC normalization.

## Authored Scripts And Compatibility Markdown

- Authored full scripts resolve from `episodes/<episode-slug>/languages/script-<language>.md`.
- Authored Short scripts, when they differ from the full script, resolve from `episodes/<episode-slug>/languages/short/script-<language>.md`.
- The shared authored-script resolver rejects stale duplicate layouts such as root `script.md`, `en/full/script.md`, or `<language>/full/script.md` instead of selecting the first match.
- Combined markdown projections may still be readable for migration tooling, but they are not the canonical persistence source.
- Compatibility rendering can combine independently persisted narration, metadata, and audio artifacts, but those combined markdown files are not the canonical persistence source.
- For already-generated episodes, migrate audio by keeping the existing story markdown unchanged, running `audio narration prepare`, `plan`, `generate`, `assemble`, and `validate` first in `shadow` for the target locale and variant, inspecting `quality-gate.json`, then rerunning the same stages in `new` with `--resume` to promote `mastered-narration.wav` to `audio/narration.wav`. Existing compatibility markdown remains valid and does not need regeneration unless the story text changes.

## Staged Narration Observability

- Narration telemetry events include `episodeId`, `language`, `variant`, `chunkId`, `stage`, `model`, `voice`, `attempt`, `latencyMs`, `inputCharacters`, `outputBytes`, optional `generatedSeconds`, `cacheDecision`, `validationResult`, `retryClass`, `failureClass`, `regeneration`, `fallbackUsed`, and a cost estimate when telemetry pricing is configured.
- Detail fields redact secret-like keys, raw audio keys, story text, full text, and chunk text. Batch status also redacts API keys, bearer tokens, credentials, and text-bearing error fragments.
- Cost controls are cache-first: `--resume` reuses completed staged artifacts, chunk cache hits avoid provider calls, `--dry-run` writes nothing, `--validation-only` avoids generation and assembly, `--concurrency <n>` bounds local chunk synthesis, and voice benchmarking is capped with `--max-samples`.
- Operator reports live beside the staged target: `quality-gate.json`, `quality-gate.md`, `generation-metadata.json`, chunk validation reports under `chunks/`, and cache records under the narration root. Voice benchmark reports live in `voice-benchmark.json`.

## Narration Pace

- Story rewrites default to the project `fast` narration pace while retaining a typed `normal` preset for future reuse.
- Fast defaults are language-specific and currently set to `en 190/205`, `de 180/195`, `es 190/205`, `fr 185/198`, and `pt 190/205` words per minute for `full/short`.
- Short word ranges are no longer hardcoded independently. They are derived from the active short duration window and target WPM in one typed utility, and the resulting constraints are shared by prompt compilation and validation.
- Full-story defaults derive from the shared 330-660 second editorial window, targeting roughly 10 minutes at the language profile pace. Application code, never model diagnostics, owns narration word counts and duration estimates.

## Full Localization Fidelity

- Canonical full narration is projected into ordered `beat-NNN` semantic beats plus a validated story-mechanics contract before localization. Beat IDs remain structured evidence and are never rendered into narration.
- In horror affect `enforce` mode, localized full narration also receives one compact versioned projection of the accepted question, rule, response/proof, cost, climax, and payoff IDs. It preserves semantic causality and protected facts while allowing locale-native syntax, cadence, idiom, and paragraph rhythm; it never creates a locale-specific plot or provider call.
- Enforced localized output reports evidence references for every semantic ID. Missing responses, changed rules, unearned surprises, altered payoffs, new immutable facts, and parent-plan lineage mismatches fail deterministically before persistence. Source-fidelity and lineage failures remain hard failures.
- The projection and parent-plan lineage are included in enforced prompt/schema/cache identity and localized result/fidelity sidecars. Staleness can distinguish projection version, parent plan, accepted canonical fingerprint, semantic-ID set, and projection-content changes.
- `off` and `shadow` omit the projection and preserve the previous localized request schema, prompt fingerprint, and cache identity. Sync and batch localization compile through the same projection-aware prompt helper.
- A completed canonical English artifact persists an accepted snapshot with `canonicalStoryId`, `canonicalRevision`, `canonicalContentHash`, and `canonicalContractHash`. Localized-full preflight rejects absent, unaccepted, or contract-mismatched parent snapshots. Snapshot fields remain optional only when reading legacy artifacts.
- Localized structured output must declare preserved beat IDs, mechanics, emotional cost, climax/rule connection, final consequence, and localized metadata. Acceptance uses language-specific spoken-duration ratios, semantic beat coverage, named-character presence, English leakage, and metadata checks.
- Generator preservation booleans are diagnostics only; deterministic validation computes acceptance independently. Spoken dialogue is localized naturally, while physical inscriptions, device text, proper names, and callback phrases have separate policies.
- The default localization profile requires complete canonical beat coverage and a spoken-duration ratio of 85–115 percent.
- A severe duration loss, including a roughly 30 percent adaptation, forces full-stage regeneration. Missing mechanics or final consequences cannot pass as ready.
- Localization cache entries use cache schema v3 and fidelity policy v2. Older localized entries without fidelity validation metadata are unverified and cannot resume.

## Token-Budget Preflight

- Full generation, localization, short generation, targeted repair, and Task 06-owned batch request construction use one preflight module.
- Estimates are deterministic and offline. Known model families use the local OpenAI-compatible estimator; unknown models use a conservative fallback and emit diagnostics.
- Budgets track input estimate, expected output, requested `max_output_tokens`, model context window, model output limit, safety reserve, projected total, and remaining headroom separately.
- Blocked sync requests write preflight diagnostics under the episode `.localization-cache/preflight/` ledger and preserve existing valid artifacts.
- Blocked batch requests are recorded as `preflight-failed` manifest items and omitted from the JSONL input file, so they cannot be submitted unchanged.

## Prompt And Event Budgets

- Default hard prompt budgets are 48,000 characters / 14,000 estimated tokens for full narration and 24,000 characters / 8,000 estimated tokens for Shorts.
- Full prompts admit at most 20 canonical events and 20 scene beats by default. Short prompts admit at most six of each. Dependency expansion is bounded and stable; impossible mandatory closures produce causal diagnostics instead of unlimited expansion.
- Metrics include prompt characters, estimated tokens, selected, dependency-expanded, and emitted event counts, scene-beat count, prompt-section count, duplicate-section count, and largest section sizes.
- Prompt inspection is provider-free: callers can inspect the compiled prompt metrics and redacted section-size report. A hard-budget failure produces an empty provider payload.

## Short Horror Affect Projection

- Canonical English Shorts reuse the accepted, persisted full-story horror affect plan. A strict deterministic projection keeps one question, one established rule, one source-backed response or proof, one costly climax, and the accepted payoff with their original affect-plan IDs.
- `off` and `shadow` preserve the existing Short provider request, prompt fingerprint, adaptation-contract hash, and resume identity. `enforce` embeds the projection in the existing Short adaptation contract and includes its strategy, parent-plan, selected-ID, and projection hashes in prompt/cache identity.
- Enforce mode rejects missing, stale, unsupported, or causally incomplete projections before Short generation. Repair and regeneration compile the same embedded projection, final-line contract, and character rename map instead of selecting a new chain.
- Projection lineage is persisted in the existing Short JSON sidecar. Resume explains parent-plan, selected-chain-ID, and projection-content changes as stale cache dependencies.

## Semantic Validation And Repair

- Paragraph count is advisory only. Coherence checks use canonical entities, action predicates, causal ordering, mechanic consistency, ending uniqueness, and absence of explanatory text after an immutable ending.
- Hook validation matches normalized story-specific characters, objects, locations, aliases, triggers, visible actions, and impossible details; it is not a fixed noun allowlist.
- Repair instructions calculate exact add/remove word ranges, list missing event IDs and mechanics, state immutable opening and ending text, and identify modifiable versus protected sections.
- `preserveImmutableFinalLine` removes commentary after an immutable ending, and byte-for-byte validation runs after repair.

## Model Resolution And Failure Policy

- Each provider response is compared against the configured and resolved model. Date-suffixed identities of the same model are accepted; a different model requires an explicit fallback policy and reason.
- Unapproved model fallback fails closed. Connection and transport failures remain retryable provider errors and never authorize a quality downgrade.
- Resolution records contain configured, resolved, and actual response model, fallback state, reason, and policy ID. Offline/mock mode is explicit.

## Resume and Idempotency

- Full localization checks cache state and existing outputs before regenerating.
- Short rewrites support overwrite versus resume semantics and use manifest updates plus file locks around persisted artifact state.
- Batch mode persists manifests and supports refresh, import, and retry of failed items instead of recomputing whole runs.
- Preflight fingerprints include model capability definitions, prompt/schema fingerprints, output caps, language, operation, source hash, and policy version; unchanged preflight failures are not retried unchanged.

## Debug Artifacts

- The services can persist prompt, request, response, and error artifacts for debugging.
- Those persisted payloads can be large. Do not load them by default during routine repo discovery; read them only for an active debugging task.

## Relevant Tests and Source References

- `packages/story-localization/src/story-localization.unit.test.ts`
- `packages/story-localization/src/story-localization.integration.test.ts`
- `packages/story-localization/src/story-localization.batch.integration.test.ts`
- `packages/story-localization/src/short-rewrite.service.unit.test.ts`
- `packages/story-localization/src/short-rewrite.unit.test.ts`
- `packages/story-localization/src/story-localization.service.ts`
- `packages/story-localization/src/short-rewrite.service.ts`
- `packages/story-localization/src/story-localization-cache.ts`
- `packages/story-localization/src/story-localization-batch-storage.ts`
