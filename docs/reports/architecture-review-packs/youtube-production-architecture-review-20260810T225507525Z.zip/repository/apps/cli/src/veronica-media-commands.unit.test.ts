import { describe, expect, it } from "vitest";
import { Command } from "commander";
import { registerVeronicaMediaCommands } from "./veronica-media-commands.js";

describe("veronica media commands", () => {
  it("registers the isolated Veronica media subcommands", () => {
    const program = new Command();
    registerVeronicaMediaCommands(program);
    const veronica = program.commands.find((command) => command.name() === "veronica-media");
    expect(veronica?.commands.map((command) => command.name())).toEqual([
      "metadata",
      "prepare-production",
      "images",
      "speech",
      "pilot",
      "run",
      "plan-positioning-series",
      "plan-positioning-calibration",
      "review-pack",
      "validate",
      "render",
    ]);
    const images = veronica?.commands.find((command) => command.name() === "images");
    const preparation = veronica?.commands.find((command) => command.name() === "prepare-production");
    expect(preparation?.options.map((option) => option.flags)).toContain("-L, --language <code>");
    expect(images?.commands.map((command) => command.name())).toEqual([
      "derive-image-prompts",
      "inspect-image-prompts",
      "review-pack",
      "generate",
    ]);
    const imageGenerate = images?.commands.find((command) => command.name() === "generate");
    const reviewPack = images?.commands.find((command) => command.name() === "review-pack");
    expect(imageGenerate?.options.map((option) => option.long)).toEqual(
      expect.arrayContaining([
        "--mode",
        "--concurrency",
        "--max-batch-size",
        "--refresh-image-prompt-brief",
      ]),
    );
    expect(reviewPack?.options.find((option) => option.long === "--review-pack-mode")?.defaultValue).toBe("compact");
    const speech = veronica?.commands.find((command) => command.name() === "speech");
    expect(speech?.commands.map((command) => command.name())).toEqual([
      "plan",
      "generate",
      "validate",
      "status",
    ]);
    expect(
      speech?.commands
        .find((command) => command.name() === "generate")
        ?.options.map((option) => option.long),
    ).toEqual(
      expect.arrayContaining([
        "--all-languages",
        "--all-variants",
        "--concurrency",
      ]),
    );
  });
});
