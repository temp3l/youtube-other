import path from "node:path";
import { Command } from "commander";
import { loadRuntimeConfig } from "@mediaforge/config";
import {
  buildWorkspacePlannedStoryWorkflowManifest,
  StoryWorkflowManifestStore,
  workflowManifestSchema,
  type StoryWorkflowManifest,
  type WorkflowId,
} from "@mediaforge/story-localization";
import {
  buildStoryPipelineStatusJson,
  formatStoryPipelineStatus,
} from "./story-pipeline-status-output.js";

export interface StoryPipelineCliOptions {
  readonly episode?: string;
  readonly locales?: string;
  readonly formats?: string;
  readonly outputRoot?: string;
  readonly resume?: string | boolean;
  readonly dryRun?: boolean;
  readonly costEstimate?: boolean;
  readonly batchMode?: "sync" | "batch" | "hybrid";
  readonly json?: boolean;
  readonly verbose?: boolean;
}

export interface StoryPipelineReadCliOptions {
  readonly episode?: string;
  readonly workflow?: string;
  readonly outputRoot?: string;
  readonly json?: boolean;
}

interface StoryPipelineIo {
  readonly stdout: Pick<typeof process.stdout, "write">;
}

function splitCsv(value: string | undefined): string[] | undefined {
  if (!value) {
    return undefined;
  }
  const entries = value
    .split(",")
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0);
  return entries.length > 0 ? entries : undefined;
}

async function maybeLoadResumedManifest(args: {
  readonly outputRoot: string;
  readonly episodeId: string;
  readonly resume: string | boolean | undefined;
}) {
  if (typeof args.resume !== "string" || args.resume.length === 0) {
    return null;
  }
  const store = new StoryWorkflowManifestStore(args.outputRoot, args.episodeId);
  return store.load(args.resume as WorkflowId);
}

function workspaceRootFromOutputRoot(outputRoot: string): string {
  return path.basename(outputRoot) === "episodes"
    ? path.dirname(outputRoot)
    : outputRoot;
}

async function buildCurrentWorkspacePlan(args: {
  readonly outputRoot: string;
  readonly episodeId: string;
  readonly locales?: readonly string[];
  readonly formats?: readonly string[];
}): Promise<StoryWorkflowManifest> {
  return buildWorkspacePlannedStoryWorkflowManifest({
    episodeId: args.episodeId,
    dryRun: true,
    ...(args.locales ? { locales: args.locales } : {}),
    ...(args.formats ? { formats: args.formats } : {}),
    workspaceRoot: workspaceRootFromOutputRoot(args.outputRoot),
  });
}

export async function commandStoriesPipeline(
  options: StoryPipelineCliOptions,
  io: StoryPipelineIo = { stdout: process.stdout }
): Promise<void> {
  if (!options.episode) {
    throw new Error("--episode is required.");
  }
  if (!options.dryRun) {
    throw new Error("stories pipeline currently supports planning with --dry-run only.");
  }
  const runtimeConfig = await loadRuntimeConfig();
  const outputRoot = path.resolve(options.outputRoot ?? runtimeConfig.workspaceDir);
  const locales = splitCsv(options.locales);
  const formats = splitCsv(options.formats);
  const planned = await buildCurrentWorkspacePlan({
    outputRoot,
    episodeId: options.episode,
    ...(locales !== undefined ? { locales } : {}),
    ...(formats !== undefined ? { formats } : {}),
  });
  const resumed = await maybeLoadResumedManifest({
    outputRoot,
    episodeId: planned.episodeId,
    resume: options.resume,
  });
  const manifest = workflowManifestSchema.parse(
    resumed ?? planned
  ) as StoryWorkflowManifest;
  const currentManifest: StoryWorkflowManifest | undefined = resumed
    ? planned
    : undefined;

  if (options.json) {
    io.stdout.write(`${JSON.stringify(manifest, null, 2)}\n`);
    return;
  }

  io.stdout.write(
    [
      `Workflow: ${manifest.workflowId}`,
      `Execution: ${manifest.executionId}`,
      `Episode: ${manifest.episodeId}`,
      `Locales: ${manifest.locales.join(", ")}`,
      `Formats: ${manifest.formats.join(", ")}`,
      `Planned stages: ${manifest.plannedStageCount}`,
      `Mode: ${options.batchMode ?? "hybrid"}`,
      currentManifest
        ? `Stale stages: ${buildStoryPipelineStatusJson(manifest, currentManifest).staleStages.length}`
        : null,
      options.costEstimate ? "Cost estimate: unavailable in dry-run skeleton" : null,
    ]
      .filter((line): line is string => line !== null)
      .join("\n") + "\n"
  );
}

async function loadWorkflowForRead(options: StoryPipelineReadCliOptions) {
  if (!options.episode) {
    throw new Error("--episode is required.");
  }
  if (!options.workflow) {
    throw new Error("--workflow is required.");
  }
  const runtimeConfig = await loadRuntimeConfig();
  const outputRoot = path.resolve(options.outputRoot ?? runtimeConfig.workspaceDir);
  const store = new StoryWorkflowManifestStore(outputRoot, options.episode);
  const manifest = await store.load(options.workflow as WorkflowId);
  if (!manifest) {
    throw new Error(`Workflow manifest not found: ${options.workflow}`);
  }
  return { manifest, outputRoot };
}

export async function commandStoriesPipelineStatus(
  options: StoryPipelineReadCliOptions,
  io: StoryPipelineIo = { stdout: process.stdout }
): Promise<void> {
  const { manifest, outputRoot } = await loadWorkflowForRead(options);
  const currentManifest = await buildCurrentWorkspacePlan({
    outputRoot,
    episodeId: manifest.episodeId,
    locales: manifest.locales,
    formats: manifest.formats,
  });
  if (options.json) {
    io.stdout.write(
      `${JSON.stringify(buildStoryPipelineStatusJson(manifest, currentManifest), null, 2)}\n`
    );
    return;
  }
  io.stdout.write(formatStoryPipelineStatus(manifest, currentManifest));
}

export async function commandStoriesPipelineInspect(
  options: StoryPipelineReadCliOptions,
  io: StoryPipelineIo = { stdout: process.stdout }
): Promise<void> {
  const { manifest } = await loadWorkflowForRead(options);
  io.stdout.write(`${JSON.stringify(manifest, null, 2)}\n`);
}

export function registerStoryPipelineCommand(storiesCommand: Command): void {
  const pipeline = storiesCommand
    .command("pipeline")
    .description("Plan the durable story workflow")
    .requiredOption("--episode <slug-or-number>", "episode slug or number")
    .option("--locales <comma-separated-locales>", "workflow locales")
    .option("--formats <comma-separated-formats>", "story formats")
    .option("--output-root <path>", "episode workspace root")
    .option("--resume [workflow-id]", "load an existing workflow manifest when available")
    .option("--dry-run", "plan without running stages")
    .option("--cost-estimate", "include dry-run cost estimate status")
    .option("--batch-mode <sync|batch|hybrid>", "provider execution mode", "hybrid")
    .option("--json", "print machine-readable workflow manifest")
    .option("--verbose", "enable verbose logging")
    .action((opts: StoryPipelineCliOptions) => {
      const rootOpts = storiesCommand.parent?.opts<StoryPipelineCliOptions>() ?? {};
      const dryRun = opts.dryRun ?? rootOpts.dryRun;
      const json = opts.json ?? rootOpts.json;
      const verbose = opts.verbose ?? rootOpts.verbose;
      return commandStoriesPipeline({
        ...rootOpts,
        ...opts,
        ...(dryRun !== undefined ? { dryRun } : {}),
        ...(json !== undefined ? { json } : {}),
        ...(verbose !== undefined ? { verbose } : {}),
      });
    });
  pipeline
    .command("status")
    .requiredOption("--episode <slug-or-number>", "episode slug or number")
    .requiredOption("--workflow <workflow-id>", "workflow id")
    .option("--output-root <path>", "episode workspace root")
    .option("--json", "print machine-readable report")
    .action((opts: StoryPipelineReadCliOptions) => {
      const rootOpts = storiesCommand.parent?.opts<StoryPipelineReadCliOptions>() ?? {};
      const json = opts.json ?? rootOpts.json;
      return commandStoriesPipelineStatus({
        ...rootOpts,
        ...opts,
        ...(json !== undefined ? { json } : {}),
      });
    });
  pipeline
    .command("inspect")
    .requiredOption("--episode <slug-or-number>", "episode slug or number")
    .requiredOption("--workflow <workflow-id>", "workflow id")
    .option("--output-root <path>", "episode workspace root")
    .option("--json", "accepted for command symmetry; inspect is always JSON")
    .action((opts: StoryPipelineReadCliOptions) => {
      const rootOpts = storiesCommand.parent?.opts<StoryPipelineReadCliOptions>() ?? {};
      const json = opts.json ?? rootOpts.json;
      return commandStoriesPipelineInspect({
        ...rootOpts,
        ...opts,
        ...(json !== undefined ? { json } : {}),
      });
    });
}
