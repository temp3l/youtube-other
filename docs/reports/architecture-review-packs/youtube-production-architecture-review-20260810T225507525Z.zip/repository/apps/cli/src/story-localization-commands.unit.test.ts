import fs from "node:fs/promises";
import path from "node:path";
import { Command } from "commander";
import { describe, expect, it, vi } from "vitest";

const createStoryLocalizationConfigMock = vi.hoisted(() =>
  vi.fn((config) => config)
);

vi.mock("@mediaforge/config", () => ({
  loadRuntimeConfig: vi.fn(async () => ({
    openAiLocalizationModel: "gpt-5.4-localize",
    openAiLocalizationReasoningEffort: "low",
    openAiLocalizationMaxOutputTokens: 12345,
    openAiValidatorModel: "gpt-5-validator",
    openAiValidatorReasoningEffort: "medium",
    openAiValidatorMaxOutputTokens: 9999,
    openAiMetadataModel: "gpt-5-metadata",
    openAiMetadataReasoningEffort: "high",
    openAiMetadataMaxOutputTokens: 8888,
    horrorAffectRolloutMode: "enforce",
  })),
}));

vi.mock("@mediaforge/story-localization", async () => {
  const actual = await vi.importActual<
    typeof import("@mediaforge/story-localization")
  >("@mediaforge/story-localization");
  return {
    ...actual,
    createStoryLocalizationConfig: createStoryLocalizationConfigMock,
  };
});

import {
  buildBatchConfig,
  buildCommandConfig,
  registerStoryLocalizationCommands,
} from "./story-localization-commands.js";

function commandNames(command: Command): string[] {
  return command.commands.map((entry) => entry.name()).sort();
}

describe("story localization command registration", () => {
  it("registers the documented story commands and batch commands", async () => {
    const program = new Command();
    registerStoryLocalizationCommands(program);

    const stories = program.commands.find(
      (command) => command.name() === "stories"
    );
    const batches = program.commands.find(
      (command) => command.name() === "stories:batches"
    );
    expect(stories).toBeDefined();
    expect(batches).toBeDefined();
    expect(
      program.commands.some((command) => command.name() === "story-short-evaluate")
    ).toBe(true);
    expect(commandNames(stories as Command)).toEqual([
      "analyze",
      "audio",
      "batch",
      "bootstrap-shared",
      "images",
      "inspect",
      "localize",
      "pipeline",
      "production",
      "render",
      "resume-images",
      "rewrite-full",
      "rewrite-short",
      "status",
      "sync-characters",
    ]);
    const storyBatch = (stories as Command).commands.find(
      (command) => command.name() === "batch"
    );
    expect(storyBatch).toBeDefined();
    expect(commandNames(storyBatch as Command)).toEqual([
      "download",
      "import",
      "plan",
      "retry-failed",
      "status",
      "submit",
      "sync",
      "todo",
      "validate",
    ]);
    expect(commandNames(batches as Command)).toEqual([
      "cancel",
      "completed",
      "expired",
      "failed",
      "find",
      "import",
      "import-ready",
      "latest",
      "list",
      "pending",
      "ready",
      "rebuild-index",
      "refresh",
      "retry-failed",
      "show",
      "status",
      "verify-index",
    ]);

    const docs = await fs.readFile(path.resolve("docs/cli.md"), "utf8");
    expect(docs).toContain("stories rewrite-full");
    expect(docs).toContain("stories rewrite-short");
    expect(docs).toContain("stories analyze");
    expect(docs).toContain("stories production status");
    expect(docs).toContain("stories production repair");
    expect(docs).toContain("stories production batch");
    expect(docs).toContain("stories batch todo");
    expect(docs).toContain("stories audio generate");
    expect(docs).toContain("stories images generate");
    expect(docs).toContain("stories render validate");
    expect(docs).toContain("stories:batches verify-index");
    expect(docs).toContain("node apps/cli/dist/index.js episode resume-images");
    expect(docs).not.toContain(
      "node apps/cli/dist/index.js episodes resume-images"
    );
  });

  it("routes localized full model and repair config through localization settings only", async () => {
    const config = await buildCommandConfig({});
    expect(config.model).toBe("gpt-5.4-localize");
    expect(config.reasoningEffort).toBe("low");
    expect(config.maxOutputTokens).toBe(12345);
    expect(config.retryMaxOutputTokens).toBe(12345);
    expect(config.repairModel).toBe("gpt-5.4-localize");
    expect(config.repairReasoningEffort).toBe("low");
    expect(config.repairMaxOutputTokens).toBe(12345);
    expect(config.horrorAffectRolloutMode).toBe("enforce");
  });

  it("keeps batch localized full config on the localization fallback family", async () => {
    const config = await buildBatchConfig({});
    expect(config.model).toBe("gpt-5.4-localize");
    expect(config.repairModel).toBe("gpt-5.4-localize");
    expect(config.maxOutputTokens).toBe(12345);
    expect(config.repairMaxOutputTokens).toBe(12345);
    expect(config.horrorAffectRolloutMode).toBe("enforce");
  });

  it("normalizes regional Spanish locale input to es", async () => {
    const config = await buildCommandConfig({ languages: "es-419" });
    expect(config.languages).toEqual(["es"]);
  });

  it("rejects legacy sp locale input with an actionable error", async () => {
    await expect(buildCommandConfig({ languages: "sp" })).rejects.toThrow(
      'Use "es" for Spanish.'
    );
  });
});
