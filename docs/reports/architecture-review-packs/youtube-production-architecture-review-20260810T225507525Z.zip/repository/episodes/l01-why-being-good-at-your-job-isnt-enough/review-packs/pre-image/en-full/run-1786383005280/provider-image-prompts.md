# UNAPPROVED — DO NOT SUBMIT

These provider-oriented prompts are intentionally blocked until human pre-image approval is recorded.

## scene-001

State complexity: SINGLE_STATE
Action owner: buyer
Visible thesis: When two credible professionals compete, the client chooses the clearer evidence even when the overlooked option has stronger underlying capability.

### Asset l01-cold_open-base

Text-free 16:9 Veronica long-form editorial sequence. Environment: consultation decision table with both candidates visible. Camera: 50mm seated client eye-line documentary. Must show: two contrasting unlabeled portfolios, selection token. Capture one stable condition: client reaches toward the clearer evidence while the stronger craft remains overlooked. Visible thesis: When two credible professionals compete, the client chooses the clearer evidence even when the overlooked option has stronger underlying capability. No readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-002

State complexity: MULTI_STATE_REQUIRED
Action owner: buyer
Visible thesis: Before direct interaction, a buyer filters broad professional options out and keeps the candidate whose visible signals show the clearest fit for the specific problem.

### Asset l01-v01-base

Text-free 16:9 Veronica long-form editorial sequence. Environment: occupation-neutral pre-contact evaluation space with separate candidate evidence surfaces. Camera: 50mm buyer-eye over-shoulder comparison followed by a focused evidence detail. Must show: unlabeled general evidence surfaces, one repeated focus pattern, buyer shortlist gesture. Sequence asset 1 of 2: show the initial condition and causal context without the later result. Visible thesis: Before direct interaction, a buyer filters broad professional options out and keeps the candidate whose visible signals show the clearest fit for the specific problem. Render only this sequence state as one image; do not render a storyboard, panel grid, readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

### Asset l01-v01-base-state-02

Text-free 16:9 Veronica long-form editorial sequence. Environment: occupation-neutral pre-contact evaluation space with separate candidate evidence surfaces. Camera: 50mm buyer-eye over-shoulder comparison followed by a focused evidence detail. Must show: unlabeled general evidence surfaces, one repeated focus pattern, buyer shortlist gesture. Sequence asset 2 of 2: show the resulting buyer-visible condition: a buyer scans many equally broad signals, recognizes and keeps the focused candidate before direct contact. Visible thesis: Before direct interaction, a buyer filters broad professional options out and keeps the candidate whose visible signals show the clearest fit for the specific problem. Render only this sequence state as one image; do not render a storyboard, panel grid, readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-003

State complexity: SINGLE_STATE
Action owner: buyer
Visible thesis: When many unrelated capabilities compete equally, a buyer cannot retrieve one clear association; one repeatedly recognizable expertise becomes memorable when the matching problem appears.

### Asset l01-v02-base

Text-free 16:9 Veronica long-form editorial sequence. Environment: quiet occupation-neutral recall setting with unlabeled evidence surfaces. Camera: 65mm close buyer profile with selective evidence-plane focus. Must show: unlabeled matching problem cue, one repeated evidence pattern, indistinct unrelated capability samples. Capture one stable condition: a buyer confronted with a matching problem remembers one repeated evidence pattern while unrelated capability samples remain indistinct. Visible thesis: When many unrelated capabilities compete equally, a buyer cannot retrieve one clear association; one repeatedly recognizable expertise is memorable when the matching problem appears. No readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-004

State complexity: DECISIVE_TRANSITION_MOMENT
Action owner: buyer
Visible thesis: One recognizable doorway gives the market immediate access to a broader range of real expertise instead of limiting the professional to one skill.

### Asset l01-v03-base

Text-free 16:9 Veronica long-form editorial sequence. Environment: real architectural threshold opening into a broad occupation-neutral expertise space. Camera: 38mm buyer-height threshold view with deep access into the broader space. Must show: one recognizable doorway, broad connected evidence areas beyond, occupation-neutral expert and buyer. Capture the instant in which the transition is already visible. Prior context: one clear doorway in the foreground reveals many connected evidence areas in the wider space beyond. Primary actor: the buyer. Current action: the buyer commits through the clear threshold. Emerging consequence: a focused relevant audience is visible beyond the doorway. Visible thesis: One recognizable doorway gives the market immediate access to a broader range of real expertise instead of limiting the professional to one skill. No readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-005

State complexity: DECISIVE_TRANSITION_MOMENT
Action owner: buyer
Visible thesis: When public signals reinforce the same recognizable expertise, a buyer understands the professional quickly; conflicting signals force interpretation work and make the buyer leave.

### Asset l01-v04-base

Text-free 16:9 Veronica long-form editorial sequence. Environment: paired occupation-neutral public encounter spaces with text-free evidence categories. Camera: 40mm locked landscape comparison at buyer eye level. Must show: repeated matching evidence pattern, conflicting evidence patterns, buyer recognition and departure reactions. Capture the instant in which the transition is already visible. Prior context: left: many unrelated signals with weak retrieval; right: one dominant clear association with visible adjacent branches. Primary actor: the buyer. Current action: a simultaneous split comparison holds the crowded signal field beside one clear route. Emerging consequence: one dominant association is recognizable while adjacent evidence branches from it. Visible thesis: When public signals reinforce the same recognizable expertise, a buyer understands the professional quickly; conflicting signals force interpretation work and make the buyer leave. No readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-006

State complexity: MULTI_STATE_REQUIRED
Action owner: buyer
Visible thesis: Genuine competence evidence becomes legible when it coherently supports one expertise, allowing the buyer to see a real value difference beyond price without mistaking image for substance.

### Asset l01-v05-base

Text-free 16:9 Veronica long-form editorial sequence. Environment: occupation-neutral evidence evaluation space with real process and outcome proof. Camera: 45mm alternating evidence-detail and buyer-reaction views. Must show: unlabeled process evidence, verifiable outcome evidence, equal price cues with different evidence clarity. Sequence asset 1 of 2: show the initial condition and causal context without the later result. Visible thesis: Genuine competence evidence is legible when it coherently supports one expertise, allowing the buyer to see a real value difference beyond price without mistaking image for substance. Render only this sequence state as one image; do not render a storyboard, panel grid, readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

### Asset l01-v05-base-state-02

Text-free 16:9 Veronica long-form editorial sequence. Environment: occupation-neutral evidence evaluation space with real process and outcome proof. Camera: 45mm alternating evidence-detail and buyer-reaction views. Must show: unlabeled process evidence, verifiable outcome evidence, equal price cues with different evidence clarity. Sequence asset 2 of 2: show the resulting buyer-visible condition: a buyer verifies genuine competence evidence, recognizes how the coherent evidence supports one expertise and chooses on visible value rather than price alone. Visible thesis: Genuine competence evidence is legible when it coherently supports one expertise, allowing the buyer to see a real value difference beyond price without mistaking image for substance. Render only this sequence state as one image; do not render a storyboard, panel grid, readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-007

State complexity: MULTI_STATE_REQUIRED
Action owner: expert
Visible thesis: Consistent evidence across repeated encounters teaches the market which problem to associate with the professional, while constantly changing signals prevent that association from being retrieved.

### Asset l01-v06-base

Text-free 16:9 Veronica long-form editorial sequence. Environment: sequence of distinct occupation-neutral public encounters linked by one repeated evidence pattern. Camera: 50mm repeated buyer-eye framing across changing encounter contexts. Must show: one recurring problem cue, consistent evidence pattern across contexts, inconsistent alternative signal set. Sequence asset 1 of 2: show the initial condition and causal context without the later result. Visible thesis: Consistent evidence across repeated encounters teaches the market which problem to associate with the professional, while constantly changing signals prevent that association from being retrieved. Render only this sequence state as one image; do not render a storyboard, panel grid, readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

### Asset l01-v06-base-state-02

Text-free 16:9 Veronica long-form editorial sequence. Environment: sequence of distinct occupation-neutral public encounters linked by one repeated evidence pattern. Camera: 50mm repeated buyer-eye framing across changing encounter contexts. Must show: one recurring problem cue, consistent evidence pattern across contexts, inconsistent alternative signal set. Sequence asset 2 of 2: show the resulting buyer-visible condition: the professional consistently presents evidence for one problem while a buyer recognizes the association across repeated encounters and cannot retrieve the constantly changing alternative. Visible thesis: Consistent evidence across repeated encounters teaches the market which problem to associate with the professional, while constantly changing signals prevent that association from being retrieved. Render only this sequence state as one image; do not render a storyboard, panel grid, readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-008

State complexity: MULTI_STATE_REQUIRED
Action owner: shared
Visible thesis: Comparing intended professional identity with an external client's actual association reveals a useful match or gap, which directs what the professional should reinforce or deliberately change.

### Asset l01-v07-base

Text-free 16:9 Veronica long-form editorial sequence. Environment: quiet feedback conversation with two independent text-free evidence selections and a visible adjustment area. Camera: 50mm conversational two-shot alternating with direct evidence comparison details. Must show: intended evidence selection, independent client evidence selection, matched and mismatched evidence pairs, revised future signal set. Sequence asset 1 of 2: show the initial condition and causal context without the later result. Visible thesis: Comparing intended professional identity with an external client's actual association reveals a useful match or gap, which directs what the professional should reinforce or deliberately change. Render only this sequence state as one image; do not render a storyboard, panel grid, readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

### Asset l01-v07-base-state-02

Text-free 16:9 Veronica long-form editorial sequence. Environment: quiet feedback conversation with two independent text-free evidence selections and a visible adjustment area. Camera: 50mm conversational two-shot alternating with direct evidence comparison details. Must show: intended evidence selection, independent client evidence selection, matched and mismatched evidence pairs, revised future signal set. Sequence asset 2 of 2: show the resulting buyer-visible condition: the professional defines intended value, an external client independently recognizes the current association, both compare the match or gap, and the professional adjusts future signals. Visible thesis: Comparing intended professional identity with an external client's actual association reveals a useful match or gap, which directs what the professional should reinforce or deliberately change. Render only this sequence state as one image; do not render a storyboard, panel grid, readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.
