# UNAPPROVED — DO NOT SUBMIT

These provider-oriented prompts are intentionally blocked until human pre-image approval is recorded.

## scene-001

State complexity: SINGLE_STATE
Action owner: not applicable

Text-free 16:9 Veronica long-form editorial sequence. Environment: consultation decision table with both candidates visible. Camera: 50mm seated client eye-line documentary. Must show: two contrasting unlabeled portfolios, selection token. Capture one stable condition: client reaches toward the clearer evidence while the stronger craft remains overlooked. Visible thesis:. No readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-002

State complexity: MULTI_STATE_REQUIRED
Action owner: not applicable

Text-free 16:9 Veronica long-form editorial sequence. Environment: workshop, shop floor, studio wall, or hospitality space; backstage production zone. Camera: 28mm high-corner documentary wide; elevated diagonal viewpoint. Must show: finished work, tools in use, expertise evidence artifact. MULTI-ASSET SEQUENCE REQUIRED: retain the semantic states as separately prepared assets or deterministic sequence events; do not submit this as one storyboard still. No readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-003

State complexity: SINGLE_STATE
Action owner: buyer

Text-free 16:9 Veronica long-form editorial sequence. Environment: procurement table or consultation waiting area; client point-of-decision zone. Camera: 45mm seated point-of-view; subjective client viewpoint. Must show: unlabeled portfolios, evidence samples, selection token, customer evidence artifact. Capture one stable condition: a decision maker selects between visible options. Visible thesis:. No readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-004

State complexity: DECISIVE_TRANSITION_MOMENT
Action owner: none

Text-free 16:9 Veronica long-form editorial sequence. Environment: dual-world editorial set; artifact archive zone. Camera: 40mm locked frontal comparison; lateral profile viewpoint. Must show: contrasting evidence sets, decision marker, generalist evidence artifact. Capture the instant in which the transition is already visible. Prior context: left: many unrelated signals with weak retrieval; right: one dominant clear association with visible adjacent branches. Primary actor: the simultaneous market comparison. Current action: a simultaneous split comparison holds the crowded signal field beside one clear route. Emerging consequence: one dominant association is recognizable while adjacent evidence branches from it. No readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-005

State complexity: SINGLE_STATE
Action owner: not applicable

Text-free 16:9 Veronica long-form editorial sequence. Environment: procurement table or consultation waiting area; peer-referral setting. Camera: 45mm seated point-of-view; compressed distant observation. Must show: unlabeled portfolios, evidence samples, selection token, category evidence artifact. Capture one stable condition: a broad field resolves into a legible category. Visible thesis:. No readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-006

State complexity: SINGLE_STATE
Action owner: not applicable

Text-free 16:9 Veronica long-form editorial sequence. Environment: case-study archive, exhibition rail, or results wall; field-work context. Camera: 35mm shallow diagonal dolly perspective; close foreground parallax. Must show: before- sample, prototype, testimonial portrait without text, brand evidence artifact. Capture one stable condition: observable proof accumulates toward trust. Visible thesis:. No readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-007

State complexity: SINGLE_STATE
Action owner: not applicable

Text-free 16:9 Veronica long-form editorial sequence. Environment: case-study archive, exhibition rail, or results wall; street-facing public threshold. Camera: 35mm shallow diagonal dolly perspective; low three-quarter viewpoint. Must show: before- sample, prototype, testimonial portrait without text, perceived evidence artifact. Capture one stable condition: multiple visible conditions produce one outcome. Visible thesis:. No readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.

## scene-008

State complexity: MULTI_STATE_REQUIRED
Action owner: not applicable

Text-free 16:9 Veronica long-form editorial sequence. Environment: large planning surface with real production materials; backstage production zone. Camera: 35mm oblique overhead; elevated diagonal viewpoint. Must show: movable modules, milestone tokens, thread, positioning evidence artifact. MULTI-ASSET SEQUENCE REQUIRED: retain the semantic states as separately prepared assets or deterministic sequence events; do not submit this as one storyboard still. No readable text, logos, UI, occupation proxy, generic stock pose, decorative abstraction, prism, light laboratory, or unexplained diagram.
