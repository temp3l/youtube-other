import fs from "node:fs/promises";
import { execFileSync } from "node:child_process";
import os from "node:os";
import path from "node:path";
import sharp from "sharp";
import { describe, expect, it, vi } from "vitest";
import {
  buildEpisodeLoadResult,
  buildLocalizedScenePlan,
  buildScenePlan,
  createApprovalRecord,
  discoverEpisodeSources,
  generateCanonicalImages,
  generateNarrationAudio,
  generateMockNarrationAudio,
  parseEpisodeSourceFile,
  retimeScenePlan,
  sliceSceneAudioFiles,
  buildSpeechPlan,
} from "./index.js";
import { scenePlanSchema } from "@mediaforge/domain";
import { hashFile } from "@mediaforge/shared";

const sourceRoot = path.resolve(
  "content-ideas/content/dark-truth-episodes-multilingual-production-pack"
);
const episode001EnglishFull = path.join(
  sourceRoot,
  "001-the-forbidden-village-where-japan-s-laws-do-not-apply",
  "en",
  "001-the-forbidden-village-where-japan-s-laws-do-not-apply-en-full.md"
);
const episode001GermanFull = path.join(
  sourceRoot,
  "001-the-forbidden-village-where-japan-s-laws-do-not-apply",
  "de",
  "001-the-forbidden-village-where-japan-s-laws-do-not-apply-de-full.md"
);
const episode001EnglishShort = path.join(
  sourceRoot,
  "001-the-forbidden-village-where-japan-s-laws-do-not-apply",
  "en",
  "001-the-forbidden-village-where-japan-s-laws-do-not-apply-en-short.md"
);

function probeDurationSeconds(filePath: string): number {
  return Number(
    execFileSync(
      "ffprobe",
      [
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        filePath,
      ],
      { encoding: "utf8" }
    ).trim()
  );
}

describe("dark-truth workflow", () => {
  it("discovers episode source files in stable order", async () => {
    const discoveries = await discoverEpisodeSources(sourceRoot);
    const episode001 = discoveries.find(
      (entry) => entry.episodeNumber === "001"
    );
    expect(episode001).toBeTruthy();
    expect(
      episode001?.candidates.filter(
        (candidate) => candidate.status === "present"
      )
    ).toHaveLength(8);
    expect(
      episode001?.candidates.every(
        (candidate) => candidate.status === "present"
      )
    ).toBe(true);
  });

  it("parses the episode 001 English full source", async () => {
    const parsed = await parseEpisodeSourceFile(episode001EnglishFull);
    expect(parsed.language).toBe("en");
    expect(parsed.artifactType).toBe("full");
    expect(parsed.narration).toContain("Kurobane");
    expect(parsed.metadata.primaryTitle).toContain(
      "Forbidden Japanese Village"
    );
    expect(parsed.metadata.format.aspectRatio).toBe("16:9");
    expect(parsed.analysis.generationEligibility).toBe("eligible");
    expect(parsed.productionInstructions.instructions).toContain(
      "dark-documentary tone"
    );
  });

  it("parses canonical authored full scripts under languages", async () => {
    const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "dark-truth-canonical-"));
    const canonicalPath = path.join(
      tempDir,
      "episodes",
      "001-the-forbidden-village-where-japan-s-laws-do-not-apply",
      "languages",
      "script-en.md"
    );
    await fs.mkdir(path.dirname(canonicalPath), { recursive: true });
    await fs.copyFile(episode001EnglishFull, canonicalPath);

    const parsed = await parseEpisodeSourceFile(canonicalPath);

    expect(parsed.episodeNumber).toBe("001");
    expect(parsed.episodeId).toBe(
      "001-the-forbidden-village-where-japan-s-laws-do-not-apply"
    );
    expect(parsed.language).toBe("en");
    expect(parsed.artifactType).toBe("full");
  });

  it("parses the episode 001 German full source", async () => {
    const parsed = await parseEpisodeSourceFile(episode001GermanFull);
    expect(parsed.language).toBe("de");
    expect(parsed.artifactType).toBe("full");
    expect(parsed.narration.length).toBeGreaterThan(0);
    expect(parsed.metadata.primaryTitle).toContain("verbotene");
    expect(parsed.metadata.format.aspectRatio).toBe("16:9");
  });

  it("splits the English short narration into multiple TTS-safe chunks", async () => {
    const parsed = await parseEpisodeSourceFile(episode001EnglishShort);
    const speechPlan = await buildSpeechPlan(parsed);
    expect(speechPlan.segments.length).toBeGreaterThan(1);
    expect(speechPlan.segments.at(-1)?.text).toContain("You let the wrong one leave.");
    expect(speechPlan.segments.every((segment) => segment.wordCount <= 70)).toBe(true);
  });

  it("parses canonical authored short scripts under languages/short", async () => {
    const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "dark-truth-canonical-"));
    const canonicalPath = path.join(
      tempDir,
      "episodes",
      "001-the-forbidden-village-where-japan-s-laws-do-not-apply",
      "languages",
      "short",
      "script-en.md"
    );
    await fs.mkdir(path.dirname(canonicalPath), { recursive: true });
    await fs.copyFile(episode001EnglishShort, canonicalPath);

    const parsed = await parseEpisodeSourceFile(canonicalPath);

    expect(parsed.episodeNumber).toBe("001");
    expect(parsed.episodeId).toBe(
      "001-the-forbidden-village-where-japan-s-laws-do-not-apply"
    );
    expect(parsed.language).toBe("en");
    expect(parsed.artifactType).toBe("short");
  });

  it("writes dry-run artifacts with sidecar subtitles only", async () => {
    const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "dark-truth-"));
    const outputRoot = path.join(tempDir, "episodes");
    const result = await buildEpisodeLoadResult(
      episode001EnglishFull,
      outputRoot
    );
    expect(await fs.stat(result.paths.analysisJson)).toBeTruthy();
    expect(await fs.stat(result.paths.subtitlesSrt)).toBeTruthy();
    expect(await fs.stat(result.paths.subtitlesVtt)).toBeTruthy();
    expect(result.subtitleManifest.burnedInSubtitles).toBe(false);
    expect(result.subtitleManifest.subtitleVideoFiltersUsed).toBe(false);
    expect(result.subtitleManifest.sidecarFiles).toContain(
      result.paths.subtitlesSrt
    );
    expect(result.analysis.visualSceneTargetPer10Minutes).toBe(100);
    expect(result.analysis.estimatedVisualSceneCount).toBeGreaterThan(0);
  });

  it("copies a source-pack character registry into the generated episode workspace", async () => {
    const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "dark-truth-characters-"));
    const sourceRoot = path.join(tempDir, "source");
    const outputRoot = path.join(tempDir, "episodes");
    const episodeSlug = "001-the-forbidden-village-where-japan-s-laws-do-not-apply";
    const sourceEpisodeDir = path.join(sourceRoot, episodeSlug);
    const sourceLanguageDir = path.join(sourceEpisodeDir, "en");
    await fs.mkdir(sourceLanguageDir, { recursive: true });
    const sourceFile = path.join(
      sourceLanguageDir,
      `${episodeSlug}-en-full.md`
    );
    await fs.copyFile(episode001EnglishFull, sourceFile);
    await fs.writeFile(
      path.join(sourceEpisodeDir, "characters.json"),
      JSON.stringify(
        {
          episodeId: episodeSlug,
          updatedAt: "2026-06-25T00:00:00.000Z",
          characters: [
            {
              id: "elena-ward",
              name: "Elena Ward",
              role: "main protagonist",
              physicalDescription: "A tired student with a practical late-night look.",
              ageRange: "20s",
              genderPresentation: "woman",
              face: {
                shape: "oval",
                skinTone: "light",
                eyeColor: "brown",
                eyebrows: "slightly arched",
                nose: "small",
                mouth: "neutral",
                distinguishingFeatures: ["subtle under-eye shadows"],
              },
              hair: {
                color: "dark brown",
                length: "medium",
                style: "slightly messy",
              },
              build: "slim",
              defaultWardrobe: {
                upperBody: "dark hoodie",
                lowerBody: "jeans",
                footwear: "sneakers",
                accessories: [],
                carriedObjects: ["phone"],
                colors: ["dark navy", "grey"],
              },
              continuityTraits: ["same tired expression"],
              referenceStatus: "missing",
            },
          ],
        },
        null,
        2
      )
    );

    await buildEpisodeLoadResult(sourceFile, outputRoot);

    const copiedCharacters = JSON.parse(
      await fs.readFile(
        path.join(outputRoot, episodeSlug, "shared", "characters.json"),
        "utf8"
      )
    ) as { characters: Array<{ id: string }> };
    expect(copiedCharacters.characters).toHaveLength(1);
    expect(copiedCharacters.characters[0]?.id).toBe("elena-ward");
  });

  it("creates approval records and preserves the approval state", async () => {
    const tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "dark-truth-review-")
    );
    const reviewDir = path.join(tempDir, "reviews", "en", "full");
    const approval = await createApprovalRecord(reviewDir, {
      episodeId: "001-the-forbidden-village-where-japan-s-laws-do-not-apply",
      language: "en",
      artifactType: "full",
      artifactPath: path.join(tempDir, "generation-manifest.json"),
      artifactSha256: "a".repeat(64),
      generationManifestSha256: "a".repeat(64),
      sourceSha256: "b".repeat(64),
      reviewer: "steph",
      reviewedAt: new Date().toISOString(),
      decision: "approved",
    });
    expect(approval.approvalState).toBe("human-approved");
    expect(approval.stale).toBe(false);
    const approvalFile = JSON.parse(
      await fs.readFile(path.join(reviewDir, "approval.json"), "utf8")
    ) as { approvalState?: string };
    expect(approvalFile.approvalState).toBe("human-approved");
  });

  it("keeps narration synthesis local unless paid providers are explicitly enabled", async () => {
    const tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "dark-truth-paid-tts-")
    );
    const outputRoot = path.join(tempDir, "episodes");
    const result = await buildEpisodeLoadResult(
      episode001EnglishFull,
      outputRoot
    );
    try {
      vi.stubEnv("DARK_TRUTH_ENABLE_PAID_PROVIDERS", "true");
      vi.stubEnv("OPENAI_API_KEY", "");
      await expect(
        generateMockNarrationAudio(
          path.join(
            outputRoot,
            "001-the-forbidden-village-where-japan-s-laws-do-not-apply",
            "en",
            "full"
          ),
          result.speechPlan
        )
      ).rejects.toThrow("OPENAI_API_KEY");
    } finally {
      vi.unstubAllEnvs();
    }
  });

  it("refuses episode narration generation unless paid providers are explicitly enabled", async () => {
    const tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "dark-truth-episode-tts-")
    );
    const outputRoot = path.join(tempDir, "episodes");
    const result = await buildEpisodeLoadResult(
      episode001EnglishFull,
      outputRoot
    );
    const episodeDir = path.join(
      outputRoot,
      "001-the-forbidden-village-where-japan-s-laws-do-not-apply",
      "en",
      "full"
    );
    vi.stubEnv("DARK_TRUTH_ENABLE_PAID_PROVIDERS", "false");
    await expect(
      generateNarrationAudio(episodeDir, result.speechPlan)
    ).rejects.toThrow("DARK_TRUTH_ENABLE_PAID_PROVIDERS=true");
    vi.unstubAllEnvs();
  });

  it("cleans stale narration segments before regenerating audio", async () => {
    const tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "dark-truth-stale-segments-")
    );
    const outputRoot = path.join(tempDir, "episodes");
    const result = await buildEpisodeLoadResult(
      episode001EnglishFull,
      outputRoot
    );
    const episodeDir = path.join(
      outputRoot,
      "001-the-forbidden-village-where-japan-s-laws-do-not-apply",
      "en",
      "full"
    );
    const segmentsDir = path.join(episodeDir, "audio", "segments-speech");
    await fs.mkdir(segmentsDir, { recursive: true });
    await fs.writeFile(path.join(segmentsDir, "segment-999.wav"), "stale");
    await fs.writeFile(
      path.join(segmentsDir, "segment-999.wav.tmp"),
      "temp"
    );
    const narrationPath = await generateMockNarrationAudio(
      episodeDir,
      result.speechPlan
    );
    expect((await fs.stat(narrationPath)).size).toBeGreaterThan(0);
    await expect(
      fs.stat(path.join(segmentsDir, "segment-999.wav"))
    ).rejects.toThrow();
    await expect(
      fs.stat(path.join(segmentsDir, "segment-999.wav.tmp"))
    ).rejects.toThrow();
    const manifest = JSON.parse(
      await fs.readFile(
        path.join(episodeDir, "audio", "narration-manifest.json"),
        "utf8"
      )
    ) as { segmentCount: number; speechPlanHash: string };
    expect(manifest.segmentCount).toBe(result.speechPlan.segments.length);
    expect(manifest.speechPlanHash).toHaveLength(64);
  }, 120000);

  it("adapts SpeechPlan narration through the staged pipeline while preserving compatibility outputs", async () => {
    const tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "dark-truth-narration-adapter-")
    );
    const outputRoot = path.join(tempDir, "episodes");
    const result = await buildEpisodeLoadResult(
      episode001EnglishShort,
      outputRoot
    );
    const episodeDir = path.join(
      outputRoot,
      "001-the-forbidden-village-where-japan-s-laws-do-not-apply",
      "en",
      "short"
    );
    try {
      vi.stubEnv("MEDIAFORGE_NARRATION_PIPELINE_MODE", "new");
      const narrationPath = await generateMockNarrationAudio(
        episodeDir,
        result.speechPlan
      );
      expect((await fs.stat(narrationPath)).size).toBeGreaterThan(0);
      const compatibilityManifest = JSON.parse(
        await fs.readFile(
          path.join(episodeDir, "audio", "narration-manifest.json"),
          "utf8"
        )
      ) as {
        adapterMode?: string;
        segmentCount?: number;
        canonicalManifestHash?: string;
      };
      expect(compatibilityManifest.adapterMode).toBe("new");
      expect(compatibilityManifest.segmentCount).toBe(result.speechPlan.segments.length);
      expect(compatibilityManifest.canonicalManifestHash).toHaveLength(64);
      await expect(
        fs.stat(
          path.join(
            outputRoot,
            "001-the-forbidden-village-where-japan-s-laws-do-not-apply",
            "locales",
            "en",
            "short",
            "audio",
            "narration",
            "chunk-manifest.json"
          )
        )
      ).resolves.toBeTruthy();
      const adapterStatus = JSON.parse(
        await fs.readFile(
          path.join(episodeDir, "audio", "narration-adapter-status.json"),
          "utf8"
        )
      ) as { fallbackUsed?: boolean; outputManifestHash?: string };
      expect(adapterStatus.fallbackUsed).toBe(false);
      expect(adapterStatus.outputManifestHash).toHaveLength(64);
    } finally {
      vi.unstubAllEnvs();
    }
  }, 120000);

  it("keeps canonical image generation local unless paid providers are explicitly enabled", async () => {
    const tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "dark-truth-paid-images-")
    );
    const outputRoot = path.join(tempDir, "episodes");
    const parsed = await parseEpisodeSourceFile(episode001EnglishFull);
    const scenePlan = buildScenePlan(
      parsed.narration,
      parsed.episodeId,
      parsed.artifactType
    );
    try {
      vi.stubEnv("DARK_TRUTH_ENABLE_PAID_PROVIDERS", "true");
      vi.stubEnv("OPENAI_API_KEY", "");
      await expect(
        generateCanonicalImages(
          path.join(
            outputRoot,
            "001-the-forbidden-village-where-japan-s-laws-do-not-apply",
            "shared"
          ),
          scenePlan
        )
      ).rejects.toThrow("OPENAI_API_KEY");
    } finally {
      vi.unstubAllEnvs();
    }
  });

  it("reuses existing shared full images instead of regenerating them", async () => {
    const tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "dark-truth-shared-images-")
    );
    const sharedDir = path.join(tempDir, "shared");
    const imageDir = path.join(sharedDir, "images", "generated");
    await fs.mkdir(imageDir, { recursive: true });
    const scenePlan = scenePlanSchema.parse({
      sourceId: "episode-fixture",
      scenes: [
        {
          id: "scene-001",
          sequenceNumber: 1,
          canonicalNarration: "A single reused scene.",
          sourceSegmentIds: ["scene-001"],
          estimatedDurationSeconds: 4,
          timing: { startSeconds: 0, endSeconds: 4 },
          visualPurpose: "introduce the setting",
          subject: "subject",
          action: "shown",
          setting: "setting",
          composition: "composition",
          cameraFraming: "wide shot",
          mood: "tense",
          continuityReferences: [],
          onScreenText: "",
          textRequirement: { required: false },
          negativeConstraints: [],
          aspectRatios: ["16:9"],
          imagePrompt: "existing prompt",
          expectedImageFilenames: ["scene-001__000000-000004__16x9.png"],
          qualityStatus: "draft",
        },
      ],
    });
    const existingPath = path.join(imageDir, "scene-001__000000-000004__16x9.png");
    await sharp({
      create: {
        width: 1536,
        height: 864,
        channels: 4,
        background: { r: 10, g: 20, b: 30, alpha: 1 },
      },
    })
      .png()
      .toFile(existingPath);
    const beforeHash = await hashFile(existingPath);

    const result = await generateCanonicalImages(sharedDir, scenePlan);

    const afterHash = await hashFile(existingPath);
    expect(afterHash).toBe(beforeHash);
    expect(result.assets).toHaveLength(1);
    expect(result.assets[0]).toBe(existingPath);
    const manifest = JSON.parse(
      await fs.readFile(result.imageManifestPath, "utf8")
    ) as {
      imageCount: number;
      assets: Array<{ filename: string; relativePath: string }>;
    };
    expect(manifest.imageCount).toBe(1);
    expect(manifest.assets[0]?.filename).toBe(
      "scene-001__000000-000004__16x9.png"
    );
    expect(manifest.assets[0]?.relativePath).toBe(
      "images/generated/scene-001__000000-000004__16x9.png"
    );
  });

  it("rejects existing shared full images with non-canonical dimensions", async () => {
    const tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "dark-truth-invalid-shared-images-")
    );
    const sharedDir = path.join(tempDir, "shared");
    const imageDir = path.join(sharedDir, "images", "generated");
    await fs.mkdir(imageDir, { recursive: true });
    const scenePlan = scenePlanSchema.parse({
      sourceId: "episode-fixture",
      scenes: [
        {
          id: "scene-001",
          sequenceNumber: 1,
          canonicalNarration: "A single reused scene.",
          sourceSegmentIds: ["scene-001"],
          estimatedDurationSeconds: 4,
          timing: { startSeconds: 0, endSeconds: 4 },
          visualPurpose: "introduce the setting",
          subject: "subject",
          action: "shown",
          setting: "setting",
          composition: "composition",
          cameraFraming: "wide shot",
          mood: "tense",
          continuityReferences: [],
          onScreenText: "",
          textRequirement: { required: false },
          negativeConstraints: [],
          aspectRatios: ["16:9"],
          imagePrompt: "existing prompt",
          expectedImageFilenames: ["scene-001__000000-000004__16x9.png"],
          qualityStatus: "draft",
        },
      ],
    });
    const existingPath = path.join(imageDir, "scene-001__000000-000004__16x9.png");
    await sharp({
      create: {
        width: 1024,
        height: 1024,
        channels: 4,
        background: { r: 10, g: 20, b: 30, alpha: 1 },
      },
    })
      .png()
      .toFile(existingPath);

    await expect(generateCanonicalImages(sharedDir, scenePlan)).rejects.toThrow(
      /expected=1536x864/
    );
  });

  it("uses the shared scene density target when building Dark Truth scene plans", () => {
    const narration = Array.from({ length: 180 }, (_, index) => `word${index + 1}`).join(" ");
    vi.stubEnv("VISUAL_SCENE_TARGET_PER_10_MINUTES", "20");
    try {
      const scenePlan = buildScenePlan(narration, "episode-fixture", "full");
      expect(scenePlan.scenes).toHaveLength(2);
      expect(scenePlan.scenes.every((scene) => scene.estimatedDurationSeconds >= 25 && scene.estimatedDurationSeconds <= 35)).toBe(true);
    } finally {
      vi.unstubAllEnvs();
    }
  });

  it("retimes scene plans to the actual narration duration", () => {
    const scenePlan = scenePlanSchema.parse({
      sourceId: "episode-fixture",
      scenes: [
        {
          id: "scene-001",
          sequenceNumber: 1,
          canonicalNarration: "First scene.",
          sourceSegmentIds: ["scene-001"],
          estimatedDurationSeconds: 4,
          timing: { startSeconds: 0, endSeconds: 4 },
          visualPurpose: "introduce the setting",
          textRequirement: { required: false },
          subject: "first scene",
          action: "shown",
          setting: "dark room",
          composition: "centered",
          cameraFraming: "wide shot",
          mood: "tense",
          continuityReferences: [],
          onScreenText: "",
          negativeConstraints: [],
          aspectRatios: ["16:9"],
          imagePrompt: "first scene",
          expectedImageFilenames: ["scene-001__000000-000004__16x9.png"],
          qualityStatus: "draft",
        },
        {
          id: "scene-002",
          sequenceNumber: 2,
          canonicalNarration: "Second scene.",
          sourceSegmentIds: ["scene-002"],
          estimatedDurationSeconds: 4,
          timing: { startSeconds: 4, endSeconds: 8 },
          visualPurpose: "close on the reveal",
          textRequirement: { required: false },
          subject: "second scene",
          action: "shown",
          setting: "dark room",
          composition: "centered",
          cameraFraming: "wide shot",
          mood: "tense",
          continuityReferences: ["scene-001"],
          onScreenText: "",
          negativeConstraints: [],
          aspectRatios: ["16:9"],
          imagePrompt: "second scene",
          expectedImageFilenames: ["scene-002__000004-000008__16x9.png"],
          qualityStatus: "draft",
        },
      ],
    });
    const retimed = retimeScenePlan(scenePlan, 10);
    expect(retimed.scenes[0]?.timing).toEqual({
      startSeconds: 0,
      endSeconds: 5,
    });
    expect(retimed.scenes[1]?.timing).toEqual({
      startSeconds: 5,
      endSeconds: 10,
    });
    expect(retimed.scenes[0]?.expectedImageFilenames[0]).toBe(
      "scene-001__000000-000005__16x9.png"
    );
    expect(retimed.scenes[1]?.expectedImageFilenames[0]).toBe(
      "scene-002__000005-000010__16x9.png"
    );
    expect(retimed.scenes[0]?.actualAudioDurationSeconds).toBe(5);
    expect(retimed.scenes[1]?.actualAudioDurationSeconds).toBe(5);
  });

  it("keeps localized scene beats aligned to canonical visual timing", () => {
    const canonical = scenePlanSchema.parse({
      sourceId: "episode-fixture",
      scenes: [
        {
          id: "scene-001",
          sequenceNumber: 1,
          canonicalNarration: "Emma kept hearing footsteps above her bedroom.",
          sourceSegmentIds: ["scene-001"],
          estimatedDurationSeconds: 3,
          timing: { startSeconds: 0, endSeconds: 3 },
          visualPurpose: "introduce the setting",
          textRequirement: { required: false },
          subject: "Emma",
          action: "hearing footsteps",
          setting: "bedroom",
          composition: "centered",
          cameraFraming: "wide shot",
          mood: "tense",
          continuityReferences: [],
          onScreenText: "",
          negativeConstraints: [],
          aspectRatios: ["16:9"],
          imagePrompt: "Emma hearing footsteps",
          expectedImageFilenames: ["scene-001__000000-000003__16x9.png"],
          qualityStatus: "draft",
        },
        {
          id: "scene-002",
          sequenceNumber: 2,
          canonicalNarration: "The estate agent insisted the house had no attic.",
          sourceSegmentIds: ["scene-002"],
          estimatedDurationSeconds: 5,
          timing: { startSeconds: 3, endSeconds: 8 },
          visualPurpose: "establish the premise",
          textRequirement: { required: false },
          subject: "estate agent",
          action: "insisted there was no attic",
          setting: "house",
          composition: "centered",
          cameraFraming: "wide shot",
          mood: "tense",
          continuityReferences: ["scene-001"],
          onScreenText: "",
          negativeConstraints: [],
          aspectRatios: ["16:9"],
          imagePrompt: "Estate agent says no attic",
          expectedImageFilenames: ["scene-002__000003-000008__16x9.png"],
          qualityStatus: "draft",
        },
      ],
    });
    const localized = buildLocalizedScenePlan(
      canonical,
      "Emma hoerte Nacht fuer Nacht Schritte ueber ihrem Schlafzimmer. Der Makler behauptete, das Haus habe keinen Dachboden."
    );
    expect(localized.scenes[0]?.timing).toEqual({ startSeconds: 0, endSeconds: 3 });
    expect(localized.scenes[1]?.timing).toEqual({ startSeconds: 3, endSeconds: 8 });
    expect(localized.scenes[0]?.canonicalNarration).toBe(
      "Emma hoerte Nacht fuer Nacht Schritte ueber ihrem Schlafzimmer."
    );
    expect(localized.scenes[1]?.canonicalNarration).toBe(
      "Der Makler behauptete, das Haus habe keinen Dachboden."
    );
  });

  it("slices narration audio into one scene-level audio file per scene id", async () => {
    const tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "dark-truth-scene-audio-")
    );
    const narrationPath = path.join(tempDir, "narration.wav");
    execFileSync(
      "ffmpeg",
      [
        "-y",
        "-f",
        "lavfi",
        "-i",
        "sine=frequency=440:sample_rate=24000:duration=3",
        narrationPath,
      ],
      { stdio: "ignore" }
    );
    const scenePlan = scenePlanSchema.parse({
      sourceId: "episode-fixture",
      scenes: [
        {
          id: "scene-001",
          sequenceNumber: 1,
          canonicalNarration: "First scene.",
          sourceSegmentIds: ["scene-001"],
          estimatedDurationSeconds: 1,
          timing: { startSeconds: 0, endSeconds: 1 },
          visualPurpose: "introduce the setting",
          textRequirement: { required: false },
          subject: "first scene",
          action: "shown",
          setting: "dark room",
          composition: "centered",
          cameraFraming: "wide shot",
          mood: "tense",
          continuityReferences: [],
          onScreenText: "",
          negativeConstraints: [],
          aspectRatios: ["16:9"],
          imagePrompt: "first scene",
          expectedImageFilenames: ["scene-001__000000-000001__16x9.png"],
          qualityStatus: "draft",
        },
        {
          id: "scene-002",
          sequenceNumber: 2,
          canonicalNarration: "Second scene.",
          sourceSegmentIds: ["scene-002"],
          estimatedDurationSeconds: 2,
          timing: { startSeconds: 1, endSeconds: 3 },
          visualPurpose: "close on the reveal",
          textRequirement: { required: false },
          subject: "second scene",
          action: "shown",
          setting: "dark room",
          composition: "centered",
          cameraFraming: "wide shot",
          mood: "tense",
          continuityReferences: ["scene-001"],
          onScreenText: "",
          negativeConstraints: [],
          aspectRatios: ["16:9"],
          imagePrompt: "second scene",
          expectedImageFilenames: ["scene-002__000001-000003__16x9.png"],
          qualityStatus: "draft",
        },
      ],
    });

    await sliceSceneAudioFiles(narrationPath, scenePlan, tempDir);

    const segmentPaths = scenePlan.scenes.map((scene) =>
      path.join(tempDir, "audio", "segments", `${scene.id}.wav`)
    );
    await expect(fs.stat(segmentPaths[0] as string)).resolves.toBeTruthy();
    await expect(fs.stat(segmentPaths[1] as string)).resolves.toBeTruthy();
    expect(probeDurationSeconds(segmentPaths[0] as string)).toBeCloseTo(1, 1);
    expect(probeDurationSeconds(segmentPaths[1] as string)).toBeCloseTo(2, 1);
  }, 60000);
});
