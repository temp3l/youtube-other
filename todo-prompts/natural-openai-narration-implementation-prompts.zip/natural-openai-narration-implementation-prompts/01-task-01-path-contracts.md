# Batch 01 — Task 01: Current State and Path Contracts

## Recommended model

- Minimum: GPT-5 mini, medium reasoning
- Recommended: GPT-5, medium reasoning
- Best: GPT-5.5, low reasoning

## Codex prompt


You are implementing a planned production-grade TypeScript change in an existing story-to-video monorepo.

General rules:

- This is implementation work, not planning.
- Read every referenced task file and the relevant architecture documents before editing.
- Inspect existing symbols, conventions, schemas, error classes, observability, path helpers, and tests before introducing new abstractions.
- Reuse existing repository utilities and types where sound.
- Keep strict TypeScript compatibility.
- Do not use `any`, broad unsafe casts, non-null assertions, shell interpolation, or secret-bearing metadata.
- Do not implement later tasks early.
- Preserve existing production behavior unless the current task explicitly introduces a feature-flagged path.
- Keep changes additive and rollback-safe.
- Add concise TSDoc and inline comments only where behavior or invariants are non-obvious.
- Use runtime validation at artifact and external-input boundaries.
- Do not call the real OpenAI API in normal tests.
- Before finishing each task, inspect the diff, run the focused test from the task file, run the narrowest relevant type-check/tests available, and run `git diff --check`.
- Do not claim a test passed unless it was executed.
- After each task, create a clean checkpoint or commit before starting the next task in the batch.


Implement:

`docs/plans/natural-openai-narration/tasks/01-current-state-and-path-contracts.md`

Required focus:

- Inspect `apps/cli/src/index.ts`, `packages/shared/src/episode-filesystem.ts`,
  `packages/speech/src/script-markdown.ts`, and `packages/speech/src/index.ts`.
- Locate `localizedAudioBaseDir`, `localizedNarrationPathFromBase`,
  `commandAudioGenerate`, `createEpisodePathResolver`, and
  `loadEpisodeScriptMarkdown`.
- Add pure, deterministic narration artifact path helpers.
- Preserve the current compatibility output at `audio/narration.wav`.
- Add the new `audio/narration/` artifact root without changing CLI behavior.
- Reuse existing episode, locale, and variant normalizers.
- Reject empty values, traversal attempts, absolute fragments, and unsupported variants.
- Ensure returned paths remain under the expected artifact root.
- Export the public path types and resolver from `@mediaforge/speech`.
- Add comprehensive focused unit tests.

Strict non-goals:

- No schema work from Task 02.
- No CLI migration.
- No audio generation, OpenAI, FFmpeg, or filesystem writes.
- No broad path-system refactor.

Finish with a concise report listing created/modified files, exports, validation behavior,
tests executed, results, and any deferred repository issues.
