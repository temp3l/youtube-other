# Batch 02 — Task 02: Narration Domain Schemas

## Recommended model

- Minimum: GPT-5, medium reasoning
- Recommended: GPT-5, high reasoning
- Best: GPT-5.5, medium reasoning

## Codex prompt


You are implementing a planned production-grade TypeScript change in an existing story-to-video monorepo.

General rules:

- This is implementation work, not planning.
- Read every referenced task file and the relevant architecture documents before editing.
- Inspect existing symbols, conventions, schemas, error classes, observability, path helpers, and tests before introducing new abstractions.
- Reuse existing repository utilities and types where sound.
- Keep strict TypeScript compatibility.
- Do not use `any`, broad unsafe casts, non-null assertions, shell interpolation, or secret-bearing metadata.
- Do not implement later tasks early.
- Preserve existing production behavior unless the current task explicitly introduces a feature-flagged path.
- Keep changes additive and rollback-safe.
- Add concise TSDoc and inline comments only where behavior or invariants are non-obvious.
- Use runtime validation at artifact and external-input boundaries.
- Do not call the real OpenAI API in normal tests.
- Before finishing each task, inspect the diff, run the focused test from the task file, run the narrowest relevant type-check/tests available, and run `git diff --check`.
- Do not claim a test passed unless it was executed.
- After each task, create a clean checkpoint or commit before starting the next task in the batch.


Precondition: Task 01 is implemented and passing.

Implement:

`docs/plans/natural-openai-narration/tasks/02-narration-domain-schemas.md`

Inspect at minimum:

- `docs/plans/natural-openai-narration/03-narration-domain-schemas.md`
- `packages/speech/src/narration-paths.ts`
- `packages/speech/src/audio-instructions.ts`
- `packages/domain/src/index.ts`
- `packages/shared/src/index.ts`
- existing Zod schema and fixture conventions across the monorepo

Create strict, versioned Zod schemas and inferred TypeScript types for:

- spoken narration artifacts;
- chunk manifests and chunk records;
- performance direction sets;
- pronunciation transform reports;
- chunk generation/cache records;
- chunk technical validation reports;
- assembly manifests;
- mastering metadata;
- quality-gate reports;
- safe configuration snapshots;
- generation metadata.

Required invariants include:

- valid schema versions, hashes, timestamps, IDs, locale, and variants;
- non-negative durations/counters;
- bounded intensity/restraint;
- unique and contiguous chunk sequences where appropriate;
- unique chunk IDs and assembly entries;
- valid expected-duration ranges;
- completed records requiring successful output metadata;
- failed records supporting structured error metadata;
- `READY` reports rejecting blocking errors;
- safe, allow-listed configuration snapshots that cannot contain secrets.

Export only useful public schemas, types, enums, and version constants from
`packages/speech/src/index.ts`.

Strict non-goals:

- No pipeline behavior.
- No file persistence.
- No OpenAI requests.
- No segmentation, pronunciation transformation, validation execution, FFmpeg, assembly,
  mastering, quality computation, or CLI commands.

Run Task 01 tests again before completion.
